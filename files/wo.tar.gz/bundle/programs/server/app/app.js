var require = meteorInstall({"lib":{"collections":{"declarations":{"_utils.js":["babel-runtime/helpers/typeof",function(require){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/collections/declarations/_utils.js                                                                              //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var _typeof2 = require('babel-runtime/helpers/typeof');                                                                //
                                                                                                                       //
var _typeof3 = _interopRequireDefault(_typeof2);                                                                       //
                                                                                                                       //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }                      //
                                                                                                                       //
/**                                                                                                                    //
 * Created by xgfd on 26/12/2015.                                                                                      //
 */                                                                                                                    //
                                                                                                                       //
//Declare a newe EJSON type @typeName with only one instance @singular                                                 //
toEJSONSingularType = function toEJSONSingularType(singleton, typeName) {                                              // 6
                                                                                                                       //
    check(typeof singleton === 'undefined' ? 'undefined' : (0, _typeof3['default'])(singleton), 'object'); //check(singular, Ojbect) may give expected plain object error
    check(singleton.typeName, undefined);                                                                              // 6
    check(singleton.toJSONValue, undefined);                                                                           // 10
    check(typeName, String);                                                                                           // 11
                                                                                                                       //
    singleton.typeName = function () {                                                                                 // 13
        return typeName;                                                                                               // 14
    };                                                                                                                 //
                                                                                                                       //
    //the return value doesn't matter since the custom type always return one value                                    //
    singleton.toJSONValue = function () {                                                                              // 6
        return typeName;                                                                                               // 19
    };                                                                                                                 //
                                                                                                                       //
    EJSON.addType(typeName, function () {                                                                              // 22
        return singleton;                                                                                              // 23
    });                                                                                                                //
};                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"apps.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/collections/declarations/apps.js                                                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    //
 * Created by xgfd on 19/12/2015.                                                                                      //
 */                                                                                                                    //
Apps = new orion.collection('apps', {                                                                                  // 4
    singularName: 'app', // The name of one of these items                                                             // 5
    pluralName: 'apps', // The name of more than one of these items                                                    // 6
    link: {                                                                                                            // 7
        // *                                                                                                           //
        //  * The text that you want to show in the sidebar.                                                           //
        //  * The default value is the name of the collection, so                                                      //
        //  * in this case it is not necessary.                                                                        //
                                                                                                                       //
        title: 'Apps'                                                                                                  // 13
    },                                                                                                                 //
    /**                                                                                                                //
     * Tabular settings for this collection                                                                            //
     */                                                                                                                //
    tabular: {                                                                                                         // 18
        // here we set which data columns we want to appear on the data table                                          //
        // in the CMS panel                                                                                            //
        columns: [{                                                                                                    // 21
            data: "name",                                                                                              // 23
            title: "Name"                                                                                              // 24
        }, {                                                                                                           //
            data: "publisher",                                                                                         // 27
            render: function () {                                                                                      // 28
                function render(val, type, doc) {                                                                      // 28
                    var publisherId = val;                                                                             // 29
                    var publisherName = Meteor.users.findOne(publisherId).username;                                    // 30
                    return publisherName;                                                                              // 31
                }                                                                                                      //
                                                                                                                       //
                return render;                                                                                         //
            }(),                                                                                                       //
            title: "Publisher"                                                                                         // 33
        }, {                                                                                                           //
            data: "github",                                                                                            // 36
            title: "Github"                                                                                            // 37
        }, orion.attributeColumn('createdAt', 'datePublished', 'Published')]                                           //
    }                                                                                                                  //
});                                                                                                                    //
                                                                                                                       //
// Meteor.call requires parameters to be of EJSON, passing a collection as it is                                       //
// causes a Maximum call stack size exceeded error                                                                     //
toEJSONSingularType(Apps, Apps.singularName);                                                                          // 46
                                                                                                                       //
//Apps.allow({                                                                                                         //
//    update: function (userId, entry, fieldNames) {                                                                   //
//        return ownsDocument(userId, entry) && _.difference(fieldNames, appWhitelist).length === 0;                   //
//    },                                                                                                               //
//    remove: function (userId, entry) {                                                                               //
//        return ownsDocument(userId, entry);                                                                          //
//    },                                                                                                               //
//});                                                                                                                  //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"clients.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/collections/declarations/clients.js                                                                             //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    //
 * Created by xgfd on 20/01/2016.                                                                                      //
 */                                                                                                                    //
Clients = new orion.collection('clients', {                                                                            // 4
    singularName: 'client', // The name of one of these items                                                          // 5
    pluralName: 'clients', // The name of more than one of these items                                                 // 6
    link: {                                                                                                            // 7
        // *                                                                                                           //
        //  * The text that you want to show in the sidebar.                                                           //
        //  * The default value is the name of the collection, so                                                      //
        //  * in this case it is not necessary.                                                                        //
        title: 'Clients'                                                                                               // 12
    },                                                                                                                 //
    /**                                                                                                                //
     * Tabular settings for this collection                                                                            //
     */                                                                                                                //
    tabular: {                                                                                                         // 17
        // here we set which data columns we want to appear on the data table                                          //
        // in the CMS panel                                                                                            //
        columns: [{                                                                                                    // 20
            data: "name",                                                                                              // 22
            title: "Name"                                                                                              // 23
        }, {                                                                                                           //
            data: "_id",                                                                                               // 26
            title: "Client Id"                                                                                         // 27
        }, {                                                                                                           //
            data: "clientSecret",                                                                                      // 30
            title: "Client secret"                                                                                     // 31
        }, {                                                                                                           //
            data: "publisher",                                                                                         // 34
            render: function () {                                                                                      // 35
                function render(val, type, doc) {                                                                      // 35
                    var publisherId = val;                                                                             // 36
                    var publisherName = Meteor.users.findOne(publisherId).username;                                    // 37
                    return publisherName;                                                                              // 38
                }                                                                                                      //
                                                                                                                       //
                return render;                                                                                         //
            }(),                                                                                                       //
            title: "Publisher"                                                                                         // 40
        }, orion.attributeColumn('createdAt', 'datePublished', 'Created')]                                             //
    }                                                                                                                  //
});                                                                                                                    //
                                                                                                                       //
// Meteor.call requires parameters to be of EJSON, passing a collection as it is                                       //
// causes a Maximum call stack size exceeded error                                                                     //
toEJSONSingularType(Clients, Clients.singularName);                                                                    // 49
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"comments.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/collections/declarations/comments.js                                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Comments = new orion.collection('comments', {                                                                          // 1
    singularName: 'comment', // The name of one of these items                                                         // 2
    pluralName: 'comments', // The name of more than one of these items                                                // 3
    link: {                                                                                                            // 4
        // *                                                                                                           //
        //  * The text that you want to show in the sidebar.                                                           //
        //  * The default value is the name of the collection, so                                                      //
        //  * in this case it is not necessary.                                                                        //
                                                                                                                       //
        title: 'Comments'                                                                                              // 10
    },                                                                                                                 //
    /**                                                                                                                //
     * Tabular settings for this collection                                                                            //
     */                                                                                                                //
    tabular: {                                                                                                         // 15
        // here we set which data columns we want to appear on the data table                                          //
        // in the CMS panel                                                                                            //
        columns: [{                                                                                                    // 18
            data: "publisher",                                                                                         // 20
            title: "Author",                                                                                           // 21
            render: function () {                                                                                      // 22
                function render(val, type, doc) {                                                                      // 22
                    var username = Meteor.users.findOne(val).username;                                                 // 23
                    return username;                                                                                   // 24
                }                                                                                                      //
                                                                                                                       //
                return render;                                                                                         //
            }()                                                                                                        //
        }, {                                                                                                           //
            data: "entryId",                                                                                           // 27
            title: "Comment of",                                                                                       // 28
            render: function () {                                                                                      // 29
                function render(val, type, doc) {                                                                      // 29
                    var entryId = val;                                                                                 // 30
                                                                                                                       //
                    //A comment can be of either a dataset or an app                                                   //
                    var entryTitle = Datasets.findOne(entryId).name || Apps.findOne(entryId).name;                     // 29
                    return entryTitle;                                                                                 // 34
                }                                                                                                      //
                                                                                                                       //
                return render;                                                                                         //
            }()                                                                                                        //
        }, {                                                                                                           //
            data: "body",                                                                                              // 37
            title: "Comment",                                                                                          // 38
            tmpl: Meteor.isClient && Template.commentsIndexBlurbCell                                                   // 39
        }, orion.attributeColumn('createdAt', 'submitted', 'Submitted')]                                               //
    }                                                                                                                  //
});                                                                                                                    //
                                                                                                                       //
//TODO add allow & deny rules                                                                                          //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"datasets.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/collections/declarations/datasets.js                                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    //
 * Created by xgfd on 17/12/2015.                                                                                      //
 */                                                                                                                    //
                                                                                                                       //
Datasets = new orion.collection('datasets', {                                                                          // 5
    singularName: 'dataset', // The name of one of these items                                                         // 6
    pluralName: 'datasets', // The name of more than one of these items                                                // 7
    link: {                                                                                                            // 8
        // *                                                                                                           //
        //  * The text that you want to show in the sidebar.                                                           //
        //  * The default value is the name of the collection, so                                                      //
        //  * in this case it is not necessary.                                                                        //
                                                                                                                       //
        title: 'Datasets'                                                                                              // 14
    },                                                                                                                 //
                                                                                                                       //
    /**                                                                                                                //
     * Tabular settings for this collection                                                                            //
     */                                                                                                                //
    tabular: {                                                                                                         // 20
        // here we set which data columns we want to appear on the data table                                          //
        // in the CMS panel                                                                                            //
        columns: [{                                                                                                    // 23
            data: "_id",                                                                                               // 25
            title: "ID"                                                                                                // 26
        }, {                                                                                                           //
            data: "name",                                                                                              // 29
            title: "Name"                                                                                              // 30
        }, {                                                                                                           //
            data: "publisher",                                                                                         // 33
            render: function () {                                                                                      // 34
                function render(val, type, doc) {                                                                      // 34
                    var publisherId = val;                                                                             // 35
                    var publisherName = Meteor.users.findOne(publisherId).username;                                    // 36
                    return publisherName;                                                                              // 37
                }                                                                                                      //
                                                                                                                       //
                return render;                                                                                         //
            }(),                                                                                                       //
            title: "Publisher"                                                                                         // 39
        }, orion.attributeColumn('createdAt', 'datePublished', 'Published')]                                           //
    }                                                                                                                  //
});                                                                                                                    //
                                                                                                                       //
// Meteor.call requires parameters to be of EJSON, passing a collection as it is                                       //
// causes a Maximum call stack size exceeded error                                                                     //
toEJSONSingularType(Datasets, Datasets.singularName);                                                                  // 48
                                                                                                                       //
//Datasets.allow({                                                                                                     //
//    update: function (userId, entry, fieldNames) {                                                                   //
//        return ownsDocument(userId, entry);// && _.difference(fieldNames, datasetWhitelist).length === 0;            //
//    },                                                                                                               //
//    remove: function (userId, entry) {                                                                               //
//        return ownsDocument(userId, entry);                                                                          //
//    },                                                                                                               //
//});                                                                                                                  //
                                                                                                                       //
//Datasets.deny({                                                                                                      //
//    update: function (userId, entry, fieldNames) {                                                                   //
//        return _.difference(fieldNames, datasetWhitelist).length !== 0;                                              //
//    }                                                                                                                //
//});                                                                                                                  //
                                                                                                                       //
//Datasets.deny({                                                                                                      //
//    update: function (userId, entry, fieldNames, modifier) {                                                         //
//        let errors = validateDataset(modifier.$set);                                                                 //
//        return errors.name || errors.distribution;                                                                   //
//    }                                                                                                                //
//});                                                                                                                  //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"group.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/collections/declarations/group.js                                                                               //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    //
 * Created by xgfd on 24/12/2015.                                                                                      //
 */                                                                                                                    //
                                                                                                                       //
Groups = new orion.collection('groups', {                                                                              // 5
    singularName: 'group', // The name of one of these items                                                           // 6
    pluralName: 'groups', // The name of more than one of these items                                                  // 7
    link: {                                                                                                            // 8
        // *                                                                                                           //
        //  * The text that you want to show in the sidebar.                                                           //
        //  * The default value is the name of the collection, so                                                      //
        //  * in this case it is not necessary.                                                                        //
                                                                                                                       //
        title: 'Groups/Organisations'                                                                                  // 14
    },                                                                                                                 //
    /**                                                                                                                //
     * Tabular settings for this collection                                                                            //
     */                                                                                                                //
    tabular: {                                                                                                         // 19
        // here we set which data columns we want to appear on the data table                                          //
        // in the CMS panel                                                                                            //
        columns: [{                                                                                                    // 22
            data: "name",                                                                                              // 24
            title: "Name"                                                                                              // 25
        }, {                                                                                                           //
            data: "publisher",                                                                                         // 28
            title: "Founder",                                                                                          // 29
            render: function () {                                                                                      // 30
                function render(val, type, doc) {                                                                      // 30
                    var publisherName = Meteor.users.findOne(val).username;                                            // 31
                    return publisherName;                                                                              // 32
                }                                                                                                      //
                                                                                                                       //
                return render;                                                                                         //
            }()                                                                                                        //
        }, {                                                                                                           //
            data: "members",                                                                                           // 36
            title: "Members",                                                                                          // 37
            render: function () {                                                                                      // 38
                function render(val, type, doc) {                                                                      // 38
                    if (!val) {                                                                                        // 39
                        return 'No member';                                                                            // 40
                    }                                                                                                  //
                                                                                                                       //
                    var memberIds = val,                                                                               // 43
                        query = { $or: [] };                                                                           //
                    memberIds.reduce(function (previous, id) {                                                         // 45
                        return query.$or.push({ _id: id });                                                            // 46
                    }, query);                                                                                         //
                                                                                                                       //
                    return Meteor.users.find(query).map(function (user) {                                              // 49
                        return user.username;                                                                          // 50
                    });                                                                                                //
                }                                                                                                      //
                                                                                                                       //
                return render;                                                                                         //
            }()                                                                                                        //
        }, orion.attributeColumn('createdAt', 'datePublished', 'Created')]                                             //
    }                                                                                                                  //
});                                                                                                                    //
                                                                                                                       //
// When there is a change to group name, update associated account name                                                //
var query = Groups.find();                                                                                             // 60
var handle = query.observeChanges({                                                                                    // 61
    changed: function () {                                                                                             // 62
        function changed(groupId, changedField) {                                                                      // 62
            if (changedField.name) {                                                                                   // 63
                var groupAccountId = Groups.findOne(groupId).publisher;                                                // 64
                Meteor.users.update({ _id: groupAccountId }, { $set: { name: changedField.name } });                   // 65
            };                                                                                                         //
        }                                                                                                              //
                                                                                                                       //
        return changed;                                                                                                //
    }()                                                                                                                //
});                                                                                                                    //
                                                                                                                       //
Meteor.users.after.insert(function (userId, user) {                                                                    // 70
    var profile = user.profile;                                                                                        // 71
    if (profile && profile.isgroup) {                                                                                  // 72
        var group = Groups.insert({                                                                                    // 73
            publisher: user._id,                                                                                       // 74
            name: profile.name,                                                                                        // 75
            description: profile.description,                                                                          // 76
            url: profile.url                                                                                           // 77
        });                                                                                                            //
        Meteor.users.update(user._id, { $set: { isGroup: group }, $unset: { 'profile.isgroup': '' } });                // 79
        Roles.removeUserFromRoles(user._id, ["individual"]);                                                           // 80
        Roles.addUserToRoles(user._id, ["group"]);                                                                     // 81
    }                                                                                                                  //
});                                                                                                                    //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"licenses.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/collections/declarations/licenses.js                                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    //
 * Created by xgfd on 22/01/2016.                                                                                      //
 */                                                                                                                    //
                                                                                                                       //
Licenses = new orion.collection('licenses', {                                                                          // 5
    singularName: 'license', // The name of one of these items                                                         // 6
    pluralName: 'licenses', // The name of more than one of these items                                                // 7
    link: {                                                                                                            // 8
        // *                                                                                                           //
        //  * The text that you want to show in the sidebar.                                                           //
        //  * The default value is the name of the collection, so                                                      //
        //  * in this case it is not necessary.                                                                        //
                                                                                                                       //
        title: 'Licenses'                                                                                              // 14
    },                                                                                                                 //
    /**                                                                                                                //
     * Tabular settings for this collection                                                                            //
     */                                                                                                                //
    tabular: {                                                                                                         // 19
        // here we set which data columns we want to appear on the data table                                          //
        // in the CMS panel                                                                                            //
        columns: [{                                                                                                    // 22
            data: "name",                                                                                              // 24
            title: "Name"                                                                                              // 25
        }, {                                                                                                           //
            data: "url",                                                                                               // 28
            title: "URL"                                                                                               // 29
        }, {                                                                                                           //
            data: "text",                                                                                              // 32
            title: "Content"                                                                                           // 33
        }, orion.attributeColumn('createdAt', 'datePublished', 'Created')]                                             //
    }                                                                                                                  //
});                                                                                                                    //
                                                                                                                       //
defaultLicenses = new Set(["afl-3.0", "agpl-3.0", "apache-2.0", "artistic-2.0", "bsd-2-clause", "bsd-3-clause-clear", "bsd-3-clause", "cc0-1.0", "epl-1.0", "gpl-2.0", "gpl-3.0", "isc", "lgpl-2.1", "lgpl-3.0", "mit", "mpl-2.0", "ms-pl", "ms-rl", "no-license", "ofl-1.1", "osl-3.0", "unlicense", "wtfpl"]);
                                                                                                                       //
Licenses.allow({                                                                                                       // 47
    insert: function () {                                                                                              // 48
        function insert(userId, entry, fieldNames) {                                                                   // 48
            return true;                                                                                               // 49
        }                                                                                                              //
                                                                                                                       //
        return insert;                                                                                                 //
    }(),                                                                                                               //
    update: function () {                                                                                              // 51
        function update(userId, entry, fieldNames) {                                                                   // 51
            return ownsDocument(userId, entry);                                                                        // 52
        }                                                                                                              //
                                                                                                                       //
        return update;                                                                                                 //
    }(),                                                                                                               //
    remove: function () {                                                                                              // 54
        function remove(userId, entry) {                                                                               // 54
            return ownsDocument(userId, entry);                                                                        // 55
        }                                                                                                              //
                                                                                                                       //
        return remove;                                                                                                 //
    }()                                                                                                                //
});                                                                                                                    //
                                                                                                                       //
// Meteor.call requires parameters to be of EJSON, passing a collection as it is                                       //
// causes a Maximum call stack size exceeded error                                                                     //
toEJSONSingularType(Licenses, Licenses.singularName);                                                                  // 61
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"notifications.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/collections/declarations/notifications.js                                                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Notifications = new Mongo.Collection('notifications');                                                                 // 1
                                                                                                                       //
Notifications.allow({                                                                                                  // 3
    update: function () {                                                                                              // 4
        function update(userId, doc, fieldNames) {                                                                     // 4
            return doc.userId === userId && fieldNames.length === 1 && fieldNames[0] === 'read';                       // 5
        }                                                                                                              //
                                                                                                                       //
        return update;                                                                                                 //
    }()                                                                                                                //
});                                                                                                                    //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"remote.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/collections/declarations/remote.js                                                                              //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    //
 * Created by xgfd on 11/05/2016.                                                                                      //
 */                                                                                                                    //
                                                                                                                       //
RemoteDatasets = new orion.collection('remotedatasets', {                                                              // 5
    singularName: 'remotedataset', // The name of one of these items                                                   // 6
    pluralName: 'remotedatasets', // The name of more than one of these items                                          // 7
    link: {                                                                                                            // 8
        // *                                                                                                           //
        //  * The text that you want to show in the sidebar.                                                           //
        //  * The default value is the name of the collection, so                                                      //
        //  * in this case it is not necessary.                                                                        //
                                                                                                                       //
        title: 'Remote Datasets'                                                                                       // 14
    },                                                                                                                 //
                                                                                                                       //
    /**                                                                                                                //
     * Tabular settings for this collection                                                                            //
     */                                                                                                                //
    tabular: {                                                                                                         // 20
        // here we set which data columns we want to appear on the data table                                          //
        // in the CMS panel                                                                                            //
        columns: [{                                                                                                    // 23
            data: "name",                                                                                              // 25
            title: "Name"                                                                                              // 26
        }, orion.attributeColumn('createdAt', 'datePublished', 'Published')]                                           //
    }                                                                                                                  //
});                                                                                                                    //
                                                                                                                       //
RemoteApps = new orion.collection('remoteapps', {                                                                      // 33
    singularName: 'remoteapp', // The name of one of these items                                                       // 34
    pluralName: 'remoteapps', // The name of more than one of these items                                              // 35
    link: {                                                                                                            // 36
        // *                                                                                                           //
        //  * The text that you want to show in the sidebar.                                                           //
        //  * The default value is the name of the collection, so                                                      //
        //  * in this case it is not necessary.                                                                        //
                                                                                                                       //
        title: 'Remote Apps'                                                                                           // 42
    },                                                                                                                 //
    /**                                                                                                                //
     * Tabular settings for this collection                                                                            //
     */                                                                                                                //
    tabular: {                                                                                                         // 47
        // here we set which data columns we want to appear on the data table                                          //
        // in the CMS panel                                                                                            //
        columns: [{                                                                                                    // 50
            data: "name",                                                                                              // 52
            title: "Name"                                                                                              // 53
        }, orion.attributeColumn('createdAt', 'datePublished', 'Published')]                                           //
    }                                                                                                                  //
});                                                                                                                    //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"schemas":{"_creative_work.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/collections/schemas/_creative_work.js                                                                           //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    //
 * Created by xgfd on 17/12/2015.                                                                                      //
 */                                                                                                                    //
// SimpleSchema.debug = true;                                                                                          //
SimpleSchema.extendOptions({                                                                                           // 5
    noneditable: Match.Optional(Boolean)                                                                               // 6
});                                                                                                                    //
                                                                                                                       //
Thing = {                                                                                                              // 9
    name: {                                                                                                            // 10
        type: String,                                                                                                  // 11
        unique: true,                                                                                                  // 12
        label: 'Name'                                                                                                  // 13
    },                                                                                                                 //
                                                                                                                       //
    description: {                                                                                                     // 16
        type: String,                                                                                                  // 17
        label: 'Description',                                                                                          // 18
        autoform: { type: 'textarea' }                                                                                 // 19
    }                                                                                                                  //
};                                                                                                                     //
                                                                                                                       //
CreativeWork = {                                                                                                       // 23
    comments: orion.attribute('hasMany', {                                                                             // 24
        type: [String],                                                                                                // 25
        label: 'Comments',                                                                                             // 26
        // optional is true because you can have a post without comments                                               //
        optional: true,                                                                                                // 28
        noneditable: true                                                                                              // 29
    }, {                                                                                                               //
        collection: Comments,                                                                                          // 31
        titleField: 'body',                                                                                            // 32
        publicationName: 'rel_comments'                                                                                // 33
    }),                                                                                                                //
                                                                                                                       //
    commentsCount: {                                                                                                   // 36
        type: Number,                                                                                                  // 37
        autoValue: function () {                                                                                       // 38
            function autoValue() {                                                                                     //
                var comments = this.field("comments");                                                                 // 39
                return comments ? comments.length : 0;                                                                 // 40
            }                                                                                                          //
                                                                                                                       //
            return autoValue;                                                                                          //
        }(),                                                                                                           //
                                                                                                                       //
        optional: true,                                                                                                // 42
        autoform: {                                                                                                    // 43
            readonly: true                                                                                             // 44
        },                                                                                                             //
        noneditable: true                                                                                              // 46
    },                                                                                                                 //
                                                                                                                       //
    creator: {                                                                                                         // 49
        type: String,                                                                                                  // 50
        label: 'Creator',                                                                                              // 51
        optional: true                                                                                                 // 52
    },                                                                                                                 //
                                                                                                                       //
    publisher: orion.attribute('hasOne', {                                                                             // 55
        type: String,                                                                                                  // 56
        label: 'publisher',                                                                                            // 57
        denyUpdate: true,                                                                                              // 58
        autoValue: function () {                                                                                       // 59
            function autoValue() {                                                                                     //
                if (this.isInsert || this.isUpsert) {                                                                  // 60
                    return this.userId || this.value;                                                                  // 61
                } else {                                                                                               //
                    this.unset();                                                                                      // 63
                }                                                                                                      //
            }                                                                                                          //
                                                                                                                       //
            return autoValue;                                                                                          //
        }(),                                                                                                           //
                                                                                                                       //
        autoform: {                                                                                                    // 66
            type: 'select'                                                                                             // 67
            //readonly: true                                                                                           //
        },                                                                                                             // 66
        noneditable: true                                                                                              // 70
    }, {                                                                                                               //
        collection: Meteor.users,                                                                                      // 72
        // the key whose value you want to show for each post document on the update form                              //
        titleField: 'username',                                                                                        // 74
        publicationName: 'publisher'                                                                                   // 75
    }),                                                                                                                //
                                                                                                                       //
    publisherName: {                                                                                                   // 78
        type: String,                                                                                                  // 79
        optional: true,                                                                                                // 80
        autoValue: function () {                                                                                       // 81
            function autoValue() {                                                                                     //
                var publisher = this.field('publisher');                                                               // 82
                if (publisher.isSet) {                                                                                 // 83
                    var pId = publisher.value;                                                                         // 84
                    return Meteor.users.findOne(pId);                                                                  // 85
                } else {                                                                                               //
                    this.unset();                                                                                      // 87
                }                                                                                                      //
            }                                                                                                          //
                                                                                                                       //
            return autoValue;                                                                                          //
        }()                                                                                                            //
    },                                                                                                                 //
    // Force value to be current date (on server) upon insert                                                          //
    // and prevent updates thereafter.                                                                                 //
    datePublished: {                                                                                                   // 93
        type: Date,                                                                                                    // 94
        denyUpdate: true,                                                                                              // 95
        autoform: {                                                                                                    // 96
            readonly: true,                                                                                            // 97
            type: "bootstrap-datepicker"                                                                               // 98
        },                                                                                                             //
        autoValue: function () {                                                                                       // 100
            function autoValue() {                                                                                     // 100
                if (this.isInsert || this.isUpsert) {                                                                  // 101
                    return new Date();                                                                                 // 102
                } else {                                                                                               //
                    this.unset(); // Prevent user from supplying their own value                                       // 104
                }                                                                                                      // 103
            }                                                                                                          //
                                                                                                                       //
            return autoValue;                                                                                          //
        }()                                                                                                            //
    },                                                                                                                 //
                                                                                                                       //
    // Force value to be current date (on server) upon update                                                          //
    // and don't allow it to be set upon insert.                                                                       //
    dateModified: {                                                                                                    // 111
        type: Date,                                                                                                    // 112
        autoform: {                                                                                                    // 113
            readonly: true,                                                                                            // 114
            type: "bootstrap-datepicker"                                                                               // 115
        },                                                                                                             //
        autoValue: function () {                                                                                       // 117
            function autoValue() {                                                                                     //
                return new Date();                                                                                     // 118
            }                                                                                                          //
                                                                                                                       //
            return autoValue;                                                                                          //
        }(),                                                                                                           //
                                                                                                                       //
        noneditable: true                                                                                              // 120
    },                                                                                                                 //
                                                                                                                       //
    isBasedOnUrl: orion.attribute('hasMany', {                                                                         // 123
        type: [String],                                                                                                // 124
        label: 'Related datasets',                                                                                     // 125
        optional: true                                                                                                 // 126
    }, {                                                                                                               //
        collection: Datasets,                                                                                          // 128
        titleField: 'name',                                                                                            // 129
        publicationName: 'isbasedonurl'                                                                                // 130
    }),                                                                                                                //
                                                                                                                       //
    keywords: {                                                                                                        // 133
        type: [String],                                                                                                // 134
        label: 'Keywords',                                                                                             // 135
        optional: true                                                                                                 // 136
    },                                                                                                                 //
                                                                                                                       //
    license: {                                                                                                         // 139
        type: String,                                                                                                  // 140
        label: 'License',                                                                                              // 141
        autoform: {                                                                                                    // 142
            options: function () {                                                                                     // 143
                function options() {                                                                                   //
                    var addedLices = Licenses.find().fetch();                                                          // 144
                                                                                                                       //
                    var options = [];                                                                                  // 146
                    defaultLicenses.forEach(function (name) {                                                          // 147
                        options.push({ label: name.toUpperCase(), value: name });                                      // 148
                    });                                                                                                //
                                                                                                                       //
                    addedLices.forEach(function (lice) {                                                               // 151
                        if (lice.name) {                                                                               // 152
                            var name = lice.name;                                                                      // 153
                            options.push({ label: name.toUpperCase(), value: name });                                  // 154
                        }                                                                                              //
                    });                                                                                                //
                                                                                                                       //
                    return options;                                                                                    // 158
                }                                                                                                      //
                                                                                                                       //
                return options;                                                                                        //
            }()                                                                                                        //
        }                                                                                                              //
    }                                                                                                                  //
};                                                                                                                     //
                                                                                                                       //
Mis = {                                                                                                                // 164
    upvoters: {                                                                                                        // 165
        type: [String],                                                                                                // 166
        optional: true,                                                                                                // 167
        autoform: {                                                                                                    // 168
            readonly: true                                                                                             // 169
        }                                                                                                              //
    },                                                                                                                 //
                                                                                                                       //
    votes: {                                                                                                           // 173
        type: Number,                                                                                                  // 174
        autoform: {                                                                                                    // 175
            readonly: true                                                                                             // 176
        },                                                                                                             //
        optional: true,                                                                                                // 178
        autoValue: function () {                                                                                       // 179
            function autoValue() {                                                                                     //
                var voters = this.field('upvoters');                                                                   // 180
                return voters ? voters.length : 0;                                                                     // 181
            }                                                                                                          //
                                                                                                                       //
            return autoValue;                                                                                          //
        }()                                                                                                            //
    },                                                                                                                 //
                                                                                                                       //
    downvoters: {                                                                                                      // 185
        type: [String],                                                                                                // 186
        optional: true,                                                                                                // 187
        autoform: {                                                                                                    // 188
            readonly: true                                                                                             // 189
        }                                                                                                              //
    },                                                                                                                 //
                                                                                                                       //
    downvotes: {                                                                                                       // 193
        type: Number,                                                                                                  // 194
        autoform: {                                                                                                    // 195
            readonly: true                                                                                             // 196
        },                                                                                                             //
        optional: true,                                                                                                // 198
        autoValue: function () {                                                                                       // 199
            function autoValue() {                                                                                     //
                var voters = this.field('downvoters');                                                                 // 200
                return voters ? voters.length : 0;                                                                     // 201
            }                                                                                                          //
                                                                                                                       //
            return autoValue;                                                                                          //
        }()                                                                                                            //
    },                                                                                                                 //
                                                                                                                       //
    // whether this entry is online                                                                                    //
    // in case of a dataset, it's offline if any of its distribution is offline                                        //
    online: {                                                                                                          // 207
        type: Boolean,                                                                                                 // 208
        autoform: {                                                                                                    // 209
            readonly: true,                                                                                            // 210
            type: 'hidden'                                                                                             // 211
        },                                                                                                             //
        optional: true,                                                                                                // 213
        defaultValue: true                                                                                             // 214
    },                                                                                                                 //
                                                                                                                       //
    //metadata permission i.e. visibility                                                                              //
    aclMeta: {                                                                                                         // 218
        type: Boolean,                                                                                                 // 219
        label: "Visible to everyone",                                                                                  // 220
        defaultValue: true                                                                                             // 221
    },                                                                                                                 //
                                                                                                                       //
    //content permission i.e. queryability                                                                             //
    aclContent: {                                                                                                      // 225
        type: Boolean,                                                                                                 // 226
        label: "Accessible to everyone",                                                                               // 227
        defaultValue: true                                                                                             // 228
    },                                                                                                                 //
                                                                                                                       //
    //who can see this entry disregards acl settings                                                                   //
    metaWhiteList: orion.attribute('hasMany', {                                                                        // 232
        type: [String],                                                                                                // 233
        label: 'Permitted to see',                                                                                     // 234
        optional: true                                                                                                 // 235
    }, {                                                                                                               //
        collection: Meteor.users,                                                                                      // 237
        titleField: 'username',                                                                                        // 238
        publicationName: 'metawhitelist'                                                                               // 239
    }),                                                                                                                //
                                                                                                                       //
    //who can access this entry disregards acl settings                                                                //
    contentWhiteList: orion.attribute('hasMany', {                                                                     // 243
        type: [String],                                                                                                // 244
        label: 'Permitted to access',                                                                                  // 245
        optional: true                                                                                                 // 246
    }, {                                                                                                               //
        collection: Meteor.users,                                                                                      // 248
        titleField: 'username',                                                                                        // 249
        publicationName: 'contentwhitelist'                                                                            // 250
    })                                                                                                                 //
};                                                                                                                     //
                                                                                                                       //
_.extend(CreativeWork, Thing);                                                                                         // 254
_.extend(CreativeWork, Mis);                                                                                           // 255
                                                                                                                       //
omitFields = "publisher, comments, commentsCount, datePublished, dateModified, upvoters, downvoters, votes, downvotes, online, distribution.$._id".split(/\s*,\s*/);
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"apps.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/collections/schemas/apps.js                                                                                     //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    //
 * Created by xgfd on 19/12/2015.                                                                                      //
 */                                                                                                                    //
                                                                                                                       //
AppSchema = {                                                                                                          // 5
    url: {                                                                                                             // 6
        type: String,                                                                                                  // 7
        label: "URL",                                                                                                  // 8
        regEx: SimpleSchema.RegEx.Url,                                                                                 // 9
        autoform: {                                                                                                    // 10
            type: 'url',                                                                                               // 11
            placeholder: "Provide the URL of your web app or upload the app source below"                              // 12
        }                                                                                                              //
    },                                                                                                                 //
    file: orion.attribute('file', {                                                                                    // 15
        label: 'Upload app source as a zip file. Only support apps written in client-side JS and HTML',                // 16
        optional: true                                                                                                 // 17
    }),                                                                                                                //
    github: {                                                                                                          // 19
        type: String,                                                                                                  // 20
        optional: true,                                                                                                // 21
        label: "Github",                                                                                               // 22
        regEx: SimpleSchema.RegEx.Url                                                                                  // 23
    }                                                                                                                  //
};                                                                                                                     //
                                                                                                                       //
////_.extend(App, CreativeWork);                                                                                       //
//                                                                                                                     //
////important, generate whitelist before constructing simpleschema                                                     //
//appWhitelist = _.filter(_.keys(App), function (property) {                                                           //
//    return !App[property].noneditable;                                                                               //
//});                                                                                                                  //
//                                                                                                                     //
//_.extend(appWhitelist, Whitelist);                                                                                   //
//                                                                                                                     //
//appBlacklist = _.filter(_.keys(App), function (property) {                                                           //
//    return App[property].noneditable;                                                                                //
//});                                                                                                                  //
//                                                                                                                     //
//_.extend(appBlacklist, BlackList);                                                                                   //
                                                                                                                       //
Apps.attachSchema(new SimpleSchema([Thing, AppSchema, CreativeWork]));                                                 // 42
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"clients.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/collections/schemas/clients.js                                                                                  //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    //
 * Created by xgfd on 20/01/2016.                                                                                      //
 */                                                                                                                    //
var ClientSchema = new SimpleSchema({                                                                                  // 4
                                                                                                                       //
    name: {                                                                                                            // 6
        type: String,                                                                                                  // 7
        label: 'Name'                                                                                                  // 8
    },                                                                                                                 //
                                                                                                                       //
    publisher: orion.attribute('hasOne', {                                                                             // 11
        type: String,                                                                                                  // 12
        label: 'publisher',                                                                                            // 13
        denyUpdate: true,                                                                                              // 14
        autoValue: function () {                                                                                       // 15
            function autoValue() {                                                                                     //
                if (this.isInsert || this.isUpsert) {                                                                  // 16
                    return this.userId || this.value;                                                                  // 17
                } else {                                                                                               //
                    this.unset();                                                                                      // 19
                }                                                                                                      //
            }                                                                                                          //
                                                                                                                       //
            return autoValue;                                                                                          //
        }(),                                                                                                           //
                                                                                                                       //
        autoform: {                                                                                                    // 22
            type: 'select',                                                                                            // 23
            omit: true,                                                                                                // 24
            readonly: true                                                                                             // 25
        }                                                                                                              //
    }, {                                                                                                               //
        collection: Meteor.users,                                                                                      // 28
        // the key whose value you want to show for each post document on the update form                              //
        titleField: 'username',                                                                                        // 30
        publicationName: 'clientpublisher'                                                                             // 31
    }),                                                                                                                //
                                                                                                                       //
    clientSecret: {                                                                                                    // 34
        type: String,                                                                                                  // 35
        denyUpdate: true,                                                                                              // 36
        autoValue: function () {                                                                                       // 37
            function autoValue() {                                                                                     //
                if (this.isInsert || this.isUpsert) {                                                                  // 38
                    return Random.id();                                                                                // 39
                } else {                                                                                               //
                    this.unset();                                                                                      // 41
                }                                                                                                      //
            }                                                                                                          //
                                                                                                                       //
            return autoValue;                                                                                          //
        }(),                                                                                                           //
                                                                                                                       //
        autoform: {                                                                                                    // 44
            omit: true,                                                                                                // 45
            readonly: true                                                                                             // 46
        }                                                                                                              //
    },                                                                                                                 //
                                                                                                                       //
    datePublished: {                                                                                                   // 50
        type: Date,                                                                                                    // 51
        denyUpdate: true,                                                                                              // 52
        autoform: {                                                                                                    // 53
            readonly: true,                                                                                            // 54
            omit: true,                                                                                                // 55
            type: "bootstrap-datepicker"                                                                               // 56
        },                                                                                                             //
        autoValue: function () {                                                                                       // 58
            function autoValue() {                                                                                     // 58
                if (this.isInsert || this.isUpsert) {                                                                  // 59
                    return new Date();                                                                                 // 60
                } else {                                                                                               //
                    this.unset(); // Prevent user from supplying their own value                                       // 62
                }                                                                                                      // 61
            }                                                                                                          //
                                                                                                                       //
            return autoValue;                                                                                          //
        }()                                                                                                            //
    },                                                                                                                 //
                                                                                                                       //
    callbackUrl: {                                                                                                     // 67
        type: String,                                                                                                  // 68
        label: 'Callback URL',                                                                                         // 69
        optional: true                                                                                                 // 70
    }                                                                                                                  //
});                                                                                                                    //
                                                                                                                       //
Clients.attachSchema(ClientSchema);                                                                                    // 74
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"comments.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/collections/schemas/comments.js                                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    //
 * Now we will attach the schema for that collection.                                                                  //
 * Orion will automatically create the corresponding form.                                                             //
 */                                                                                                                    //
Comments.attachSchema(new SimpleSchema({                                                                               // 5
    entryId: {                                                                                                         // 6
        type: String,                                                                                                  // 7
        // the label is the text that will show up on the Update form's label                                          //
        label: 'Comment of',                                                                                           // 9
        // optional is false because you shouldn't have a comment without a post                                       //
        // associated with it                                                                                          //
        autoform: {                                                                                                    // 12
            type: "hidden",                                                                                            // 13
            readonly: true                                                                                             // 14
        }                                                                                                              //
    },                                                                                                                 //
    // here is where we define `a comment has one user (author)`                                                       //
    // Each document in Comment has a userId                                                                           //
    publisher: {                                                                                                       // 19
        type: String,                                                                                                  // 20
        label: 'Author',                                                                                               // 21
        autoform: {                                                                                                    // 22
            type: "hidden",                                                                                            // 23
            readonly: true                                                                                             // 24
        }                                                                                                              //
    },                                                                                                                 //
    category: {                                                                                                        // 27
        type: String,                                                                                                  // 28
        optional: true                                                                                                 // 29
    },                                                                                                                 //
    submitted: {                                                                                                       // 31
        type: Date,                                                                                                    // 32
        autoform: {                                                                                                    // 33
            readonly: true                                                                                             // 34
        }                                                                                                              //
    },                                                                                                                 //
    body: { type: String, label: 'Body', autoform: { type: 'textarea' } },                                             // 37
    image: orion.attribute('image', {                                                                                  // 38
        optional: true,                                                                                                // 39
        label: 'Comment Image'                                                                                         // 40
    })                                                                                                                 //
}));                                                                                                                   //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"datasets.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/collections/schemas/datasets.js                                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    //
 * http://schema.org/Dataset                                                                                           //
 * Created by xgfd on 17/12/2015.                                                                                      //
 */                                                                                                                    //
                                                                                                                       //
var DistributionSchema = new SimpleSchema({                                                                            // 6
                                                                                                                       //
    _id: {                                                                                                             // 8
        type: String,                                                                                                  // 9
        denyUpdate: true,                                                                                              // 10
        optional: true,                                                                                                // 11
        autoValue: function () {                                                                                       // 12
            function autoValue() {                                                                                     //
                if (this.isInsert || this.isUpsert) {                                                                  // 13
                    return Random.id();                                                                                // 14
                } else {                                                                                               //
                    this.unset();                                                                                      // 16
                }                                                                                                      //
            }                                                                                                          //
                                                                                                                       //
            return autoValue;                                                                                          //
        }(),                                                                                                           //
                                                                                                                       //
        autoform: {                                                                                                    // 19
            readonly: true                                                                                             // 20
        }                                                                                                              //
    },                                                                                                                 //
                                                                                                                       //
    fileFormat: {                                                                                                      // 24
        type: String,                                                                                                  // 25
        label: 'Format',                                                                                               // 26
        allowedValues: ['MongoDB', 'MySQL', 'AMQP', 'SPARQL', 'HTML', 'File'],                                         // 27
        autoform: { type: 'select' }                                                                                   // 28
        //TODO custom validate                                                                                         //
    },                                                                                                                 // 24
                                                                                                                       //
    url: {                                                                                                             // 32
        type: String,                                                                                                  // 33
        label: 'Distribution URL',                                                                                     // 34
        autoform: {                                                                                                    // 35
            type: 'url',                                                                                               // 36
            placeholder: "Select a format"                                                                             // 37
        }                                                                                                              //
    },                                                                                                                 //
                                                                                                                       //
    file: orion.attribute('file', {                                                                                    // 41
        label: 'Upload dataset as a file.',                                                                            // 42
        optional: true                                                                                                 // 43
    }),                                                                                                                //
                                                                                                                       //
    profile: {                                                                                                         // 46
        type: Object,                                                                                                  // 47
        optional: true,                                                                                                // 48
        autoValue: function () {                                                                                       // 49
            function autoValue() {                                                                                     //
                if (!this.isSet) {                                                                                     // 50
                    return {};                                                                                         // 51
                }                                                                                                      //
            }                                                                                                          //
                                                                                                                       //
            return autoValue;                                                                                          //
        }()                                                                                                            //
    },                                                                                                                 //
    'profile.username': {                                                                                              // 55
        type: String,                                                                                                  // 56
        optional: true,                                                                                                // 57
        label: 'Dataset user name'                                                                                     // 58
    },                                                                                                                 //
    'profile.pass': {                                                                                                  // 60
        type: String,                                                                                                  // 61
        optional: true,                                                                                                // 62
        label: 'Dataset password'                                                                                      // 63
    },                                                                                                                 //
                                                                                                                       //
    instruction: {                                                                                                     // 66
        type: String,                                                                                                  // 67
        optional: true,                                                                                                // 68
        label: 'Instruction to access this dataset',                                                                   // 69
        autoform: { type: 'textarea' }                                                                                 // 70
    },                                                                                                                 //
                                                                                                                       //
    //whether this distribution is online                                                                              //
    online: {                                                                                                          // 74
        type: Boolean,                                                                                                 // 75
        autoform: {                                                                                                    // 76
            type: 'hidden'                                                                                             // 77
            //omit: true,                                                                                              //
        },                                                                                                             // 76
        optional: true,                                                                                                // 80
        autoValue: function () {                                                                                       // 81
            function autoValue() {                                                                                     //
                if (this.isInsert || this.isUpsert) {                                                                  // 82
                    return this.value || true;                                                                         // 83
                } else if (!this.isSet) {                                                                              //
                    this.unset();                                                                                      // 85
                }                                                                                                      //
            }                                                                                                          //
                                                                                                                       //
            return autoValue;                                                                                          //
        }()                                                                                                            //
    }                                                                                                                  //
});                                                                                                                    //
                                                                                                                       //
DatasetSchema = {                                                                                                      // 91
                                                                                                                       //
    url: {                                                                                                             // 93
        type: String,                                                                                                  // 94
        label: "URL",                                                                                                  // 95
        regEx: SimpleSchema.RegEx.Url,                                                                                 // 96
        autoform: {                                                                                                    // 97
            type: 'hidden'                                                                                             // 98
        },                                                                                                             //
        optional: true,                                                                                                // 100
        autoValue: function () {                                                                                       // 101
            function autoValue() {                                                                                     //
                if (!this.isSet) {                                                                                     // 102
                    var distribution = this.field('distribution').value;                                               // 103
                    if (distribution && distribution.length === 1 && distribution[0].fileFormat === 'HTML') {          // 104
                        return distribution[0].url;                                                                    // 105
                    }                                                                                                  //
                }                                                                                                      //
            }                                                                                                          //
                                                                                                                       //
            return autoValue;                                                                                          //
        }()                                                                                                            //
    },                                                                                                                 //
                                                                                                                       //
    distribution: {                                                                                                    // 111
        type: [DistributionSchema],                                                                                    // 112
        label: "Distribution"                                                                                          // 113
    },                                                                                                                 //
                                                                                                                       //
    datasetTimeInterval: {                                                                                             // 116
        type: Object,                                                                                                  // 117
        label: "Time span",                                                                                            // 118
        optional: true                                                                                                 // 119
    },                                                                                                                 //
                                                                                                                       //
    "datasetTimeInterval.startTime": {                                                                                 // 122
        type: Date,                                                                                                    // 123
        label: "Start",                                                                                                // 124
        autoform: {                                                                                                    // 125
            type: "bootstrap-datepicker" // set to bootstrap-datepicker to work with materilize, check out https://github.com/djhi/meteor-autoform-materialize/
        }                                                                                                              // 125
    },                                                                                                                 //
                                                                                                                       //
    "datasetTimeInterval.endTime": {                                                                                   // 130
        type: Date,                                                                                                    // 131
        label: "End",                                                                                                  // 132
        autoform: {                                                                                                    // 133
            type: "bootstrap-datepicker"                                                                               // 134
        }                                                                                                              //
    },                                                                                                                 //
                                                                                                                       //
    spatial: {                                                                                                         // 138
        type: String,                                                                                                  // 139
        label: "Spatial coverage",                                                                                     // 140
        optional: true                                                                                                 // 141
    }                                                                                                                  //
};                                                                                                                     //
                                                                                                                       //
//_.extend(Dataset, CreativeWork);                                                                                     //
//important, generate whitelist before constructing simpleschema                                                       //
//datasetWhitelist = _.filter(_.keys(Dataset), function (property) {                                                   //
//    return !Dataset[property].noneditable;                                                                           //
//});                                                                                                                  //
//                                                                                                                     //
//_.extend(datasetWhitelist, Whitelist);                                                                               //
//                                                                                                                     //
//datasetBlackList = _.filter(_.keys(Dataset), function (property) {                                                   //
//    return Dataset[property].noneditable;                                                                            //
//});                                                                                                                  //
//                                                                                                                     //
//_.extend(datasetBlackList, BlackList);                                                                               //
                                                                                                                       //
/* the following will cause errors;                                                                                    //
 * new SimpleSchema(Dataset)) modifies Dataset and therefore modifies CreativeWork                                     //
 _.extend(Dataset, CreativeWork);                                                                                      //
 Datasets.attachSchema(new SimpleSchema(Dataset));                                                                     //
 */                                                                                                                    //
Datasets.attachSchema(new SimpleSchema([Thing, DatasetSchema, CreativeWork]));                                         // 164
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"groups.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/collections/schemas/groups.js                                                                                   //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    //
 * Created by xgfd on 24/12/2015.                                                                                      //
 */                                                                                                                    //
                                                                                                                       //
var Group = {                                                                                                          // 5
    name: { type: String },                                                                                            // 6
                                                                                                                       //
    description: { type: String, optional: true },                                                                     // 8
                                                                                                                       //
    url: { type: String, label: 'Home page', regEx: SimpleSchema.RegEx.Url, optional: true, autoform: { type: 'url' } },
                                                                                                                       //
    youtube: { type: String, regEx: SimpleSchema.RegEx.Url, optional: true, autoform: { type: 'url' } },               // 12
                                                                                                                       //
    github: { type: String, regEx: SimpleSchema.RegEx.Url, optional: true, autoform: { type: 'url' } },                // 14
                                                                                                                       //
    publisher: orion.attribute('hasOne', {                                                                             // 16
        type: String,                                                                                                  // 17
        label: 'Founder'                                                                                               // 18
    }, {                                                                                                               //
        collection: Meteor.users,                                                                                      // 20
        titleField: 'username',                                                                                        // 21
        publicationName: 'groupfounder'                                                                                // 22
    }),                                                                                                                //
                                                                                                                       //
    //who can access this entry disregards acl settings                                                                //
    //used as Members field to reuse existing functions                                                                //
    contentWhiteList: orion.attribute('hasMany', {                                                                     // 27
        type: [String],                                                                                                // 28
        label: 'Members',                                                                                              // 29
        // optional is true because you can have a post without comments                                               //
        optional: true                                                                                                 // 31
    }, {                                                                                                               //
        collection: Meteor.users,                                                                                      // 33
        titleField: 'username',                                                                                        // 34
        publicationName: 'groupmembers'                                                                                // 35
    }),                                                                                                                //
                                                                                                                       //
    datasets: orion.attribute('hasMany', {                                                                             // 38
        type: [String],                                                                                                // 39
        label: 'Datasets',                                                                                             // 40
        // optional is true because you can have a post without comments                                               //
        optional: true                                                                                                 // 42
    }, {                                                                                                               //
        collection: Datasets,                                                                                          // 44
        titleField: 'name',                                                                                            // 45
        publicationName: 'groupdatasets'                                                                               // 46
    }),                                                                                                                //
                                                                                                                       //
    apps: orion.attribute('hasMany', {                                                                                 // 49
        type: [String],                                                                                                // 50
        label: 'Apps',                                                                                                 // 51
        // optional is true because you can have a post without comments                                               //
        optional: true                                                                                                 // 53
    }, {                                                                                                               //
        collection: Apps,                                                                                              // 55
        titleField: 'name',                                                                                            // 56
        publicationName: 'groupapps'                                                                                   // 57
    }),                                                                                                                //
                                                                                                                       //
    //publications: {type: [Object], label: "Publications", optional: true},                                           //
    "publications.$.name": { type: String, optional: true },                                                           // 61
    "publications.$.url": { type: String, optional: true, autoform: { type: 'url' } },                                 // 62
                                                                                                                       //
    datePublished: {                                                                                                   // 64
        type: Date,                                                                                                    // 65
        label: "Created at",                                                                                           // 66
        denyUpdate: true,                                                                                              // 67
        autoform: {                                                                                                    // 68
            readonly: true,                                                                                            // 69
            type: "bootstrap-datepicker"                                                                               // 70
        },                                                                                                             //
        autoValue: function () {                                                                                       // 72
            function autoValue() {                                                                                     // 72
                if (this.isInsert) {                                                                                   // 73
                    return new Date();                                                                                 // 74
                } else if (this.isUpsert) {                                                                            //
                    return { $setOnInsert: new Date() };                                                               // 76
                } else {                                                                                               //
                    this.unset(); // Prevent user from supplying their own value                                       // 78
                }                                                                                                      // 77
            }                                                                                                          //
                                                                                                                       //
            return autoValue;                                                                                          //
        }()                                                                                                            //
    },                                                                                                                 //
                                                                                                                       //
    upvoters: {                                                                                                        // 83
        type: [String],                                                                                                // 84
        optional: true,                                                                                                // 85
        autoform: {                                                                                                    // 86
            readonly: true                                                                                             // 87
        }                                                                                                              //
    },                                                                                                                 //
                                                                                                                       //
    votes: {                                                                                                           // 91
        type: Number,                                                                                                  // 92
        autoform: {                                                                                                    // 93
            readonly: true                                                                                             // 94
        },                                                                                                             //
        optional: true                                                                                                 // 96
    },                                                                                                                 //
                                                                                                                       //
    // whether this entry is online                                                                                    //
    // in case of a dataset, it's offline if any of its distribution is offline                                        //
    online: {                                                                                                          // 101
        type: Boolean,                                                                                                 // 102
        autoform: {                                                                                                    // 103
            type: 'hidden',                                                                                            // 104
            readonly: true                                                                                             // 105
        },                                                                                                             //
        defaultValue: true                                                                                             // 107
    },                                                                                                                 //
                                                                                                                       //
    //metadata permission i.e. visibility                                                                              //
    aclMeta: {                                                                                                         // 111
        type: Boolean,                                                                                                 // 112
        label: "Visible to everyone",                                                                                  // 113
        defaultValue: true                                                                                             // 114
    },                                                                                                                 //
                                                                                                                       //
    aclContent: {                                                                                                      // 117
        type: Boolean,                                                                                                 // 118
        label: "Everyone can join",                                                                                    // 119
        defaultValue: true                                                                                             // 120
    }                                                                                                                  //
};                                                                                                                     //
                                                                                                                       //
Groups.attachSchema(new SimpleSchema([Group]));                                                                        // 124
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"licenses.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/collections/schemas/licenses.js                                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    //
 * Created by xgfd on 22/01/2016.                                                                                      //
 */                                                                                                                    //
                                                                                                                       //
var LicenseSchema = new SimpleSchema({                                                                                 // 5
    name: {                                                                                                            // 6
        type: String,                                                                                                  // 7
        label: 'License name'                                                                                          // 8
    },                                                                                                                 //
    url: {                                                                                                             // 10
        type: String,                                                                                                  // 11
        label: 'License URL',                                                                                          // 12
        autoform: {                                                                                                    // 13
            type: 'url'                                                                                                // 14
        },                                                                                                             //
        optional: true                                                                                                 // 16
    },                                                                                                                 //
    publisher: orion.attribute('hasOne', {                                                                             // 18
        type: String,                                                                                                  // 19
        label: 'publisher',                                                                                            // 20
        denyUpdate: true,                                                                                              // 21
        autoValue: function () {                                                                                       // 22
            function autoValue() {                                                                                     //
                if (this.isInsert || this.isUpsert) {                                                                  // 23
                    return Meteor.userId();                                                                            // 24
                } else {                                                                                               //
                    this.unset();                                                                                      // 26
                }                                                                                                      //
            }                                                                                                          //
                                                                                                                       //
            return autoValue;                                                                                          //
        }(),                                                                                                           //
                                                                                                                       //
        autoform: {                                                                                                    // 29
            type: 'select',                                                                                            // 30
            readonly: true,                                                                                            // 31
            omit: true                                                                                                 // 32
        },                                                                                                             //
        noneditable: true                                                                                              // 34
    }, {                                                                                                               //
        collection: Meteor.users,                                                                                      // 36
        // the key whose value you want to show for each post document on the update form                              //
        titleField: 'username',                                                                                        // 38
        publicationName: 'licepublisher'                                                                               // 39
    }),                                                                                                                //
    text: {                                                                                                            // 41
        type: String,                                                                                                  // 42
        label: 'License content',                                                                                      // 43
        autoform: {                                                                                                    // 44
            type: 'textarea'                                                                                           // 45
        },                                                                                                             //
        optional: true                                                                                                 // 47
    },                                                                                                                 //
    datePublished: {                                                                                                   // 49
        type: Date,                                                                                                    // 50
        denyUpdate: true,                                                                                              // 51
        autoform: {                                                                                                    // 52
            readonly: true,                                                                                            // 53
            omit: true,                                                                                                // 54
            type: "bootstrap-datepicker"                                                                               // 55
        },                                                                                                             //
        autoValue: function () {                                                                                       // 57
            function autoValue() {                                                                                     // 57
                if (this.isInsert || this.isUpsert) {                                                                  // 58
                    return new Date();                                                                                 // 59
                } else {                                                                                               //
                    this.unset(); // Prevent user from supplying their own value                                       // 61
                }                                                                                                      // 60
            }                                                                                                          //
                                                                                                                       //
            return autoValue;                                                                                          //
        }()                                                                                                            //
    }                                                                                                                  //
});                                                                                                                    //
                                                                                                                       //
Licenses.attachSchema(LicenseSchema);                                                                                  // 67
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"remote.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/collections/schemas/remote.js                                                                                   //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    //
 * Created by xgfd on 12/05/2016.                                                                                      //
 */                                                                                                                    //
var remoteMeta = {                                                                                                     // 4
    origin: {                                                                                                          // 5
        type: String,                                                                                                  // 6
        label: 'Origin',                                                                                               // 7
        optional: true                                                                                                 // 8
    }                                                                                                                  //
};                                                                                                                     //
                                                                                                                       //
var ReleasedCreativeWork = _.clone(CreativeWork);                                                                      // 12
                                                                                                                       //
ReleasedCreativeWork.publisher = {                                                                                     // 14
    type: String,                                                                                                      // 15
    label: 'Publisher',                                                                                                // 16
    optional: true,                                                                                                    // 17
    autoform: { type: 'hidden' }                                                                                       // 18
};                                                                                                                     //
                                                                                                                       //
ReleasedCreativeWork.description = {                                                                                   // 21
    type: String,                                                                                                      // 22
    label: 'Description',                                                                                              // 23
    optional: true,                                                                                                    // 24
    autoform: { type: 'textarea' }                                                                                     // 25
};                                                                                                                     //
                                                                                                                       //
ReleasedCreativeWork.metaWhiteList = {                                                                                 // 28
    type: [String],                                                                                                    // 29
    label: 'Permitted to see',                                                                                         // 30
    optional: true                                                                                                     // 31
};                                                                                                                     //
                                                                                                                       //
ReleasedCreativeWork.contentWhiteList = {                                                                              // 34
    type: [String],                                                                                                    // 35
    label: 'Permitted to access',                                                                                      // 36
    optional: true                                                                                                     // 37
};                                                                                                                     //
                                                                                                                       //
RemoteApps.attachSchema(new SimpleSchema([remoteMeta, AppSchema, ReleasedCreativeWork]));                              // 40
RemoteDatasets.attachSchema(new SimpleSchema([remoteMeta, DatasetSchema, ReleasedCreativeWork]));                      // 41
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"config":{"at_config.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/config/at_config.js                                                                                             //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
function ldapOrUserPass(error, state) {                                                                                // 1
    console.log({ error: error, state: state });                                                                       // 2
    if (error && state === 'signIn' //user/pass login failed                                                           // 3
     && orion.dictionary.get('ldap.ldap') && orion.dictionary.get('ldap.ldap').length !== 0) {                         // 3
                                                                                                                       //
        var username = document.getElementById("at-field-username_and_email").value;                                   // 7
        pass = document.getElementById("at-field-password").value;                                                     // 8
                                                                                                                       //
        Meteor.loginWithLdap(username, pass, function (err) {                                                          // 10
            if (err) {                                                                                                 // 11
                var errSpan = $('.at-form .at-error span');                                                            // 12
                errSpan.html('<i class="mdi-alert-warning"></i> ' + err.reason);                                       // 13
            }                                                                                                          //
        });                                                                                                            //
    }                                                                                                                  //
}                                                                                                                      //
// Options                                                                                                             //
AccountsTemplates.configure({                                                                                          // 19
    // defaultLayout: 'emptyLayout',                                                                                   //
    showForgotPasswordLink: true,                                                                                      // 21
    overrideLoginErrors: false,                                                                                        // 22
    enablePasswordChange: true,                                                                                        // 23
                                                                                                                       //
    sendVerificationEmail: false,                                                                                      // 25
    // enforceEmailVerification: true,                                                                                 //
    confirmPassword: true,                                                                                             // 27
    //continuousValidation: false,                                                                                     //
    //displayFormLabels: true,                                                                                         //
    forbidClientAccountCreation: false,                                                                                // 30
    //formValidationFeedback: true,                                                                                    //
    homeRoutePath: '/',                                                                                                // 32
    //showAddRemoveServices: false,                                                                                    //
    showPlaceholders: true,                                                                                            // 34
    lowercaseUsername: true,                                                                                           // 35
    onSubmitHook: ldapOrUserPass,                                                                                      // 36
    continuousValidation: true,                                                                                        // 37
    negativeValidation: true,                                                                                          // 38
    positiveValidation: true,                                                                                          // 39
    negativeFeedback: false,                                                                                           // 40
    positiveFeedback: true                                                                                             // 41
                                                                                                                       //
});                                                                                                                    //
                                                                                                                       //
// Privacy Policy and Terms of Use                                                                                     //
//privacyUrl: 'privacy',                                                                                               //
//termsUrl: 'terms-of-use',                                                                                            //
var pwd = AccountsTemplates.removeField('password');                                                                   // 48
AccountsTemplates.removeField('email');                                                                                // 49
AccountsTemplates.addFields([{                                                                                         // 50
    _id: "username",                                                                                                   // 52
    type: "text",                                                                                                      // 53
    displayName: "username",                                                                                           // 54
    required: true,                                                                                                    // 55
    minLength: 4                                                                                                       // 56
}, {                                                                                                                   //
    _id: 'email',                                                                                                      // 59
    type: 'email',                                                                                                     // 60
    required: true,                                                                                                    // 61
    displayName: "email",                                                                                              // 62
    re: /.+@(.+){2,}\.(.+){2,}/,                                                                                       // 63
    errStr: 'Invalid email'                                                                                            // 64
}, {                                                                                                                   //
    _id: 'username_and_email',                                                                                         // 67
    type: 'text',                                                                                                      // 68
    required: true,                                                                                                    // 69
    displayName: "Login"                                                                                               // 70
}, pwd]);                                                                                                              //
                                                                                                                       //
AccountsTemplates.addField({                                                                                           // 75
    _id: "isgroup",                                                                                                    // 76
    type: "checkbox",                                                                                                  // 77
    displayName: "This is a group/organisational account"                                                              // 78
});                                                                                                                    //
                                                                                                                       //
AccountsTemplates.addFields([{                                                                                         // 81
    _id: "url",                                                                                                        // 82
    type: "text",                                                                                                      // 83
    displayName: "Home page"                                                                                           // 84
}, {                                                                                                                   //
    _id: "description",                                                                                                // 86
    type: "text",                                                                                                      // 87
    displayName: "A brief description of this account"                                                                 // 88
}]);                                                                                                                   //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"roles":{"_utils.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/roles/_utils.js                                                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
//register actions                                                                                                     //
Roles.registerAction("collections.entries.access", true);                                                              // 2
                                                                                                                       //
Roles.debug = true;                                                                                                    // 4
                                                                                                                       //
// check that the userId specified owns the documents                                                                  //
ownsDocument = function ownsDocument(userId, doc) {                                                                    // 7
    return doc && doc.publisher === userId || Roles.userHasRole(userId, "admin");                                      // 8
};                                                                                                                     //
                                                                                                                       //
ownsDocumentQuery = function ownsDocumentQuery() {                                                                     // 11
    return { publisher: this.userId };                                                                                 // 12
};                                                                                                                     //
                                                                                                                       //
viewsDocument = function (_viewsDocument) {                                                                            // 15
    function viewsDocument(_x, _x2) {                                                                                  //
        return _viewsDocument.apply(this, arguments);                                                                  //
    }                                                                                                                  //
                                                                                                                       //
    viewsDocument.toString = function () {                                                                             //
        return _viewsDocument.toString();                                                                              //
    };                                                                                                                 //
                                                                                                                       //
    return viewsDocument;                                                                                              //
}(function (userId, doc) {                                                                                             //
    if (!userId) {                                                                                                     // 16
        return doc.aclMeta;                                                                                            // 17
    }                                                                                                                  //
                                                                                                                       //
    if (doc) {                                                                                                         // 20
        return doc.aclMeta // publicly listed entries                                                                  // 21
         || ownsDocument(userId, doc) // own entries                                                                   //
         || doc.metaWhiteList && _.contains(doc.metaWhiteList, userId) // white-listed user                            //
         || Groups.find({ contentWhiteList: userId }).fetch().some(function (group) {                                  // 21
            return viewsDocument(group.publisher, doc);                                                                //
        }); // member of white-listed groups, for null userId returning true if group doesn't have contentWhhiteList property
    } else {                                                                                                           // 20
            return false;                                                                                              // 26
        }                                                                                                              //
});                                                                                                                    //
                                                                                                                       //
accessesDocument = function (_accessesDocument) {                                                                      // 30
    function accessesDocument(_x3, _x4) {                                                                              //
        return _accessesDocument.apply(this, arguments);                                                               //
    }                                                                                                                  //
                                                                                                                       //
    accessesDocument.toString = function () {                                                                          //
        return _accessesDocument.toString();                                                                           //
    };                                                                                                                 //
                                                                                                                       //
    return accessesDocument;                                                                                           //
}(function (userId, doc) {                                                                                             //
    if (!userId) {                                                                                                     // 31
        return doc.aclContent;                                                                                         // 32
    }                                                                                                                  //
                                                                                                                       //
    if (doc) {                                                                                                         // 35
        return doc.aclContent || ownsDocument(userId, doc) || doc.contentWhiteList && _.contains(doc.contentWhiteList, userId) || Groups.find({ contentWhiteList: userId }).fetch().some(function (group) {
            return accessesDocument(group.publisher, doc);                                                             //
        }); // member of white-listed groups                                                                           //
    } else {                                                                                                           // 35
            return false;                                                                                              // 41
        }                                                                                                              //
});                                                                                                                    //
                                                                                                                       //
viewsDocumentQuery = function viewsDocumentQuery(userId) {                                                             // 45
                                                                                                                       //
    //anonymous user default                                                                                           //
    var query = { $or: [{ aclMeta: true }] };                                                                          // 48
                                                                                                                       //
    //logged in user                                                                                                   //
    if (userId) {                                                                                                      // 45
        //admin user                                                                                                   //
        if (Roles.userHasRole(userId, "admin")) {                                                                      // 53
            query = { $or: [{}] };                                                                                     // 54
        } else {                                                                                                       //
            //individual or group user                                                                                 //
            query = { $or: [{ aclMeta: true }, { metaWhiteList: userId }, { publisher: userId }, { contentWhiteList: userId }] }; //individual permission
            var groups = Groups.find({ contentWhiteList: userId });                                                    // 55
            //group permission                                                                                         //
            groups.forEach(function (group) {                                                                          // 55
                query.$or.push({ metaWhiteList: group.publisher });                                                    // 61
            });                                                                                                        //
        }                                                                                                              //
    }                                                                                                                  //
                                                                                                                       //
    return query;                                                                                                      // 66
};                                                                                                                     //
                                                                                                                       //
isMemberQuery = function isMemberQuery() {                                                                             // 69
    return { contentWhiteList: this.userId };                                                                          // 70
};                                                                                                                     //
                                                                                                                       //
//set @Role's permission according to @colRules                                                                        //
//@colRules is of the form {collection_name: [allowed_field]}                                                          //
//if allowed_field is a string set permission to true                                                                  //
//if allowed_field is a function, compute permission using the function                                                //
setCollectionGrants = function setCollectionGrants(Role, colRules) {                                                   // 77
    for (var colName in meteorBabelHelpers.sanitizeForInObject(colRules)) {                                            // 78
        if (colRules.hasOwnProperty(colName)) {                                                                        // 79
            setRuleArray(Role, colName, colRules[colName]);                                                            // 80
        }                                                                                                              //
    }                                                                                                                  //
};                                                                                                                     //
                                                                                                                       //
function setRuleArray(Role, colName, fields) {                                                                         // 85
                                                                                                                       //
    for (var action in meteorBabelHelpers.sanitizeForInObject(fields)) {                                               // 87
        if (fields.hasOwnProperty(action)) {                                                                           // 88
            var field = fields[action];                                                                                // 89
                                                                                                                       //
            if (typeof field === 'string') {                                                                           // 91
                Role.allow('collections.' + colName + '.' + field, true);                                              // 92
            }                                                                                                          //
                                                                                                                       //
            if (typeof field === 'function') {                                                                         // 95
                Role.allow('collections.' + colName + '.' + action, field);                                            // 96
            }                                                                                                          //
        }                                                                                                              //
    }                                                                                                                  //
};                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"group.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/roles/group.js                                                                                                  //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    //
 * Created by xgfd on 24/12/2015.                                                                                      //
 */                                                                                                                    //
                                                                                                                       //
var Molecule = new Roles.Role('group'),                                                                                // 5
    grants = {                                                                                                         //
    entries: {                                                                                                         // 7
        access: function () {                                                                                          // 8
            function access(entry) {                                                                                   //
                return accessesDocument(this.userId, entry);                                                           // 9
            }                                                                                                          //
                                                                                                                       //
            return access;                                                                                             //
        }()                                                                                                            //
    },                                                                                                                 //
    groups: ['index', 'update', 'showUpdate'],                                                                         // 12
    datasets: ['index', 'insert', 'update', 'remove', 'showUpdate', 'showRemove'],                                     // 13
    apps: ['index', 'insert', 'update', 'remove', 'showUpdate', 'showRemove'],                                         // 14
    licenses: ['index', 'insert', 'update', 'remove', 'showCreate', 'showUpdate', 'showRemove'],                       // 15
    clients: ['index', 'insert', 'update', 'remove', 'showCreate', 'showUpdate', 'showRemove']                         // 16
};                                                                                                                     //
                                                                                                                       //
setCollectionGrants(Molecule, grants);                                                                                 // 19
                                                                                                                       //
Molecule.helper('collections.groups.indexFilter', ownsDocumentQuery);                                                  // 21
Molecule.helper('collections.datasets.indexFilter', ownsDocumentQuery);                                                // 22
Molecule.helper('collections.apps.indexFilter', ownsDocumentQuery);                                                    // 23
Molecule.helper('collections.clients.indexFilter', ownsDocumentQuery);                                                 // 24
Molecule.helper('collections.licenses.indexFilter', ownsDocumentQuery);                                                // 25
                                                                                                                       //
//forbidden fields                                                                                                     //
Molecule.helper('collections.datasets.forbiddenFields', omitFields);                                                   // 28
Molecule.helper('collections.apps.forbiddenFields', omitFields);                                                       // 29
Molecule.helper('collections.licenses.forbiddenFields', ['publisher', 'datePublished']);                               // 30
Molecule.helper('collections.clients.forbiddenFields', ['clientSecret', 'publisher', 'datePublished']);                // 31
//Molecule.helper('collections.comments.forbiddenFields', ['publisher', 'entryId', 'submitted']);                      //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"individual.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/roles/individual.js                                                                                             //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Options.set('defaultRoles', ['individual']);                                                                           // 1
/*                                                                                                                     //
 * First you must define the role                                                                                      //
 */                                                                                                                    //
var Atom = new Roles.Role('individual'),                                                                               // 5
    grants = {                                                                                                         //
    entries: {                                                                                                         // 7
        access: function () {                                                                                          // 8
            function access(entry) {                                                                                   //
                return accessesDocument(this.userId, entry);                                                           // 9
            }                                                                                                          //
                                                                                                                       //
            return access;                                                                                             //
        }()                                                                                                            //
    },                                                                                                                 //
    datasets: ['index', 'insert', 'update', 'remove', 'showUpdate', 'showRemove'],                                     // 12
    apps: ['index', 'insert', 'update', 'remove', 'showUpdate', 'showRemove'],                                         // 13
    clients: ['index', 'insert', 'update', 'remove', 'showCreate', 'showUpdate', 'showRemove'],                        // 14
    licenses: ['index', 'insert', 'update', 'remove', 'showCreate', 'showUpdate', 'showRemove'],                       // 15
    comments: ['index'],                                                                                               // 16
    groups: ['index']                                                                                                  // 17
};                                                                                                                     //
                                                                                                                       //
setCollectionGrants(Atom, grants);                                                                                     // 20
                                                                                                                       //
Atom.helper('collections.datasets.indexFilter', ownsDocumentQuery);                                                    // 22
Atom.helper('collections.apps.indexFilter', ownsDocumentQuery);                                                        // 23
Atom.helper('collections.clients.indexFilter', ownsDocumentQuery);                                                     // 24
Atom.helper('collections.licenses.indexFilter', ownsDocumentQuery);                                                    // 25
Atom.helper('collections.comments.indexFilter', ownsDocumentQuery);                                                    // 26
Atom.helper('collections.groups.indexFilter', isMemberQuery);                                                          // 27
                                                                                                                       //
//forbidden fields                                                                                                     //
Atom.helper('collections.datasets.forbiddenFields', omitFields);                                                       // 30
Atom.helper('collections.apps.forbiddenFields', omitFields);                                                           // 31
//Atom.helper('collections.licenses.forbiddenFields', ['publisher', 'datePublished']);                                 //
//Atom.helper('collections.clients.forbiddenFields', ['clientSecret', 'publisher', 'datePublished']);                  //
//Atom.helper('collections.comments.forbiddenFields', ['publisher', 'entryId', 'submitted']);                          //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"_utils.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/_utils.js                                                                                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    //
 * Created by xgfd on 15/01/2016.                                                                                      //
 */                                                                                                                    //
                                                                                                                       //
/*                                                                                                                     //
 * Extends @query with @or clause                                                                                      //
 * If @query.$or exists, replace it with $and:[{$or:query.$or}, or]                                                    //
 */                                                                                                                    //
extendOr = function extendOr(query, or) {                                                                              // 9
    check(query, Object);                                                                                              // 10
    check(or, { $or: Array });                                                                                         // 11
                                                                                                                       //
    if (query.$or) {                                                                                                   // 13
        query.$and = [{ $or: query.$or }, or];                                                                         // 14
        delete query.$or;                                                                                              // 15
    } else {                                                                                                           //
        _.extend(query, or);                                                                                           // 17
    }                                                                                                                  //
};                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"orion_config.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/orion_config.js                                                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    //
 * Created by xgfd on 20/05/2016.                                                                                      //
 */                                                                                                                    //
                                                                                                                       //
orion.config.add('wo_urls', 'WO', { type: [String], label: 'WO URLs' });                                               // 5
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"orion_dictionary.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/orion_dictionary.js                                                                                             //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
// orion.dictionary.addDefinition('image', 'comment',                                                                  //
//   orion.attribute('image', {                                                                                        //
//       label: 'Comment Image',                                                                                       //
//       optional: true                                                                                                //
//   })                                                                                                                //
// );                                                                                                                  //
                                                                                                                       //
orion.dictionary.addDefinition('title', 'mainPage', {                                                                  // 8
    type: String,                                                                                                      // 9
    label: 'Site Title',                                                                                               // 10
    optional: false,                                                                                                   // 11
    min: 1,                                                                                                            // 12
    max: 40                                                                                                            // 13
});                                                                                                                    //
                                                                                                                       //
orion.dictionary.addDefinition('description', 'mainPage', {                                                            // 16
    type: String,                                                                                                      // 17
    label: 'Site Description',                                                                                         // 18
    optional: true                                                                                                     // 19
});                                                                                                                    //
                                                                                                                       //
orion.dictionary.addDefinition('termsAndConditions', 'submitPostPage', {                                               // 23
    type: String,                                                                                                      // 24
    label: 'Terms and Conditions',                                                                                     // 25
    optional: true                                                                                                     // 26
});                                                                                                                    //
                                                                                                                       //
//ldap                                                                                                                 //
var ldapSchema = new SimpleSchema({                                                                                    // 31
    domain: { type: String },                                                                                          // 32
    serverDn: { type: String, label: 'Server DN' },                                                                    // 33
    serverUrl: { type: String, label: 'Server Url' },                                                                  // 34
    whiteListedFields: { type: String, label: 'Included fields' }                                                      // 35
});                                                                                                                    //
                                                                                                                       //
orion.dictionary.addDefinition('ldap', 'ldap', { type: [ldapSchema] });                                                // 38
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"orion_filesystem.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/orion_filesystem.js                                                                                             //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
///**                                                                                                                  //
// * Official S3 Upload Provider                                                                                       //
// *                                                                                                                   //
// * Please replace this function with the                                                                             //
// * provider you prefer.                                                                                              //
// *                                                                                                                   //
// * If success, call success(publicUrl);                                                                              //
// * you can pass data and it will be saved in file.meta                                                               //
// * Ej: success(publicUrl, {local_path: '/user/path/to/file'})                                                        //
// *                                                                                                                   //
// * If it fails, call failure(error).                                                                                 //
// *                                                                                                                   //
// * When the progress change, call progress(newProgress)                                                              //
// */                                                                                                                  //
//orion.filesystem.providerUpload = function(options, success, failure, progress) {                                    //
//  S3.upload({                                                                                                        //
//    files: options.fileList,                                                                                         //
//    path: 'orionjs',                                                                                                 //
//  }, function(error, result) {                                                                                       //
//    debugger                                                                                                         //
//    if (error) {                                                                                                     //
//      failure(error);                                                                                                //
//    } else {                                                                                                         //
//      success(result.secure_url, { s3Path: result.relative_url });                                                   //
//      result;                                                                                                        //
//      debugger                                                                                                       //
//    }                                                                                                                //
//    S3.collection.remove({})                                                                                         //
//  });                                                                                                                //
//  Tracker.autorun(function () {                                                                                      //
//    let file = S3.collection.findOne();                                                                              //
//    if (file) {                                                                                                      //
//      progress(file.percent_uploaded);                                                                               //
//    }                                                                                                                //
//  });                                                                                                                //
//};                                                                                                                   //
//                                                                                                                     //
///**                                                                                                                  //
// * Official S3 Remove Provider                                                                                       //
// *                                                                                                                   //
// * Please replace this function with the                                                                             //
// * provider you prefer.                                                                                              //
// *                                                                                                                   //
// * If success, call success();                                                                                       //
// * If it fails, call failure(error).                                                                                 //
// */                                                                                                                  //
//orion.filesystem.providerRemove = function(file, success, failure)  {                                                //
//  S3.delete(file.meta.s3Path, function(error, result) {                                                              //
//    if (error) {                                                                                                     //
//      failure(error);                                                                                                //
//    } else {                                                                                                         //
//      success();                                                                                                     //
//    }                                                                                                                //
//  })                                                                                                                 //
//};                                                                                                                   //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"router.js":["babel-runtime/helpers/toConsumableArray",function(require){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/router.js                                                                                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var _toConsumableArray2 = require('babel-runtime/helpers/toConsumableArray');                                          //
                                                                                                                       //
var _toConsumableArray3 = _interopRequireDefault(_toConsumableArray2);                                                 //
                                                                                                                       //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }                      //
                                                                                                                       //
Router.configure({                                                                                                     // 1
    layoutTemplate: 'layout',                                                                                          // 2
    loadingTemplate: 'loading',                                                                                        // 3
    notFoundTemplate: 'notFound',                                                                                      // 4
    subscriptions: function () {                                                                                       // 5
        function subscriptions() {                                                                                     //
            //using waitOn will cause entry_list to reload every time load-more is clicked                             //
            return [Meteor.subscribe(Notifications._name), Meteor.subscribe(Groups._name), Meteor.subscribe(Meteor.users._name), Meteor.subscribe(Licenses._name)];
        }                                                                                                              //
                                                                                                                       //
        return subscriptions;                                                                                          //
    }()                                                                                                                //
});                                                                                                                    //
                                                                                                                       //
ListController = RouteController.extend({                                                                              // 15
    template: 'entryList',                                                                                             // 16
    increment: 12,                                                                                                     // 17
    //query modifier generation helper                                                                                 //
    entriesLimit: function () {                                                                                        // 19
        function entriesLimit() {                                                                                      //
            return parseInt(this.params.entriesLimit) || this.increment;                                               // 20
        }                                                                                                              //
                                                                                                                       //
        return entriesLimit;                                                                                           //
    }(),                                                                                                               //
                                                                                                                       //
    //query modifier generator                                                                                         //
    findOptions: function () {                                                                                         // 23
        function findOptions() {                                                                                       //
            return { sort: this.sort, limit: this.entriesLimit() };                                                    // 24
        }                                                                                                              //
                                                                                                                       //
        return findOptions;                                                                                            //
    }(),                                                                                                               //
                                                                                                                       //
    //query generator                                                                                                  //
    findSelector: function () {                                                                                        // 27
        function findSelector() {                                                                                      //
            var textFilter = search(Session.get('search'));                                                            // 28
            var query = {},                                                                                            // 29
                _query = this.params.query;                                                                            //
                                                                                                                       //
            _.keys(_query).forEach(function (key) {                                                                    // 31
                console.log(key);                                                                                      // 32
                switch (key) {                                                                                         // 33
                    case 'online':                                                                                     // 34
                    case 'aclMeta':                                                                                    // 35
                    case 'aclContent':                                                                                 // 36
                        query[key] = _query[key].toLowerCase() === 'true';                                             // 37
                        break;                                                                                         // 38
                    default:                                                                                           // 33
                        query[key] = _query[key];                                                                      // 40
                }                                                                                                      // 33
            });                                                                                                        //
                                                                                                                       //
            _.extend(query, textFilter);                                                                               // 44
                                                                                                                       //
            ////this function runs twice due to reactivity (subscriptions)                                             //
            ////set findSelector to return the computed query straight away                                            //
            ////in the second run                                                                                      //
            //this.findSelector = function () {                                                                        //
            //    return query;                                                                                        //
            //}                                                                                                        //
            return query;                                                                                              // 27
        }                                                                                                              //
                                                                                                                       //
        return findSelector;                                                                                           //
    }(),                                                                                                               //
                                                                                                                       //
    //collection of entries (e.g. Apps, Datasets)                                                                      //
    category: null, //overrided in sub controllers                                                                     // 55
    //displayed entries                                                                                                //
    entries: function () {                                                                                             // 57
        function entries() {                                                                                           //
            return this.category.find({}, { sort: this.findOptions.sort });                                            // 58
        }                                                                                                              //
                                                                                                                       //
        return entries;                                                                                                //
    }(),                                                                                                               //
                                                                                                                       //
    // helper to generate route names of a given category;                                                             //
    // a workaround since cannot dynamically concatenate variables in templates                                        //
    routes: function () {                                                                                              // 62
        function routes() {                                                                                            //
            var cat = arguments.length <= 0 || arguments[0] === undefined ? this.category.singularName : arguments[0];
                                                                                                                       //
            return ['latest', 'page', 'submit', 'edit'].reduce(function (routes, action) {                             // 63
                routes[action] = cat + '.' + action;                                                                   // 64
                return routes;                                                                                         // 65
            }, {});                                                                                                    //
        }                                                                                                              //
                                                                                                                       //
        return routes;                                                                                                 //
    }(),                                                                                                               //
    data: function () {                                                                                                // 68
        function data() {                                                                                              //
            var self = this;                                                                                           // 69
            return {                                                                                                   // 70
                category: self.category,                                                                               // 71
                entries: self.entries(),                                                                               // 72
                //show search bar in top nav on entry list page                                                        //
                showSearch: true,                                                                                      // 74
                //show Add button if logged in                                                                         //
                showAdd: true,                                                                                         // 76
                ready: self.ready.bind(self),                                                                          // 77
                routes: self.routes(),                                                                                 // 78
                //generate path to load next page of entries                                                           //
                nextPath: function () {                                                                                // 80
                    function nextPath() {                                                                              //
                        if (self.category.find().count() === self.entriesLimit()) {                                    // 81
                            return self.nextPath();                                                                    // 82
                        }                                                                                              //
                    }                                                                                                  //
                                                                                                                       //
                    return nextPath;                                                                                   //
                }()                                                                                                    //
            };                                                                                                         //
        }                                                                                                              //
                                                                                                                       //
        return data;                                                                                                   //
    }()                                                                                                                //
});                                                                                                                    //
                                                                                                                       //
RegExp.prototype.toJSONValue = function () {                                                                           // 89
    var flags = '';                                                                                                    // 90
    if (this.global) {                                                                                                 // 91
        flags += 'g';                                                                                                  // 92
    }                                                                                                                  //
    if (this.ignoreCase) {                                                                                             // 94
        flags += 'i';                                                                                                  // 95
    }                                                                                                                  //
    if (this.multiline) {                                                                                              // 97
        flags += 'm';                                                                                                  // 98
    }                                                                                                                  //
    return [this.source, flags];                                                                                       // 100
};                                                                                                                     //
                                                                                                                       //
RegExp.prototype.typeName = function () {                                                                              // 103
    return "regex";                                                                                                    // 104
};                                                                                                                     //
                                                                                                                       //
EJSON.addType("regex", function (str) {                                                                                // 107
    return new (Function.prototype.bind.apply(RegExp, [null].concat((0, _toConsumableArray3['default'])(str))))();     // 108
});                                                                                                                    //
                                                                                                                       //
function search(searchText) {                                                                                          // 111
    var selector = void 0;                                                                                             // 112
    if (searchText) {                                                                                                  // 113
        var regExp = buildRegExp(searchText);                                                                          // 114
        selector = {                                                                                                   // 115
            $or: [{ name: regExp }, { description: regExp }, { 'distribution.fileFormat': regExp }]                    // 116
        };                                                                                                             //
    } else {                                                                                                           //
        selector = {};                                                                                                 // 123
    }                                                                                                                  //
                                                                                                                       //
    return selector;                                                                                                   // 126
}                                                                                                                      //
                                                                                                                       //
//any position                                                                                                         //
function buildRegExp(searchText) {                                                                                     // 130
    var parts = searchText.trim().split(/[ \-\:]+/);                                                                   // 131
    return new RegExp("(" + parts.join('|') + ")", "ig");                                                              // 132
}                                                                                                                      //
                                                                                                                       //
//type ahead                                                                                                           //
//function buildRegExp(searchText) {                                                                                   //
//    let words = searchText.trim().split(/[ \-\:]+/);                                                                 //
//    let exps = _.map(words, function (word) {                                                                        //
//        return "(?=.*" + word + ")";                                                                                 //
//    });                                                                                                              //
//    let fullExp = exps.join('') + ".+";                                                                              //
//    return new RegExp(fullExp, "i");                                                                                 //
//}                                                                                                                    //
/***************************                                                                                           //
 * entry list                                                                                                          //
 **************************/                                                                                           //
LatestController = ListController.extend({                                                                             // 147
    subscriptions: function () {                                                                                       // 148
        function subscriptions() {                                                                                     //
            return Meteor.subscribe(this.category._name, this.findOptions(), this.findSelector());                     // 149
        }                                                                                                              //
                                                                                                                       //
        return subscriptions;                                                                                          //
    }(),                                                                                                               //
                                                                                                                       //
    sort: { datePublished: -1, votes: -1, downvotes: 1, _id: -1 },                                                     // 151
    nextPath: function () {                                                                                            // 152
        function nextPath() {                                                                                          //
            return Router.routes[this.category.singularName + '.latest'].path({ entriesLimit: this.entriesLimit() + this.increment });
        }                                                                                                              //
                                                                                                                       //
        return nextPath;                                                                                               //
    }()                                                                                                                //
});                                                                                                                    //
                                                                                                                       //
DatasetLatestController = LatestController.extend({                                                                    // 157
    category: Datasets                                                                                                 // 158
});                                                                                                                    //
                                                                                                                       //
RemotedatasetLatestController = LatestController.extend({                                                              // 161
    category: RemoteDatasets                                                                                           // 162
});                                                                                                                    //
                                                                                                                       //
AppLatestController = LatestController.extend({                                                                        // 165
    category: Apps                                                                                                     // 166
});                                                                                                                    //
                                                                                                                       //
RemoteappLatestController = LatestController.extend({                                                                  // 169
    category: RemoteApps                                                                                               // 170
});                                                                                                                    //
                                                                                                                       //
GroupLatestController = LatestController.extend({                                                                      // 173
    category: Groups,                                                                                                  // 174
    nextPath: function () {                                                                                            // 175
        function nextPath() {                                                                                          //
            return Router.routes['group.latest'].path({ entriesLimit: this.entriesLimit() + this.increment });         // 176
        }                                                                                                              //
                                                                                                                       //
        return nextPath;                                                                                               //
    }()                                                                                                                //
});                                                                                                                    //
/***************************                                                                                           //
 * entry page                                                                                                          //
 **************************/                                                                                           //
PageController = ListController.extend({                                                                               // 182
    template: 'entryPage',                                                                                             // 183
    subscriptions: function () {                                                                                       // 184
        function subscriptions() {                                                                                     //
            return [Meteor.subscribe('comments', this.params._id), Meteor.subscribe(this.category.singularName, this.params._id)];
        }                                                                                                              //
                                                                                                                       //
        return subscriptions;                                                                                          //
    }(),                                                                                                               //
    data: function () {                                                                                                // 188
        function data() {                                                                                              //
            return {                                                                                                   // 189
                comments: Comments.find({ entryId: this.params._id }),                                                 // 190
                category: this.category,                                                                               // 191
                entry: this.category.findOne(this.params._id),                                                         // 192
                routes: this.routes(this.category.singularName)                                                        // 193
            };                                                                                                         //
        }                                                                                                              //
                                                                                                                       //
        return data;                                                                                                   //
    }()                                                                                                                //
});                                                                                                                    //
                                                                                                                       //
//_isTemplated:true,                                                                                                   //
DatasetPageController = PageController.extend({                                                                        // 199
    category: Datasets                                                                                                 // 200
});                                                                                                                    //
                                                                                                                       //
RemotedatasetPageController = PageController.extend({                                                                  // 203
    category: RemoteDatasets                                                                                           // 204
});                                                                                                                    //
                                                                                                                       //
AppPageController = PageController.extend({                                                                            // 207
    category: Apps                                                                                                     // 208
});                                                                                                                    //
                                                                                                                       //
RemoteappPageController = PageController.extend({                                                                      // 211
    category: RemoteApps                                                                                               // 212
});                                                                                                                    //
                                                                                                                       //
GroupPageController = PageController.extend({                                                                          // 215
    category: Groups                                                                                                   // 216
});                                                                                                                    //
                                                                                                                       //
function templateData(router, col, option) {                                                                           // 219
    return {                                                                                                           // 220
        category: col,                                                                                                 // 221
        routes: router.routes(col.singularName),                                                                       // 222
        entries: router.getEntries(option, col),                                                                       // 223
        ready: router.ready.bind(router)                                                                               // 224
    };                                                                                                                 //
}                                                                                                                      //
                                                                                                                       //
HomeController = ListController.extend({                                                                               // 228
    template: 'home',                                                                                                  // 229
    increment: 8,                                                                                                      // 230
    sort: { votes: -1, downvotes: 1, datePublished: -1, _id: -1 },                                                     // 231
    subscriptions: function () {                                                                                       // 232
        function subscriptions() {                                                                                     //
            var _this = this;                                                                                          //
                                                                                                                       //
            return [Datasets, Apps, RemoteDatasets, RemoteApps].map(function (col) {                                   // 233
                return Meteor.subscribe(col._name, _this.findOptions());                                               //
            });                                                                                                        //
        }                                                                                                              //
                                                                                                                       //
        return subscriptions;                                                                                          //
    }(),                                                                                                               //
    getEntries: function () {                                                                                          // 236
        function getEntries(options, col) {                                                                            //
            if (!options) options = this.findOptions();                                                                // 237
            return col.find({}, options);                                                                              // 239
        }                                                                                                              //
                                                                                                                       //
        return getEntries;                                                                                             //
    }(),                                                                                                               //
    nextPath: function () {                                                                                            // 241
        function nextPath() {                                                                                          //
            return Router.routes['datasets.latest'].path({ entriesLimit: this.entriesLimit() + this.increment });      // 242
        }                                                                                                              //
                                                                                                                       //
        return nextPath;                                                                                               //
    }(),                                                                                                               //
    data: function () {                                                                                                // 244
        function data() {                                                                                              //
            var homeTempData = templateData.bind(null, this);                                                          // 245
            var byPubData = { sort: { datePublished: -1 }, limit: 8 },                                                 // 246
                byVote = { sort: { votes: -1 }, limit: 8 };                                                            //
            // let self = this;                                                                                        //
            return {                                                                                                   // 244
                recentDataset: homeTempData(Datasets, byPubData),                                                      // 250
                recentApp: homeTempData(Apps, byPubData),                                                              // 251
                dataset: homeTempData(Datasets, byVote),                                                               // 252
                app: homeTempData(Apps, byVote),                                                                       // 253
                remoteApp: homeTempData(RemoteApps, byPubData),                                                        // 254
                remoteDataset: homeTempData(RemoteDatasets, byPubData),                                                // 255
                _isHome: true,                                                                                         // 256
                _isTemplated: true                                                                                     // 257
            };                                                                                                         //
        }                                                                                                              //
                                                                                                                       //
        return data;                                                                                                   //
    }()                                                                                                                //
});                                                                                                                    //
                                                                                                                       //
/****************************************************************                                                      //
 * Routes                                                                                                              //
 * Route naming schema {{coll.singularName}}.{{action}}                                                                //
 *****************************************************************/                                                    //
                                                                                                                       //
/*                                                                                                                     //
 * Home                                                                                                                //
 */                                                                                                                    //
                                                                                                                       //
Router.route('/', { name: 'home' });                                                                                   // 271
                                                                                                                       //
function setUpRoutes(col) {                                                                                            // 273
    var hasRemote = arguments.length <= 1 || arguments[1] === undefined ? false : arguments[1];                        //
                                                                                                                       //
    var sn = col.singularName,                                                                                         // 274
        pn = col.pluralName;                                                                                           //
                                                                                                                       //
    Router.route('/new/' + pn + '/:entriesLimit?', { name: sn + '.latest' });                                          // 276
                                                                                                                       //
    Router.route('/' + pn + '/submit', {                                                                               // 278
        template: 'entrySubmit',                                                                                       // 279
        name: sn + '.submit',                                                                                          // 280
        data: function () {                                                                                            // 281
            function data() {                                                                                          //
                return { category: col, col: pn.substr(0, 1).toUpperCase() + pn.substr(1) };                           // 282
            }                                                                                                          //
                                                                                                                       //
            return data;                                                                                               //
        }()                                                                                                            //
    });                                                                                                                //
                                                                                                                       //
    Router.route('/' + pn + '/:_id', { name: sn + '.page' });                                                          // 286
                                                                                                                       //
    Router.route('/' + pn + '/:_id/edit', {                                                                            // 288
        name: sn + '.edit',                                                                                            // 289
        template: 'entryEdit',                                                                                         // 290
        waitOn: function () {                                                                                          // 291
            function waitOn() {                                                                                        //
                return Meteor.subscribe('single' + sn, this.params._id);                                               // 292
            }                                                                                                          //
                                                                                                                       //
            return waitOn;                                                                                             //
        }(),                                                                                                           //
        data: function () {                                                                                            // 294
            function data() {                                                                                          //
                return {                                                                                               // 295
                    category: col,                                                                                     // 296
                    entry: col.findOne()                                                                               // 297
                };                                                                                                     //
            }                                                                                                          //
                                                                                                                       //
            return data;                                                                                               //
        }()                                                                                                            //
    });                                                                                                                //
                                                                                                                       //
    if (hasRemote) {                                                                                                   // 302
        Router.route('/new/remote_' + pn + '/:entriesLimit?', { name: 'remote' + sn + '.latest' });                    // 303
        Router.route('/remote_' + pn + '/:_id', { name: 'remote' + sn + '.page' });                                    // 304
    }                                                                                                                  //
}                                                                                                                      //
                                                                                                                       //
/*                                                                                                                     //
 * Datasets routes                                                                                                     //
 */                                                                                                                    //
setUpRoutes(Datasets, true);                                                                                           // 311
                                                                                                                       //
/*                                                                                                                     //
 * Apps routes                                                                                                         //
 */                                                                                                                    //
setUpRoutes(Apps, true);                                                                                               // 316
                                                                                                                       //
/*                                                                                                                     //
 * Groups                                                                                                              //
 */                                                                                                                    //
                                                                                                                       //
setUpRoutes(Groups);                                                                                                   // 322
                                                                                                                       //
/*                                                                                                                     //
 * Accounts                                                                                                            //
 */                                                                                                                    //
                                                                                                                       //
AccountsTemplates.configureRoute('changePwd');                                                                         // 328
AccountsTemplates.configureRoute('enrollAccount');                                                                     // 329
AccountsTemplates.configureRoute('forgotPwd');                                                                         // 330
AccountsTemplates.configureRoute('resetPwd');                                                                          // 331
AccountsTemplates.configureRoute('signIn');                                                                            // 332
AccountsTemplates.configureRoute('signUp');                                                                            // 333
AccountsTemplates.configureRoute('verifyEmail');                                                                       // 334
                                                                                                                       //
/*                                                                                                                     //
 * Helpers                                                                                                             //
 */                                                                                                                    //
function requireLogin() {                                                                                              // 339
    if (!Meteor.user()) {                                                                                              // 340
        if (Meteor.loggingIn()) {                                                                                      // 341
            this.render(this.loadingTemplate);                                                                         // 342
        } else {                                                                                                       //
            this.render('accessDenied', { data: 'Please sign in.' });                                                  // 344
        }                                                                                                              //
    } else {                                                                                                           //
        this.next();                                                                                                   // 347
    }                                                                                                                  //
}                                                                                                                      //
                                                                                                                       //
//Router.onBeforeAction('dataNotFound', {only: 'dataset.page'});                                                       //
Router.onBeforeAction(requireLogin, { only: ['dataset.submit', 'dataset.edit', 'app.submit', 'app.edit'] });           // 352
                                                                                                                       //
Router.onBeforeAction(function () {                                                                                    // 354
    var _data = this.data();                                                                                           //
                                                                                                                       //
    var entry = _data.entry;                                                                                           //
    var category = _data.category;                                                                                     //
                                                                                                                       //
    if (Meteor.userId() && entry //should not be necessary                                                             // 356
     && ownsDocument(Meteor.userId(), entry)) {                                                                        //
        this.next();                                                                                                   // 358
    } else {                                                                                                           //
        this.render('accessDenied', { data: "You cannot edit others' " + category.singularName });                     // 360
    }                                                                                                                  //
}, { only: ['dataset.edit', 'app.edit'] });                                                                            //
                                                                                                                       //
Router.onBeforeAction(function () {                                                                                    // 364
    //using named function causes an error                                                                             //
                                                                                                                       //
    var _data2 = this.data();                                                                                          //
                                                                                                                       //
    var entry = _data2.entry;                                                                                          //
    var category = _data2.category;                                                                                    //
                                                                                                                       //
    if (!entry) {                                                                                                      // 366
        this.render('loading');                                                                                        // 367
    } else {                                                                                                           //
        if (viewsDocument(Meteor.userId(), entry)) {                                                                   // 369
            this.next();                                                                                               // 370
        } else {                                                                                                       //
            this.render('accessDenied', { data: "You cannot view this " + category.singularName });                    // 372
        }                                                                                                              //
    }                                                                                                                  //
}, { only: ['dataset.page', 'app.page'] });                                                                            //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"server":{"methods":{"accounts.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/methods/accounts.js                                                                                          //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    //
 * Created by xgfd on 25/12/2015.                                                                                      //
 */                                                                                                                    //
//Accounts.onCreateUser(function (options, user) {                                                                     //
//    let profile = options.profile;                                                                                   //
//    if (profile) {                                                                                                   //
//        if (profile.isgroup) {                                                                                       //
//            delete profile.isgroup;                                                                                  //
//            user.isGroup = Groups.insert({publisher: user._id, name: profile.name});                                 //
//            Roles.removeUserFromRoles( user._id, ["individual"] );                                                   //
//            Roles.addUserToRoles( user._id ,  ["group"] );                                                           //
//        }                                                                                                            //
//        user.profile = options.profile;                                                                              //
//    }                                                                                                                //
//    return user;                                                                                                     //
//});                                                                                                                  //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"comments.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/methods/comments.js                                                                                          //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    //
 * Created by xgfd on 13/01/2016.                                                                                      //
 */                                                                                                                    //
                                                                                                                       //
Meteor.methods({                                                                                                       // 5
    commentInsert: function () {                                                                                       // 6
        function commentInsert(commentAttributes, category) {                                                          // 6
            check(this.userId, String);                                                                                // 7
            check(category, Mongo.Collection);                                                                         // 8
            check(category.singularName, Match.OneOf('dataset', 'app'));                                               // 9
            check(commentAttributes, {                                                                                 // 10
                entryId: String,                                                                                       // 11
                body: String                                                                                           // 12
            });                                                                                                        //
                                                                                                                       //
            entry = category.findOne(commentAttributes.entryId);                                                       // 15
                                                                                                                       //
            if (!entry) throw new Meteor.Error('invalid-comment', 'You must comment on ' + category);                  // 17
                                                                                                                       //
            comment = _.extend(commentAttributes, {                                                                    // 20
                publisher: this.userId,                                                                                // 21
                category: category.singularName,                                                                       // 22
                //author: user.username,                                                                               //
                submitted: new Date()                                                                                  // 24
            });                                                                                                        //
                                                                                                                       //
            // update the post with the number of comments                                                             //
            category.update(comment.entryId, { $inc: { commentsCount: 1 } });                                          // 6
                                                                                                                       //
            // create the comment, save the id                                                                         //
            comment._id = Comments.insert(comment);                                                                    // 6
                                                                                                                       //
            // now create a notification, informing the user that there's been a comment                               //
            createCommentNotification(comment, category);                                                              // 6
                                                                                                                       //
            return comment._id;                                                                                        // 36
        }                                                                                                              //
                                                                                                                       //
        return commentInsert;                                                                                          //
    }()                                                                                                                //
});                                                                                                                    //
                                                                                                                       //
function createCommentNotification(comment, category) {                                                                // 40
    check(comment, Object);                                                                                            // 41
    check(category, Mongo.Collection);                                                                                 // 42
    check(category.singularName, Match.OneOf('dataset', 'app'));                                                       // 43
                                                                                                                       //
    var entryId = comment.entryId,                                                                                     // 45
        entry = category.findOne(entryId),                                                                             //
        initiatorId = comment.publisher;                                                                               //
                                                                                                                       //
    var path = Router.routes[category.singularName + '.page'].path({ _id: entryId });                                  // 49
    var message = '<a href="' + path + '"> <strong>' + Meteor.users.findOne(initiatorId).username + '</strong> commented on your post </a>';
                                                                                                                       //
    if (initiatorId !== entry.publisher) {                                                                             // 52
        createNotification(initiatorId, entryId, entry.name, entry.publisher, category.singularName, message);         // 53
    }                                                                                                                  //
};                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"creative_work.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/methods/creative_work.js                                                                                     //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    //
 * Created by xgfd on 26/12/2015.                                                                                      //
 */                                                                                                                    //
                                                                                                                       //
Meteor.methods({                                                                                                       // 5
    //datasetInsert: function (datasetAttributes) {                                                                    //
    //    check(this.userId, String);                                                                                  //
    //    check(datasetAttributes, {                                                                                   //
    //        name: String,                                                                                            //
    //        //url: String                                                                                            //
    //    });                                                                                                          //
    //                                                                                                                 //
    //    let errors = validateDataset(datasetAttributes);                                                             //
    //    if (errors.name || errors.distribution)                                                                      //
    //        throw new Meteor.Error('invalid-dataset', "You must set a name and distribution for your dataset");      //
    //                                                                                                                 //
    //    //let datasetWithSameLink = Datasets.findOne({"distribution.url": datasetAttributes.distribution.url});      //
    //    //if (datasetWithSameLink) {                                                                                 //
    //    //    return {                                                                                               //
    //    //        postExists: true,                                                                                  //
    //    //        _id: datasetWithSameLink._id                                                                       //
    //    //    }                                                                                                      //
    //    //}                                                                                                          //
    //                                                                                                                 //
    //    let user = Meteor.user();                                                                                    //
    //    let dataset = _.extend(datasetAttributes, {                                                                  //
    //        publisher: user._id,                                                                                     //
    //        commentsCount: 0,                                                                                        //
    //        upvoters: [],                                                                                            //
    //        votes: 0                                                                                                 //
    //    });                                                                                                          //
    //                                                                                                                 //
    //    let datasetId = Datasets.insert(dataset);                                                                    //
    //                                                                                                                 //
    //    return {                                                                                                     //
    //        _id: datasetId                                                                                           //
    //    };                                                                                                           //
    //},                                                                                                               //
                                                                                                                       //
    upvote: function () {                                                                                              // 40
        function upvote(entryId, category) {                                                                           //
            check(this.userId, String);                                                                                // 41
            check(entryId, String);                                                                                    // 42
            check(category, Mongo.Collection);                                                                         // 43
            check(category.singularName, Match.OneOf('dataset', 'app'));                                               // 44
                                                                                                                       //
            var affected = category.update({                                                                           // 46
                _id: entryId,                                                                                          // 47
                upvoters: { $ne: this.userId }                                                                         // 48
            }, {                                                                                                       //
                $addToSet: { upvoters: this.userId },                                                                  // 50
                $inc: { votes: 1 }                                                                                     // 51
            });                                                                                                        //
                                                                                                                       //
            if (!affected) throw new Meteor.Error('invalid', "You weren't able to upvote that entry");                 // 54
        }                                                                                                              //
                                                                                                                       //
        return upvote;                                                                                                 //
    }(),                                                                                                               //
    downvote: function () {                                                                                            // 57
        function downvote(entryId, category) {                                                                         //
            check(this.userId, String);                                                                                // 58
            check(entryId, String);                                                                                    // 59
            check(category, Mongo.Collection);                                                                         // 60
            check(category.singularName, Match.OneOf('dataset', 'app'));                                               // 61
                                                                                                                       //
            var affected = category.update({                                                                           // 63
                _id: entryId,                                                                                          // 64
                downvoters: { $ne: this.userId }                                                                       // 65
            }, {                                                                                                       //
                $addToSet: { downvoters: this.userId },                                                                // 67
                $inc: { downvotes: 1 }                                                                                 // 68
            });                                                                                                        //
                                                                                                                       //
            if (!affected) throw new Meteor.Error('invalid', "You weren't able to upvote that entry");                 // 71
        }                                                                                                              //
                                                                                                                       //
        return downvote;                                                                                               //
    }()                                                                                                                //
});                                                                                                                    //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"distributions.js":["babel-runtime/helpers/typeof",function(require){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/methods/distributions.js                                                                                     //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var _typeof2 = require('babel-runtime/helpers/typeof');                                                                //
                                                                                                                       //
var _typeof3 = _interopRequireDefault(_typeof2);                                                                       //
                                                                                                                       //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }                      //
                                                                                                                       //
/**                                                                                                                    //
 * Created by xgfd on 02/01/2016.                                                                                      //
 */                                                                                                                    //
var connPool = {};                                                                                                     // 4
                                                                                                                       //
function augsTrans(url, username, pass) {                                                                              // 6
                                                                                                                       //
    if (arguments.length === 1) {                                                                                      // 8
        if (!url.match(/^.*:\/\//)) {                                                                                  // 9
            var distId = url,                                                                                          // 10
                dist = Datasets.findOne({ 'distribution._id': distId }, { fields: { distribution: { $elemMatch: { _id: distId } } } }).distribution[0];
                                                                                                                       //
            if (dist) {                                                                                                // 13
                url = dist.url;                                                                                        // 14
                if (dist.profile) {                                                                                    // 15
                    var _dist$profile = dist.profile;                                                                  //
                    username = _dist$profile.username;                                                                 // 16
                    pass = _dist$profile.pass;                                                                         // 16
                }                                                                                                      //
            } else {                                                                                                   //
                throw new Meteor.Error('not-found', 'Distribution ' + distId + ' not found');                          // 19
            }                                                                                                          //
        }                                                                                                              //
    }                                                                                                                  //
                                                                                                                       //
    return { url: url, username: username, pass: pass };                                                               // 24
}                                                                                                                      //
                                                                                                                       //
function connectorFactory(connect) {                                                                                   // 27
    return function (url, username, pass) {                                                                            // 28
        var id = url;                                                                                                  // 29
                                                                                                                       //
        var _augsTrans$apply = augsTrans.apply(null, arguments);                                                       //
                                                                                                                       //
        url = _augsTrans$apply.url;                                                                                    // 31
        username = _augsTrans$apply.username;                                                                          // 31
        pass = _augsTrans$apply.pass;                                                                                  // 31
                                                                                                                       //
        var _Async$runSync = Async.runSync(function (done) {                                                           //
            connect(url, username, pass, done);                                                                        // 34
        });                                                                                                            //
                                                                                                                       //
        var error = _Async$runSync.error;                                                                              //
        var result = _Async$runSync.result;                                                                            //
                                                                                                                       //
                                                                                                                       //
        if (error) {                                                                                                   // 37
            throw new Meteor.Error(error.name, error.message);                                                         // 38
        } else {                                                                                                       //
            connPool[id] = result;                                                                                     // 40
            return true;                                                                                               // 41
        }                                                                                                              //
    };                                                                                                                 //
}                                                                                                                      //
                                                                                                                       //
/*                                                                                                                     //
 * @connector(distId) create an db connection and save it to dbPool                                                    //
 * @queryExec(db, done, ...args) query execution function. result is passed to done(error, result)                     //
 * */                                                                                                                  //
function queryerFactory(connector, queryExec) {                                                                        // 50
    return function (distId) {                                                                                         // 51
        for (var _len = arguments.length, args = Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {      //
            args[_key - 1] = arguments[_key];                                                                          //
        }                                                                                                              //
                                                                                                                       //
        var conn = connPool[distId];                                                                                   // 52
                                                                                                                       //
        if (!conn) {                                                                                                   // 54
            try {                                                                                                      // 55
                connector(distId);                                                                                     // 56
            } catch (e) {                                                                                              //
                Datasets.update({ distribution: { $elemMatch: { _id: distId } } }, { $set: { 'distribtuion.$.online': false } });
                throw e;                                                                                               // 60
            }                                                                                                          //
        }                                                                                                              //
                                                                                                                       //
        conn = connPool[distId];                                                                                       // 64
                                                                                                                       //
        if (!conn) {                                                                                                   // 66
            Datasets.update({ distribution: { $elemMatch: { _id: distId } } }, { $set: { 'distribtuion.$.online': false } });
            throw new Meteor.Error('not-found', 'Distribution ' + distId + ' not initialised');                        // 68
        }                                                                                                              //
                                                                                                                       //
        var _Async$runSync2 = Async.runSync(function (done) {                                                          //
            queryExec.apply(undefined, [conn, done].concat(args));                                                     // 72
        });                                                                                                            //
                                                                                                                       //
        var error = _Async$runSync2.error;                                                                             //
        var result = _Async$runSync2.result;                                                                           //
                                                                                                                       //
                                                                                                                       //
        if (error) {                                                                                                   // 75
            Datasets.update({ distribution: { $elemMatch: { _id: distId } } }, { $set: { 'distribtuion.$.online': false } });
            throw new Meteor.Error(error.name, error.message);                                                         // 77
        } else {                                                                                                       //
            Datasets.update({ distribution: { $elemMatch: { _id: distId } } }, { $set: { 'distribtuion.$.online': true } });
            return result;                                                                                             // 80
        }                                                                                                              //
    };                                                                                                                 //
}                                                                                                                      //
                                                                                                                       //
/*                                                                                                                     //
 * check whether credentials are included in the url                                                                   //
 */                                                                                                                    //
function hasCredential(url) {                                                                                          // 88
    var match = url.match(/(.*?:\/\/)?(.*:.*@).*/);                                                                    // 89
    return match && match[2];                                                                                          // 90
}                                                                                                                      //
                                                                                                                       //
//TODO close connections using settimeout                                                                              //
                                                                                                                       //
/*MongoDB*/                                                                                                            //
var mongoclient = Npm.require("mongodb").MongoClient;                                                                  // 96
                                                                                                                       //
/*                                                                                                                     //
 call with one parameter @distId or three parameters @url @username @pass                                              //
 */                                                                                                                    //
var mongodbConnect = connectorFactory(function (url, username, pass, done) {                                           // 101
    if (!hasCredential(url) && username) {                                                                             // 102
        url = 'mongodb://' + username + ':' + pass + '@' + url.slice('mongodb://'.length);                             // 103
    }                                                                                                                  //
    mongoclient.connect(url, done);                                                                                    // 105
});                                                                                                                    //
                                                                                                                       //
/* MySQL */                                                                                                            //
var mysql = Npm.require('mysql');                                                                                      // 109
                                                                                                                       //
var mysqlConnect = connectorFactory(function (url, username, pass, done) {                                             // 111
    url = url.match(/(mysql:\/\/)?(.*)/)[2]; //strip off mysql://                                                      // 112
                                                                                                                       //
    var options = {                                                                                                    // 111
        connectionLimit: 20,                                                                                           // 115
        host: url                                                                                                      // 116
    };                                                                                                                 //
                                                                                                                       //
    if (username) {                                                                                                    // 119
        options.user = username;                                                                                       // 120
    }                                                                                                                  //
                                                                                                                       //
    if (pass) {                                                                                                        // 123
        options.pass = pass;                                                                                           // 124
    }                                                                                                                  //
                                                                                                                       //
    var pool = mysql.createPool(options);                                                                              // 127
                                                                                                                       //
    done(null, pool);                                                                                                  // 129
});                                                                                                                    //
                                                                                                                       //
/*RabbitMQ*/                                                                                                           //
var amqp = Npm.require('amqplib/callback_api');                                                                        // 133
var amqpConnect = connectorFactory(function (url, username, pass, done) {                                              // 134
    var parts = url.match(/(amqps?:\/\/)?([^\?]*)\??(\S*)/),                                                           // 135
        query = parts[3],                                                                                              //
        params = query.split(/[=,&]/),                                                                                 //
        exchanges = params[params.indexOf('exchange') + 1].split(','); //value of query exchange can be a comma separate list
                                                                                                                       //
    if (username) {                                                                                                    // 134
        url = parts[1] + (username + ':' + pass + '@') + parts[2] + (query ? '?' + query : '');                        // 141
    }                                                                                                                  //
                                                                                                                       //
    amqp.connect(url, function (error, conn) {                                                                         // 144
        if (conn) {                                                                                                    // 145
            conn.exchanges = exchanges;                                                                                // 146
        }                                                                                                              //
        done(error, conn);                                                                                             // 148
    });                                                                                                                //
});                                                                                                                    //
                                                                                                                       //
Meteor.methods({                                                                                                       // 152
    //connect                                                                                                          //
    mongodbConnect: mongodbConnect,                                                                                    // 154
    mysqlConnect: mysqlConnect,                                                                                        // 155
    amqpConnect: amqpConnect,                                                                                          // 156
                                                                                                                       //
    //query                                                                                                            //
    mongodbQuery: queryerFactory(mongodbConnect, function (conn, done, collection) {                                   // 159
        var selector = arguments.length <= 3 || arguments[3] === undefined ? {} : arguments[3];                        //
        var options = arguments.length <= 4 || arguments[4] === undefined ? {} : arguments[4];                         //
                                                                                                                       //
        conn.collection(collection, function (error, col) {                                                            // 160
            if (error) {                                                                                               // 161
                throw new Meteor.Error(error.name, error.message);                                                     // 162
            }                                                                                                          //
            var query = col.find(selector);                                                                            // 164
                                                                                                                       //
            for (var key in meteorBabelHelpers.sanitizeForInObject(options)) {                                         // 166
                if (options.hasOwnProperty(key)) {                                                                     // 167
                    query = query[key](options[key]);                                                                  // 168
                }                                                                                                      //
            }                                                                                                          //
            query.toArray(done);                                                                                       // 171
        });                                                                                                            //
    }),                                                                                                                //
    //utils                                                                                                            //
    mongodbCollectionNames: function () {                                                                              // 175
        function mongodbCollectionNames(distId) {                                                                      //
            var db = connPool[distId];                                                                                 // 176
                                                                                                                       //
            if (!db) {                                                                                                 // 178
                mongodbConnect(distId);                                                                                // 179
            }                                                                                                          //
                                                                                                                       //
            db = connPool[distId];                                                                                     // 182
                                                                                                                       //
            if (!db) {                                                                                                 // 184
                throw new Meteor.Error('not-found', 'Distribution ' + distId + ' not initialised');                    // 185
            }                                                                                                          //
                                                                                                                       //
            var _Async$runSync3 = Async.runSync(function (done) {                                                      //
                db.listCollections().toArray(done);                                                                    // 189
            });                                                                                                        //
                                                                                                                       //
            var error = _Async$runSync3.error;                                                                         //
            var result = _Async$runSync3.result;                                                                       //
                                                                                                                       //
                                                                                                                       //
            if (error) {                                                                                               // 192
                throw new Meteor.Error(error.name, error.message);                                                     // 193
            } else {                                                                                                   //
                result = result.filter(function (x) {                                                                  // 195
                    return x.name !== 'system.indexes';                                                                // 196
                });                                                                                                    //
                //console.log(result);                                                                                 //
                return result;                                                                                         // 194
            }                                                                                                          //
        }                                                                                                              //
                                                                                                                       //
        return mongodbCollectionNames;                                                                                 //
    }(),                                                                                                               //
                                                                                                                       //
    mysqlQuery: queryerFactory(mysqlConnect, function (conn, done, query) {                                            // 202
        conn.query(query, done); // db.query returns a third argument @fields which is discarded                       // 203
    }),                                                                                                                // 202
    sparqlQuery: queryerFactory(connectorFactory(function (url, username, pass, done) {                                // 205
        done(null, url);                                                                                               // 206
    }), function (url, done, query) {                                                                                  //
        HTTP.get(url, {                                                                                                // 208
            params: { query: query }, timeout: 30000, headers: {                                                       // 209
                'Content-Type': 'application/x-www-form-urlencoded',                                                   // 210
                'Accept': 'application/sparql-results+json'                                                            // 211
            }                                                                                                          //
        }, function (error, result) {                                                                                  //
            if ((typeof result === 'undefined' ? 'undefined' : (0, _typeof3['default'])(result)) === 'object' && result.content) {
                try {                                                                                                  // 215
                    result = result.content;                                                                           // 216
                } catch (e) {                                                                                          //
                    console.log(e);                                                                                    // 218
                }                                                                                                      //
            }                                                                                                          //
            done(error, result);                                                                                       // 221
        });                                                                                                            //
    }),                                                                                                                //
    amqpQuery: queryerFactory(amqpConnect, function (conn, done, ex, sId) {                                            // 224
        var exchanges = conn.exchanges;                                                                                // 225
        if (_.contains(exchanges, ex)) {                                                                               // 226
            conn.createChannel(function (err, ch) {                                                                    // 227
                var socket = Streamy.sockets(sId);                                                                     // 228
                //keep the channel associate with a client (socket) to close it later                                  //
                if (channels[sId]) {                                                                                   // 227
                    closeCh(channels[sId], sId);                                                                       // 231
                }                                                                                                      //
                channels[sId] = ch;                                                                                    // 233
                ch.assertExchange(ex, 'fanout', { durable: false });                                                   // 234
                ch.assertQueue('', { exclusive: true }, function (err, q) {                                            // 235
                    ch.on('close', function () {                                                                       // 236
                        console.log(sId + ' channel closed');                                                          // 237
                        Streamy.emit(q.queue, { content: sId + ' channel closed' }, socket);                           // 238
                    });                                                                                                //
                    done(err, q.queue);                                                                                // 240
                    Streamy.emit(q.queue, { content: " [*] Waiting for messages" }, socket);                           // 241
                    ch.bindQueue(q.queue, ex, '');                                                                     // 242
                    ch.consume(q.queue, function (msg) {                                                               // 243
                        //console.log(" [x] %s", msg.content.toString());                                              //
                        var content = msg.content.toString();                                                          // 245
                        Streamy.emit(q.queue, { content: content }, socket);                                           // 246
                    }, { noAck: true });                                                                               //
                });                                                                                                    //
            });                                                                                                        //
        } else {                                                                                                       //
            return done(new Error('Unrecognised exchange'));                                                           // 251
        }                                                                                                              //
    }),                                                                                                                //
    amqpCollectionNames: function () {                                                                                 // 254
        function amqpCollectionNames(distId) {                                                                         //
            var conn = connPool[distId];                                                                               // 255
                                                                                                                       //
            if (!conn) {                                                                                               // 257
                amqpConnect(distId);                                                                                   // 258
            }                                                                                                          //
                                                                                                                       //
            conn = connPool[distId];                                                                                   // 261
                                                                                                                       //
            if (!conn) {                                                                                               // 263
                throw new Meteor.Error('not-found', 'Distribution ' + distId + ' not initialised');                    // 264
            }                                                                                                          //
                                                                                                                       //
            return conn.exchanges;                                                                                     // 267
        }                                                                                                              //
                                                                                                                       //
        return amqpCollectionNames;                                                                                    //
    }()                                                                                                                //
});                                                                                                                    //
                                                                                                                       //
var channels = {}; //socketId:channel, each socket only grants for one channels                                        // 271
function closeCh(ch, sId) {                                                                                            // 272
    if (ch) {                                                                                                          // 273
        try {                                                                                                          // 274
            ch.close();                                                                                                // 275
        } catch (e) {                                                                                                  //
            console.log(e.stackAtStateChange);                                                                         // 278
        } finally {                                                                                                    //
            delete channels[sId];                                                                                      // 281
        }                                                                                                              //
    }                                                                                                                  //
}                                                                                                                      //
/**                                                                                                                    //
 * Upon disconnect, clear the client database                                                                          //
 */                                                                                                                    //
Streamy.onDisconnect(function (socket) {                                                                               // 288
    var sId = Streamy.id(socket),                                                                                      // 289
        ch = channels[sId];                                                                                            //
                                                                                                                       //
    closeCh(ch, sId);                                                                                                  // 292
    Streamy.broadcast('__leave__', {                                                                                   // 293
        'sid': Streamy.id(socket)                                                                                      // 294
    });                                                                                                                //
});                                                                                                                    //
                                                                                                                       //
Streamy.on('amqp_end', function (socket) {                                                                             // 298
    var sId = Streamy.id(socket),                                                                                      // 299
        ch = channels[sId];                                                                                            //
                                                                                                                       //
    closeCh(ch, sId);                                                                                                  // 302
    Streamy.broadcast('__leave__', {                                                                                   // 303
        'sid': Streamy.id(socket)                                                                                      // 304
    });                                                                                                                //
});                                                                                                                    //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"groups.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/methods/groups.js                                                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    //
 * Created by xgfd on 25/12/2015.                                                                                      //
 */                                                                                                                    //
                                                                                                                       //
Meteor.methods({                                                                                                       // 5
    addToGroup: function () {                                                                                          // 6
        function addToGroup(userId, groupId) {                                                                         // 6
            check(userId, String);                                                                                     // 7
            check(groupId, String);                                                                                    // 8
            return Groups.update(groupId, { $addToSet: { contentWhiteList: userId } });                                // 9
        }                                                                                                              //
                                                                                                                       //
        return addToGroup;                                                                                             //
    }(),                                                                                                               //
    removeFromGroup: function () {                                                                                     // 11
        function removeFromGroup(userId, groupId) {                                                                    // 11
            check(userId, String);                                                                                     // 12
            check(groupId, String);                                                                                    // 13
            Groups.update(groupId, { $pull: { contentWhiteList: userId } });                                           // 14
        }                                                                                                              //
                                                                                                                       //
        return removeFromGroup;                                                                                        //
    }()                                                                                                                //
});                                                                                                                    //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"notifications.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/methods/notifications.js                                                                                     //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    //
 * Created by xgfd on 13/01/2016.                                                                                      //
 */                                                                                                                    //
                                                                                                                       //
createNotification = function createNotification(initiatorId, entryId, entryName, userId, category, message) {         // 5
    var actions = arguments.length <= 6 || arguments[6] === undefined ? false : arguments[6];                          //
                                                                                                                       //
    check(initiatorId, String);                                                                                        // 6
    check(entryId, String);                                                                                            // 7
    check(entryName, String);                                                                                          // 8
    check(userId, String);                                                                                             // 9
    check(category, String);                                                                                           // 10
    check(message, String);                                                                                            // 11
    check(actions, Match.Any);                                                                                         // 12
                                                                                                                       //
    if (initiatorId !== userId) {                                                                                      // 14
        Notifications.update({                                                                                         // 15
            userId: userId,                                                                                            // 16
            initiatorId: initiatorId,                                                                                  // 17
            category: category,                                                                                        // 18
            entryId: entryId,                                                                                          // 19
            entryName: entryName,                                                                                      // 20
            message: message,                                                                                          // 21
            actions: actions,                                                                                          // 22
            read: false                                                                                                // 23
        }, {                                                                                                           //
            $set: {                                                                                                    // 25
                userId: userId,                                                                                        // 26
                initiatorId: initiatorId,                                                                              // 27
                category: category,                                                                                    // 28
                entryId: entryId,                                                                                      // 29
                entryName: entryName,                                                                                  // 30
                message: message,                                                                                      // 31
                actions: actions,                                                                                      // 32
                read: false                                                                                            // 33
            }                                                                                                          //
        }, { upsert: true });                                                                                          //
    }                                                                                                                  //
};                                                                                                                     //
                                                                                                                       //
Meteor.methods({                                                                                                       // 39
    createNotification: createNotification,                                                                            // 40
    createRequestNotification: function () {                                                                           // 41
        function createRequestNotification(username, organisation, initiatorId, entry, category, note) {               //
            check(username, String);                                                                                   // 42
            check(organisation, String);                                                                               // 43
            check(initiatorId, String);                                                                                // 44
            check(entry, Object);                                                                                      // 45
            check(category, String);                                                                                   // 46
                                                                                                                       //
            var path = Router.routes[category + '.page'].path({ _id: entry._id });                                     // 48
                                                                                                                       //
            var message = '<strong>' + username + '</strong>' + (organisation ? ' of ' + '<strong>' + organisation + '</strong>' : '') + ' requested access to ' + (category + ' <a class="blue-text" href="' + path + '">' + entry.name + '</a><br>') + (note ? '"' + note + '"' : ""),
                actions = ['Allow', 'Deny'];                                                                           //
                                                                                                                       //
            createNotification(initiatorId, entry._id, entry.name, entry.publisher, category, message, actions);       // 57
        }                                                                                                              //
                                                                                                                       //
        return createRequestNotification;                                                                              //
    }()                                                                                                                //
});                                                                                                                    //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"_utils.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/_utils.js                                                                                                    //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    //
 * Created by xgfd on 25/12/2015.                                                                                      //
 */                                                                                                                    //
                                                                                                                       //
/**                                                                                                                    //
 *                                                                                                                     //
 * @param coll A collection                                                                                            //
 * @param pubCBFactry A factory function that returns the publish callback                                             //
 * @param pubAs Maps a collection to publishing name                                                                   //
 */                                                                                                                    //
publish = function publish(coll, pubCBFactry) {                                                                        // 11
  var pubAs = arguments.length <= 2 || arguments[2] === undefined ? function (coll) {                                  //
    return coll._name;                                                                                                 //
  } : arguments[2];                                                                                                    //
                                                                                                                       //
  var name = pubAs(coll);                                                                                              // 12
  Meteor.publish(name, pubCBFactry(coll, name));                                                                       // 13
};                                                                                                                     //
                                                                                                                       //
//import JSONStream from 'JSONStream';                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"fixtures.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/fixtures.js                                                                                                  //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
if (Meteor.settings["public"].environment === 'dev' && !Meteor.settings["public"].migrate) {                           // 1
    /* testing cases                                                                                                   //
     *               ds1 (all)     ds2 (none)     ds3 (group)                                                          //
     * admin           own             y            own                                                                //
     * individual      y               own          n                                                                  //
     * member          y               n            y                                                                  //
     * group           y               n            y                                                                  //
     * */                                                                                                              //
                                                                                                                       //
    var addAdmin = function addAdmin(name) {                                                                           //
                                                                                                                       //
        var xgfdId = Accounts.createUser({                                                                             // 12
            profile: {                                                                                                 // 13
                name: name                                                                                             // 14
            },                                                                                                         //
            username: name,                                                                                            // 16
            email: name + "@example.com",                                                                              // 17
            password: "123456"                                                                                         // 18
        });                                                                                                            //
                                                                                                                       //
        Roles.removeUserFromRoles(xgfdId, ["individual"]);                                                             // 21
        Roles.addUserToRoles(xgfdId, ["admin"]);                                                                       // 22
                                                                                                                       //
        return xgfdId;                                                                                                 // 24
    };                                                                                                                 //
                                                                                                                       //
    var addIndividual = function addIndividual(name) {                                                                 //
        return Accounts.createUser({                                                                                   // 28
            profile: {                                                                                                 // 29
                name: name                                                                                             // 30
            },                                                                                                         //
            username: name,                                                                                            // 32
            email: name + "@example.com",                                                                              // 33
            password: "123456"                                                                                         // 34
        });                                                                                                            //
    };                                                                                                                 //
                                                                                                                       //
    var addGroup = function addGroup(name) {                                                                           //
        var xgfdId = Accounts.createUser({                                                                             // 39
            profile: {                                                                                                 // 40
                name: name,                                                                                            // 41
                isgroup: true,                                                                                         // 42
                description: "Vestibulum scelerisque auctor massa. In lectus arcu, eleifend quis faucibus malesuada, vulputate in lectus. Curabitur ut venenatis ligula, sit amet lacinia velit. Ut euismod libero sed odio efficitur tincidunt. Vestibulum a lacinia erat. Nulla pretium ante id fringilla pharetra. Aliquam varius, purus sed euismod ullamcorper, eros elit maximus magna, eu dignissim turpis leo in arcu. Nullam magna leo, blandit eu sollicitudin et, efficitur eget nibh. Etiam tempus mi eleifend commodo molestie.",
                url: "https://www.google.co.uk"                                                                        // 44
            },                                                                                                         //
            username: name,                                                                                            // 46
            email: name + "@example.com",                                                                              // 47
            password: "123456"                                                                                         // 48
        });                                                                                                            //
                                                                                                                       //
        Roles.removeUserFromRoles(xgfdId, ["individual"]);                                                             // 51
        Roles.addUserToRoles(xgfdId, ["group"]);                                                                       // 52
                                                                                                                       //
        return xgfdId;                                                                                                 // 54
    };                                                                                                                 //
                                                                                                                       //
    var xgfdId = void 0,                                                                                               // 57
        individualId = void 0,                                                                                         //
        groupId = void 0,                                                                                              //
        memberId = void 0;                                                                                             //
    if (Meteor.users.find().count() === 0) {                                                                           // 58
        xgfdId = addAdmin('xgfd');                                                                                     // 59
        individualId = addIndividual('individual');                                                                    // 60
        groupId = addGroup('group');                                                                                   // 61
        memberId = addIndividual('member');                                                                            // 62
        var tmp = Meteor.call('addToGroup', memberId, Groups.findOne({ publisher: groupId })._id);                     // 63
    }                                                                                                                  //
    // Fixture data                                                                                                    //
    var telescopeId = void 0;                                                                                          // 1
    if (Datasets.find().count() === 0) {                                                                               // 67
        var now = new Date().getTime();                                                                                // 68
                                                                                                                       //
        telescopeId = Datasets.insert({                                                                                // 70
            name: 'Introducing Telescope',                                                                             // 71
            publisher: xgfdId,                                                                                         // 72
            distribution: [{                                                                                           // 73
                url: 'mongodb://localhost:3001/meteor',                                                                // 74
                fileFormat: "MongoDB",                                                                                 // 75
                online: true                                                                                           // 76
            }, {                                                                                                       //
                url: 'amqp://wsi-h1.soton.ac.uk?exchange=logs',                                                        // 78
                fileFormat: "AMQP",                                                                                    // 79
                online: true                                                                                           // 80
            }],                                                                                                        //
            license: "MIT",                                                                                            // 82
            description: "Vestibulum scelerisque auctor massa. In lectus arcu, eleifend quis faucibus malesuada, vulputate in lectus. Curabitur ut venenatis ligula, sit amet lacinia velit. Ut euismod libero sed odio efficitur tincidunt. Vestibulum a lacinia erat. Nulla pretium ante id fringilla pharetra. Aliquam varius, purus sed euismod ullamcorper, eros elit maximus magna, eu dignissim turpis leo in arcu. Nullam magna leo, blandit eu sollicitudin et, efficitur eget nibh. Etiam tempus mi eleifend commodo molestie.",
            commentsCount: 2,                                                                                          // 84
            aclContent: false,                                                                                         // 85
            online: true,                                                                                              // 86
            upvoters: [], votes: 0                                                                                     // 87
        });                                                                                                            //
                                                                                                                       //
        Comments.insert({                                                                                              // 90
            entryId: telescopeId,                                                                                      // 91
            publisher: individualId,                                                                                   // 92
            submitted: new Date(now - 5 * 3600 * 1000),                                                                // 93
            body: 'Interesting project Sacha, can I get involved?'                                                     // 94
        });                                                                                                            //
                                                                                                                       //
        Comments.insert({                                                                                              // 97
            entryId: telescopeId,                                                                                      // 98
            publisher: xgfdId,                                                                                         // 99
            submitted: new Date(now - 3 * 3600 * 1000),                                                                // 100
            body: "<p><span style=\"font-family: 'Comic Sans MS';\"><span style=\"font-size: 18px; background-color: rgb(255, 0, 0);\">You</span><span style=\"font-size: 18px;\"> </span><span style=\"font-size: 18px; background-color: rgb(255, 156, 0);\">sure</span><span style=\"font-size: 18px;\"> </span><span style=\"font-size: 18px; background-color: rgb(255, 255, 0);\">can</span><span style=\"font-size: 18px;\"> </span><span style=\"font-size: 18px; background-color: rgb(0, 255, 0);\">Tom</span><span style=\"font-size: 18px; background-color: rgb(0, 0, 255);\">!!!</span></span></p>"
        });                                                                                                            //
                                                                                                                       //
        Datasets.insert({                                                                                              // 104
            name: 'The Meteor Book',                                                                                   // 105
            publisher: individualId,                                                                                   // 106
            distribution: [{                                                                                           // 107
                url: 'http://themeteorbook.com',                                                                       // 108
                fileFormat: "MySQL",                                                                                   // 109
                online: false                                                                                          // 110
            }, {                                                                                                       //
                url: 'http://dbpedia.org/sparql',                                                                      // 112
                fileFormat: "SPARQL",                                                                                  // 113
                online: true                                                                                           // 114
            }],                                                                                                        //
            license: "MIT",                                                                                            // 116
            description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi pharetra augue eget hendrerit bibendum. Vivamus quis laoreet magna. Quisque eu mi sit amet lorem vestibulum rhoncus. Donec lacus est, sodales convallis urna nec, condimentum accumsan ligula. Nullam maximus a sem ac laoreet. In hac habitasse platea dictumst. Pellentesque porttitor ex orci, sed suscipit ante pretium eget. Nam vestibulum metus a libero ultricies molestie sed vel est. Maecenas porta tempus purus, sed pharetra nibh sodales vitae. Nullam in erat tristique, posuere enim laoreet, suscipit erat. Sed quis efficitur enim. 2",
            commentsCount: 0,                                                                                          // 118
            online: false,                                                                                             // 119
            aclMeta: false,                                                                                            // 120
            upvoters: [], votes: 0                                                                                     // 121
        });                                                                                                            //
                                                                                                                       //
        Datasets.insert({                                                                                              // 124
            name: 'Group visible dataset',                                                                             // 125
            publisher: xgfdId,                                                                                         // 126
            distribution: [{                                                                                           // 127
                url: 'http://sachagreif.com/introducing-telescope/',                                                   // 128
                fileFormat: "HTML",                                                                                    // 129
                online: true                                                                                           // 130
            }],                                                                                                        //
            license: "MIT",                                                                                            // 132
            description: "Vestibulum scelerisque auctor massa. In lectus arcu, eleifend quis faucibus malesuada, vulputate in lectus. Curabitur ut venenatis ligula, sit amet lacinia velit. Ut euismod libero sed odio efficitur tincidunt. Vestibulum a lacinia erat. Nulla pretium ante id fringilla pharetra. Aliquam varius, purus sed euismod ullamcorper, eros elit maximus magna, eu dignissim turpis leo in arcu. Nullam magna leo, blandit eu sollicitudin et, efficitur eget nibh. Etiam tempus mi eleifend commodo molestie.",
            commentsCount: 0,                                                                                          // 134
            aclMeta: false,                                                                                            // 135
            aclContent: false,                                                                                         // 136
            metaWhiteList: [groupId],                                                                                  // 137
            contentWhiteList: [groupId],                                                                               // 138
            online: true,                                                                                              // 139
            upvoters: [], votes: 0                                                                                     // 140
        });                                                                                                            //
                                                                                                                       //
        for (var i = 0; i < 50; i++) {                                                                                 // 143
            Apps.insert({                                                                                              // 144
                name: 'Test app #' + i,                                                                                // 145
                url: 'http://sachagreif.com/introducing-telescope/#' + i,                                              // 146
                publisher: groupId,                                                                                    // 147
                license: "MIT",                                                                                        // 148
                aclContent: !!(i % 2),                                                                                 // 149
                description: "Etiam porttitor purus et mollis malesuada. Nulla tempor orci id ex tincidunt consectetur. Praesent et dignissim lectus, in posuere ante. Curabitur nunc dolor, interdum a ornare eget, laoreet eu metus. Ut tempor lacinia eros nec finibus. Maecenas quis felis non mi euismod consectetur quis at leo. Nullam porta tempus ullamcorper. Phasellus et nibh feugiat, iaculis massa eget, blandit quam. Aliquam dolor justo, feugiat et sem ut, fermentum elementum arcu. Aliquam quis tincidunt tortor. Suspendisse potenti. Duis congue sapien ac purus iaculis pharetra. Donec hendrerit lacus leo, non ultricies purus accumsan nec. Nulla vel suscipit quam. Interdum et malesuada fames ac ante ipsum primis in faucibus.",
                commentsCount: 0,                                                                                      // 151
                upvoters: [], votes: 0                                                                                 // 152
            });                                                                                                        //
        }                                                                                                              //
    }                                                                                                                  //
}                                                                                                                      //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"get_remote_colls.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/get_remote_colls.js                                                                                          //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    //
 * Created by xgfd on 10/05/2016.                                                                                      //
 */                                                                                                                    //
                                                                                                                       //
function normaliseUrl(url) {                                                                                           // 5
    //prepend http:// if abscent                                                                                       //
    if (url.indexOf('http') !== 0) {                                                                                   // 7
        url = 'http://' + url;                                                                                         // 8
    }                                                                                                                  //
                                                                                                                       //
    //append / if abscent                                                                                              //
    if (url[url.length - 1] !== '/') {                                                                                 // 5
        url += '/';                                                                                                    // 13
    }                                                                                                                  //
    return url;                                                                                                        // 15
}                                                                                                                      //
                                                                                                                       //
function origin(url, name, doc) {                                                                                      // 18
    return '' + url + name + '/' + doc._id;                                                                            // 19
}                                                                                                                      //
                                                                                                                       //
function linkToRemote(url, name, local) {                                                                              // 22
    var remote = DDP.connect(url),                                                                                     // 23
        col = new Mongo.Collection(name, { connection: remote });                                                      //
                                                                                                                       //
    col.find().observe({                                                                                               // 26
        added: function () {                                                                                           // 27
            function added(doc) {                                                                                      //
                doc.origin = origin(url, name, doc);                                                                   // 28
                //TODO rewrite id refs using url as prefix                                                             //
                delete doc._id;                                                                                        // 27
                delete doc.isBasedOnUrl;                                                                               // 31
                delete doc.comments;                                                                                   // 32
                local.insert(doc);                                                                                     // 33
            }                                                                                                          //
                                                                                                                       //
            return added;                                                                                              //
        }(),                                                                                                           //
        removed: function () {                                                                                         // 35
            function removed(doc) {                                                                                    //
                var origin = origin(url, name, doc);                                                                   // 36
                local.remove({ origin: origin });                                                                      // 37
            }                                                                                                          //
                                                                                                                       //
            return removed;                                                                                            //
        }(),                                                                                                           //
        changed: function () {                                                                                         // 39
            function changed(doc, oldDoc) {                                                                            //
                var origin = origin(url, name, oldDoc);                                                                // 40
                local.remove({ origin: origin });                                                                      // 41
                                                                                                                       //
                doc.origin = origin(url, name, doc);                                                                   // 43
                delete doc._id;                                                                                        // 44
                delete doc.isBasedOnUrl;                                                                               // 45
                local.insert(doc);                                                                                     // 46
            }                                                                                                          //
                                                                                                                       //
            return changed;                                                                                            //
        }()                                                                                                            //
    });                                                                                                                //
    return col;                                                                                                        // 49
}                                                                                                                      //
                                                                                                                       //
function regRemoteColls(remote_name, urls, local) {                                                                    // 52
    return urls.reduce(function (map, url) {                                                                           // 53
        url = normaliseUrl(url);                                                                                       // 54
        if (!map[url]) {                                                                                               // 55
            map[url] = linkToRemote(url, remote_name, local);                                                          // 56
        }                                                                                                              //
        return map;                                                                                                    // 58
    }, {});                                                                                                            //
}                                                                                                                      //
                                                                                                                       //
function updateSub(remoteColls) {                                                                                      // 62
    if (remoteColls) {                                                                                                 // 63
        Object.keys(remoteColls).map(function (url) {                                                                  // 64
            return remoteColls[normaliseUrl(url)];                                                                     //
        }).forEach(function (col) {                                                                                    //
            if (col) {                                                                                                 // 67
                var name = col._name,                                                                                  // 68
                    remote = col._connection;                                                                          //
                remote.subscribe(name);                                                                                // 70
            }                                                                                                          //
        });                                                                                                            //
    }                                                                                                                  //
}                                                                                                                      //
                                                                                                                       //
var woUrls = orion.config.get('wo_urls');                                                                              // 76
var remoteColls = {};                                                                                                  // 77
                                                                                                                       //
if (woUrls) {                                                                                                          // 79
    RemoteApps.remove({});                                                                                             // 80
    RemoteDatasets.remove({});                                                                                         // 81
                                                                                                                       //
    remoteColls[RemoteDatasets.pluralName] = regRemoteColls('datasets', woUrls, RemoteDatasets);                       // 83
    remoteColls[RemoteApps.pluralName] = regRemoteColls('apps', woUrls, RemoteApps);                                   // 84
}                                                                                                                      //
                                                                                                                       //
pullRemoteColls = function pullRemoteColls() {                                                                         // 87
    [RemoteApps, RemoteDatasets].map(function (coll) {                                                                 // 88
        return remoteColls[coll.pluralName];                                                                           //
    }).forEach(updateSub);                                                                                             //
};                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"init.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/init.js                                                                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    //
 * Created by xgfd on 11/01/2016.                                                                                      //
 */                                                                                                                    //
SyncedCron.add({                                                                                                       // 4
    name: 'Pull remote collections',                                                                                   // 5
    schedule: function () {                                                                                            // 6
        function schedule(parser) {                                                                                    // 6
            // parser is a later.parse object                                                                          //
            return parser.text('every 1 hour');                                                                        // 8
        }                                                                                                              //
                                                                                                                       //
        return schedule;                                                                                               //
    }(),                                                                                                               //
    job: pullRemoteColls                                                                                               // 10
});                                                                                                                    //
                                                                                                                       //
Meteor.startup(function () {                                                                                           // 13
    var settings = Meteor.settings;                                                                                    // 14
                                                                                                                       //
    //create admin                                                                                                     //
    if (!settings.admin) {                                                                                             // 13
        settings.admin = { name: 'admin', username: 'admin', email: 'admin@webobservatory.org', password: 'admin' };   // 18
    }                                                                                                                  //
                                                                                                                       //
    if (!Accounts.findUserByUsername(settings.admin.username)) {                                                       // 21
        var xgfdId = Accounts.createUser({                                                                             // 22
            profile: {                                                                                                 // 23
                name: settings.admin.name                                                                              // 24
            },                                                                                                         //
            username: settings.admin.username,                                                                         // 26
            email: settings.admin.email,                                                                               // 27
            password: settings.admin.password                                                                          // 28
        });                                                                                                            //
                                                                                                                       //
        Roles.removeUserFromRoles(xgfdId, ["individual"]);                                                             // 31
        Roles.addUserToRoles(xgfdId, ["admin"]);                                                                       // 32
    }                                                                                                                  //
                                                                                                                       //
    // 1. Set up stmp                                                                                                  //
    //   your_server would be something like 'smtp.gmail.com'                                                          //
    //   and your_port would be a number like 25                                                                       //
                                                                                                                       //
    if (settings.smtp) {                                                                                               // 13
        process.env.MAIL_URL = encodeURIComponent(settings.smtp);                                                      // 40
    }                                                                                                                  //
                                                                                                                       //
    // Add Facebook configuration entry                                                                                //
                                                                                                                       //
    if (settings.facebook) {                                                                                           // 13
        ServiceConfiguration.configurations.update({ "service": "facebook" }, {                                        // 46
            $set: {                                                                                                    // 49
                "appId": settings.facebook.appId,                                                                      // 50
                "secret": settings.facebook.secret                                                                     // 51
            }                                                                                                          //
        }, { upsert: true });                                                                                          //
    }                                                                                                                  //
                                                                                                                       //
    // Add GitHub configuration entry                                                                                  //
    if (settings.github) {                                                                                             // 13
        ServiceConfiguration.configurations.update({ "service": "github" }, {                                          // 60
            $set: {                                                                                                    // 63
                "clientId": settings.github.clientId,                                                                  // 64
                "secret": settings.github.secret                                                                       // 65
            }                                                                                                          //
        }, { upsert: true });                                                                                          //
    }                                                                                                                  //
                                                                                                                       //
    // Set up LDAP.                                                                                                    //
    // Overwrite this function to produce settings based on the incoming request                                       //
    LDAP.generateSettings = function (request) {                                                                       // 13
        var username = request.username,                                                                               // 75
            domain = username.split('@')[1];                                                                           //
                                                                                                                       //
        var ldaps = orion.dictionary.get('ldap.ldap'),                                                                 // 78
            ldapConfig = void 0;                                                                                       //
                                                                                                                       //
        if (ldaps) {                                                                                                   // 81
            ldapConfig = ldaps.filter(function (v) {                                                                   // 82
                return v.domain === domain;                                                                            //
            })[0];                                                                                                     //
            ldapConfig.whiteListedFields = ldapConfig.whiteListedFields.split(/,\s*/);                                 // 83
            ldapConfig.autopublishFields = ldapConfig.autopublishFields ? ldapConfig.autopublishFields.split(/,\s*/) : ldapConfig.whiteListedFields;
            delete ldapConfig.domain;                                                                                  // 85
        }                                                                                                              //
                                                                                                                       //
        return ldapConfig;                                                                                             // 88
    };                                                                                                                 //
                                                                                                                       //
    LDAP.bindValue = function (username, isEmailAddress, serverDn) {                                                   // 91
        return (isEmailAddress ? username.split('@')[0] : username) + '@' + serverDn;                                  // 92
    };                                                                                                                 //
                                                                                                                       //
    LDAP.filter = function (isEmailAddress, usernameOrEmail) {                                                         // 95
        return '(&(cn=' + (isEmailAddress ? usernameOrEmail.split('@')[0] : usernameOrEmail) + ')(objectClass=user))';
    };                                                                                                                 //
                                                                                                                       //
    LDAP.logging = false;                                                                                              // 99
                                                                                                                       //
    Accounts.onCreateUser(function (options, user) {                                                                   // 101
        var profile = options.profile;                                                                                 // 102
        if (profile) {                                                                                                 // 103
            if (profile.displayName) {                                                                                 // 104
                profile.name = profile.displayName;                                                                    // 105
            }                                                                                                          //
        }                                                                                                              //
        user.profile = profile;                                                                                        // 108
        return user;                                                                                                   // 109
    });                                                                                                                //
                                                                                                                       //
    // Get remote apps and datasets                                                                                    //
    pullRemoteColls();                                                                                                 // 13
    SyncedCron.start();                                                                                                // 114
});                                                                                                                    //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publications.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/publications.js                                                                                              //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/*collection publication*/                                                                                             //
function pubSingle(coll) {                                                                                             // 2
    function cbFactry(coll) {                                                                                          // 3
        return function (id) {                                                                                         // 4
            var options = arguments.length <= 1 || arguments[1] === undefined ? {} : arguments[1];                     //
                                                                                                                       //
            check(id, String);                                                                                         // 5
                                                                                                                       //
            var selector = { _id: id },                                                                                // 7
                userId = this.userId;                                                                                  //
                                                                                                                       //
            extendOr(selector, viewsDocumentQuery(userId));                                                            // 10
            options.fields = {                                                                                         // 11
                //'distribution.url': 0,                                                                               //
                'distribution.file': 0,                                                                                // 13
                'distribution.profile.username': 0,                                                                    // 14
                'distribution.profile.pass': 0                                                                         // 15
            };                                                                                                         //
                                                                                                                       //
            return coll.find(selector, options);                                                                       // 18
        };                                                                                                             //
    }                                                                                                                  //
                                                                                                                       //
    publish(coll, cbFactry, function (coll) {                                                                          // 22
        return coll.singularName;                                                                                      //
    });                                                                                                                //
}                                                                                                                      //
                                                                                                                       //
function pubPlural(coll) {                                                                                             // 25
    function cbFactry(coll) {                                                                                          // 26
        return function () {                                                                                           // 27
            var options = arguments.length <= 0 || arguments[0] === undefined ? {} : arguments[0];                     //
            var selector = arguments.length <= 1 || arguments[1] === undefined ? {} : arguments[1];                    //
                                                                                                                       //
            //check(options, {                                                                                         //
            //    fields: Match.Optional(Object),                                                                      //
            //    skip: Match.Optional(Object),                                                                        //
            //    sort: Match.Optional(Object),                                                                        //
            //    limit: Match.Optional(Number)                                                                        //
            //});                                                                                                      //
            if (!selector) {                                                                                           // 34
                selector = {};                                                                                         // 35
            }                                                                                                          //
                                                                                                                       //
            if (!options) {                                                                                            // 38
                options = {};                                                                                          // 39
            }                                                                                                          //
                                                                                                                       //
            check(selector, Object);                                                                                   // 42
                                                                                                                       //
            switch (coll) {                                                                                            // 44
                case Meteor.users:                                                                                     // 45
                    options.fields = { username: 1 };                                                                  // 46
                    break;                                                                                             // 47
                                                                                                                       //
                case Datasets:                                                                                         // 44
                    var userId = this.userId;                                                                          // 50
                    extendOr(selector, viewsDocumentQuery(userId));                                                    // 51
                    options.fields = {                                                                                 // 52
                        //'distribution.url': 0,                                                                       //
                        'distribution.file': 0,                                                                        // 54
                        'distribution.profile.username': 0,                                                            // 55
                        'distribution.profile.pass': 0                                                                 // 56
                    };                                                                                                 //
                    Counts.publish(this, coll.singularName, coll.find(), { nonReactive: true });                       // 58
                    break;                                                                                             // 59
                                                                                                                       //
                case Apps:                                                                                             // 44
                    userId = this.userId;                                                                              // 62
                    extendOr(selector, viewsDocumentQuery(userId));                                                    // 63
                    Counts.publish(this, coll.singularName, coll.find(), { nonReactive: true });                       // 64
                    break;                                                                                             // 65
            }                                                                                                          // 44
                                                                                                                       //
            return coll.find(selector, options);                                                                       // 68
        };                                                                                                             //
    }                                                                                                                  //
                                                                                                                       //
    publish(coll, cbFactry);                                                                                           // 72
}                                                                                                                      //
                                                                                                                       //
[Datasets, Apps, RemoteApps, RemoteDatasets, Groups].forEach(pubSingle);                                               // 75
                                                                                                                       //
[Datasets, Apps, Groups, Licenses, Meteor.users, RemoteApps, RemoteDatasets].forEach(pubPlural);                       // 77
                                                                                                                       //
Meteor.publish('comments', function (entryId) {                                                                        // 79
    check(entryId, String);                                                                                            // 80
    return Comments.find({ entryId: entryId });                                                                        // 81
});                                                                                                                    //
                                                                                                                       //
//publish({                                                                                                            //
//        countDatasets: Datasets,                                                                                     //
//        countApps: Apps,                                                                                             //
//        countGroups: Groups,                                                                                         //
//}, Meteor.publish, function (collection) {                                                                           //
//    return function () {                                                                                             //
//        Counts.publish(this, collection.singularName, collection.find());                                            //
//        //return collection.find();                                                                                  //
//    }                                                                                                                //
//});                                                                                                                  //
                                                                                                                       //
Meteor.publish('notifications', function () {                                                                          // 95
    return Notifications.find({ userId: this.userId, read: false });                                                   // 96
});                                                                                                                    //
                                                                                                                       //
Meteor.publish('images', function () {                                                                                 // 99
    return Images.find();                                                                                              // 100
});                                                                                                                    //
                                                                                                                       //
//Meteor.publish("datasetsAndApps", function () {                                                                      //
//    return [                                                                                                         //
//        Datasets.find(),                                                                                             //
//        Apps.find()                                                                                                  //
//    ];                                                                                                               //
//});                                                                                                                  //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"search.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/search.js                                                                                                    //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    //
 * Created by eugene on 11/02/2016.                                                                                    //
 */                                                                                                                    //
                                                                                                                       //
function buildRegExp(keywords) {                                                                                       // 5
    // this is a dumb implementation                                                                                   //
    var parts = keywords.trim().split(/[ \-\:]+/);                                                                     // 7
    return new RegExp("(" + parts.join('|') + ")", "ig");                                                              // 8
}                                                                                                                      //
                                                                                                                       //
//function containAny(keywords) {                                                                                      //
//    return keywords ? {$or: [{name: buildRegExp(keywords)}]} : {};                                                   //
//}                                                                                                                    //
                                                                                                                       //
//function fedSearch(colls, keywords, options) {                                                                       //
//    options = options || {limit: 10};                                                                                //
//                                                                                                                     //
//    let fedResult = colls                                                                                            //
//        .map(col=> col.find(containAny(keywords), options).fetch())//fetch collection                                //
//        .reduce((a, b)=>a.concat(b));//concat results                                                                //
//    return fedResult;                                                                                                //
//}                                                                                                                    //
//                                                                                                                     //
//let searchDatasets = fedSearch.bind(null, [Datasets, RemoteDatasets]),                                               //
//    searchApps = fedSearch.bind(null, [Apps, RemoteApps]);                                                           //
                                                                                                                       //
SearchSource.defineSource('apps', function (keywords, options) {                                                       // 27
    var options = { limit: 10 };                                                                                       // 28
                                                                                                                       //
    if (keywords) {                                                                                                    // 30
        var regExp = buildRegExp(keywords);                                                                            // 31
        var selector = {                                                                                               // 32
            $or: [{ name: regExp }]                                                                                    // 33
        };                                                                                                             //
                                                                                                                       //
        return Apps.find(selector, options).fetch();                                                                   // 38
    } else {                                                                                                           //
        return Apps.find({}, options).fetch();                                                                         // 40
    }                                                                                                                  //
});                                                                                                                    //
                                                                                                                       //
SearchSource.defineSource('datasets', function (keywords, options) {                                                   // 44
    var options = { limit: 10 };                                                                                       // 45
                                                                                                                       //
    if (keywords) {                                                                                                    // 47
        var regExp = buildRegExp(keywords);                                                                            // 48
        var selector = {                                                                                               // 49
            $or: [{ name: regExp }]                                                                                    // 50
        };                                                                                                             //
                                                                                                                       //
        return Datasets.find(selector, options).fetch();                                                               // 55
    } else {                                                                                                           //
        return Datasets.find({}, options).fetch();                                                                     // 57
    }                                                                                                                  //
});                                                                                                                    //
                                                                                                                       //
SearchSource.defineSource('remoteDatasets', function (keywords, options) {                                             // 61
    var options = { limit: 10 };                                                                                       // 62
                                                                                                                       //
    if (keywords) {                                                                                                    // 64
        var regExp = buildRegExp(keywords);                                                                            // 65
        var selector = {                                                                                               // 66
            $or: [{ name: regExp }]                                                                                    // 67
        };                                                                                                             //
                                                                                                                       //
        return RemoteDatasets.find(selector, options).fetch();                                                         // 72
    } else {                                                                                                           //
        return RemoteDatasets.find({}, options).fetch();                                                               // 74
    }                                                                                                                  //
});                                                                                                                    //
                                                                                                                       //
SearchSource.defineSource('remoteApps', function (keywords, options) {                                                 // 78
    var options = { limit: 10 };                                                                                       // 79
                                                                                                                       //
    if (keywords) {                                                                                                    // 81
        var regExp = buildRegExp(keywords);                                                                            // 82
        var selector = {                                                                                               // 83
            $or: [{ name: regExp }]                                                                                    // 84
        };                                                                                                             //
                                                                                                                       //
        return RemoteApps.find(selector, options).fetch();                                                             // 89
    } else {                                                                                                           //
        return RemoteApps.find({}, options).fetch();                                                                   // 91
    }                                                                                                                  //
});                                                                                                                    //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},{"extensions":[".js",".json"]});
require("./lib/collections/declarations/_utils.js");
require("./lib/collections/declarations/apps.js");
require("./lib/collections/declarations/clients.js");
require("./lib/collections/declarations/comments.js");
require("./lib/collections/declarations/datasets.js");
require("./lib/collections/declarations/group.js");
require("./lib/collections/declarations/licenses.js");
require("./lib/collections/declarations/notifications.js");
require("./lib/collections/declarations/remote.js");
require("./lib/collections/schemas/_creative_work.js");
require("./lib/collections/schemas/apps.js");
require("./lib/collections/schemas/clients.js");
require("./lib/collections/schemas/comments.js");
require("./lib/collections/schemas/datasets.js");
require("./lib/collections/schemas/groups.js");
require("./lib/collections/schemas/licenses.js");
require("./lib/collections/schemas/remote.js");
require("./lib/config/at_config.js");
require("./lib/roles/_utils.js");
require("./lib/roles/group.js");
require("./lib/roles/individual.js");
require("./lib/_utils.js");
require("./lib/orion_config.js");
require("./lib/orion_dictionary.js");
require("./lib/orion_filesystem.js");
require("./lib/router.js");
require("./server/methods/accounts.js");
require("./server/methods/comments.js");
require("./server/methods/creative_work.js");
require("./server/methods/distributions.js");
require("./server/methods/groups.js");
require("./server/methods/notifications.js");
require("./server/_utils.js");
require("./server/fixtures.js");
require("./server/get_remote_colls.js");
require("./server/init.js");
require("./server/publications.js");
require("./server/search.js");
//# sourceMappingURL=app.js.map
