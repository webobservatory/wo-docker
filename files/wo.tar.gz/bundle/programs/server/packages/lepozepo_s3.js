(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var ServiceConfiguration = Package['service-configuration'].ServiceConfiguration;
var check = Package.check.check;
var Match = Package.check.Match;
var Random = Package.random.Random;
var WebApp = Package.webapp.WebApp;
var main = Package.webapp.main;
var WebAppInternals = Package.webapp.WebAppInternals;
var _ = Package.underscore._;
var DDP = Package['ddp-client'].DDP;
var DDPServer = Package['ddp-server'].DDPServer;
var Autoupdate = Package.autoupdate.Autoupdate;

/* Package-scope variables */
var __coffeescriptShare, Knox, AWS;

(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                         //
// packages/lepozepo_s3/server/startup.coffee.js                                                           //
//                                                                                                         //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                           //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
                                                                                                           // 2
                                                                                                           //
Knox = Npm.require("knox");                                                                                // 2
                                                                                                           //
AWS = Npm.require("aws-sdk");                                                                              // 2
                                                                                                           //
this.S3 = {                                                                                                // 2
  config: {},                                                                                              // 7
  knox: {},                                                                                                // 7
  aws: {},                                                                                                 // 7
  rules: {}                                                                                                // 7
};                                                                                                         //
                                                                                                           //
Meteor.startup(function() {                                                                                // 2
  if (!_.has(S3.config, "key")) {                                                                          // 13
    console.log("S3: AWS key is undefined");                                                               // 14
  }                                                                                                        //
  if (!_.has(S3.config, "secret")) {                                                                       // 16
    console.log("S3: AWS secret is undefined");                                                            // 17
  }                                                                                                        //
  if (!_.has(S3.config, "bucket")) {                                                                       // 19
    console.log("S3: AWS bucket is undefined");                                                            // 20
  }                                                                                                        //
  if (!_.has(S3.config, "bucket") || !_.has(S3.config, "secret") || !_.has(S3.config, "key")) {            // 22
    return;                                                                                                // 23
  }                                                                                                        //
  _.defaults(S3.config, {                                                                                  // 13
    region: "us-east-1"                                                                                    // 26
  });                                                                                                      //
  S3.knox = Knox.createClient(S3.config);                                                                  // 13
  return S3.aws = new AWS.S3({                                                                             //
    accessKeyId: S3.config.key,                                                                            // 30
    secretAccessKey: S3.config.secret,                                                                     // 30
    region: S3.config.region                                                                               // 30
  });                                                                                                      //
});                                                                                                        // 12
                                                                                                           //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                         //
// packages/lepozepo_s3/server/sign_request.coffee.js                                                      //
//                                                                                                         //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                           //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var calculate_signature, crypto;                                                                           // 1
                                                                                                           //
Meteor.methods({                                                                                           // 1
  _s3_sign: function(ops) {                                                                                // 2
    var expiration, key, policy, post_url, signature;                                                      // 3
    if (ops == null) {                                                                                     //
      ops = {};                                                                                            //
    }                                                                                                      //
    this.unblock();                                                                                        // 3
    _.defaults(ops, {                                                                                      // 3
      expiration: 1800000,                                                                                 // 13
      path: "",                                                                                            // 13
      bucket: S3.config.bucket,                                                                            // 13
      acl: "public-read",                                                                                  // 13
      region: S3.config.region                                                                             // 13
    });                                                                                                    //
    check(ops, {                                                                                           // 3
      expiration: Number,                                                                                  // 20
      path: String,                                                                                        // 20
      bucket: String,                                                                                      // 20
      acl: String,                                                                                         // 20
      region: String,                                                                                      // 20
      file_type: String,                                                                                   // 20
      file_name: String,                                                                                   // 20
      file_size: Number                                                                                    // 20
    });                                                                                                    //
    expiration = new Date(Date.now() + ops.expiration);                                                    // 3
    expiration = expiration.toISOString();                                                                 // 3
    if (_.isEmpty(ops.path)) {                                                                             // 32
      key = "" + ops.file_name;                                                                            // 33
    } else {                                                                                               //
      key = ops.path + "/" + ops.file_name;                                                                // 35
    }                                                                                                      //
    policy = {                                                                                             // 3
      "expiration": expiration,                                                                            // 38
      "conditions": [                                                                                      // 38
        ["content-length-range", 0, ops.file_size], {                                                      //
          "key": key                                                                                       // 41
        }, {                                                                                               //
          "bucket": ops.bucket                                                                             // 42
        }, {                                                                                               //
          "Content-Type": ops.file_type                                                                    // 43
        }, {                                                                                               //
          "acl": ops.acl                                                                                   // 44
        }, {                                                                                               //
          "Content-Disposition": "inline; filename='" + ops.file_name + "'"                                // 45
        }                                                                                                  //
      ]                                                                                                    //
    };                                                                                                     //
    policy = Buffer(JSON.stringify(policy), "utf-8").toString("base64");                                   // 3
    signature = calculate_signature(policy);                                                               // 3
    if (ops.region === "us-east-1" || ops.region === "us-standard") {                                      // 55
      post_url = "https://s3.amazonaws.com/" + ops.bucket;                                                 // 56
    } else {                                                                                               //
      post_url = "https://s3-" + ops.region + ".amazonaws.com/" + ops.bucket;                              // 58
    }                                                                                                      //
    return {                                                                                               //
      policy: policy,                                                                                      // 61
      signature: signature,                                                                                // 61
      access_key: S3.config.key,                                                                           // 61
      post_url: post_url,                                                                                  // 61
      url: (post_url + "/" + key).replace("https://", "http://"),                                          // 61
      secure_url: post_url + "/" + key,                                                                    // 61
      relative_url: "/" + key,                                                                             // 61
      bucket: ops.bucket,                                                                                  // 61
      acl: ops.acl,                                                                                        // 61
      key: key,                                                                                            // 61
      file_type: ops.file_type,                                                                            // 61
      file_name: ops.file_name                                                                             // 61
    };                                                                                                     //
  }                                                                                                        //
});                                                                                                        //
                                                                                                           //
crypto = Npm.require("crypto");                                                                            // 1
                                                                                                           //
calculate_signature = function(policy) {                                                                   // 1
  return crypto.createHmac("sha1", S3.config.secret).update(new Buffer(policy, "utf-8")).digest("base64");
};                                                                                                         // 76
                                                                                                           //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                         //
// packages/lepozepo_s3/server/delete_object.coffee.js                                                     //
//                                                                                                         //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                           //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var Future;                                                                                                // 1
                                                                                                           //
Future = Npm.require('fibers/future');                                                                     // 1
                                                                                                           //
Meteor.methods({                                                                                           // 1
  _s3_delete: function(path) {                                                                             // 4
    var auth_function, delete_context, future, ref;                                                        // 5
    this.unblock();                                                                                        // 5
    check(path, String);                                                                                   // 5
    future = new Future();                                                                                 // 5
    if ((ref = S3.rules) != null ? ref["delete"] : void 0) {                                               // 10
      delete_context = _.extend(this, {                                                                    // 11
        s3_delete_path: path                                                                               // 12
      });                                                                                                  //
      auth_function = _.bind(S3.rules["delete"], delete_context);                                          // 11
      if (!auth_function()) {                                                                              // 15
        throw new Meteor.Error("Unauthorized", "Delete not allowed");                                      // 16
      }                                                                                                    //
    }                                                                                                      //
    S3.knox.deleteFile(path, function(e, r) {                                                              // 5
      if (e) {                                                                                             // 19
        return future["return"](e);                                                                        //
      } else {                                                                                             //
        return future["return"](true);                                                                     //
      }                                                                                                    //
    });                                                                                                    //
    return future.wait();                                                                                  //
  }                                                                                                        //
});                                                                                                        //
                                                                                                           //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
(function (pkg, symbols) {
  for (var s in symbols)
    (s in pkg) || (pkg[s] = symbols[s]);
})(Package['lepozepo:s3'] = {}, {
  Knox: Knox,
  AWS: AWS
});

})();

//# sourceMappingURL=lepozepo_s3.js.map
