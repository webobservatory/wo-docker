(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var ServiceConfiguration = Package['service-configuration'].ServiceConfiguration;
var check = Package.check.check;
var Match = Package.check.Match;
var Random = Package.random.Random;
var WebApp = Package.webapp.WebApp;
var main = Package.webapp.main;
var WebAppInternals = Package.webapp.WebAppInternals;
var _ = Package.underscore._;
var DDP = Package['ddp-client'].DDP;
var DDPServer = Package['ddp-server'].DDPServer;
var Symbol = Package['ecmascript-runtime'].Symbol;
var Map = Package['ecmascript-runtime'].Map;
var Set = Package['ecmascript-runtime'].Set;
var meteorBabelHelpers = Package['babel-runtime'].meteorBabelHelpers;
var Promise = Package.promise.Promise;
var Autoupdate = Package.autoupdate.Autoupdate;

/* Package-scope variables */
var __coffeescriptShare, Knox, AWS;

(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                         //
// packages/lepozepo_s3/server/startup.coffee.js                                                           //
//                                                                                                         //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                           //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var processBrowser;                                                                                        // 2
                                                                                                           //
Knox = Npm.require("knox");                                                                                // 2
                                                                                                           //
processBrowser = process.browser;                                                                          // 4
                                                                                                           //
process.browser = false;                                                                                   // 5
                                                                                                           //
AWS = Npm.require("aws-sdk");                                                                              // 6
                                                                                                           //
process.browser = processBrowser;                                                                          // 7
                                                                                                           //
this.S3 = {                                                                                                // 10
  config: {},                                                                                              //
  knox: {},                                                                                                //
  aws: {},                                                                                                 //
  rules: {}                                                                                                //
};                                                                                                         //
                                                                                                           //
Meteor.startup(function() {                                                                                // 16
  if (!_.has(S3.config, "key")) {                                                                          //
    console.log("S3: AWS key is undefined");                                                               //
  }                                                                                                        //
  if (!_.has(S3.config, "secret")) {                                                                       //
    console.log("S3: AWS secret is undefined");                                                            //
  }                                                                                                        //
  if (!_.has(S3.config, "bucket")) {                                                                       //
    console.log("S3: AWS bucket is undefined");                                                            //
  }                                                                                                        //
  if (!_.has(S3.config, "bucket") || !_.has(S3.config, "secret") || !_.has(S3.config, "key")) {            //
    return;                                                                                                // 27
  }                                                                                                        //
  _.defaults(S3.config, {                                                                                  //
    region: "us-east-1"                                                                                    //
  });                                                                                                      //
  S3.knox = Knox.createClient(S3.config);                                                                  //
  return S3.aws = new AWS.S3({                                                                             //
    accessKeyId: S3.config.key,                                                                            //
    secretAccessKey: S3.config.secret,                                                                     //
    region: S3.config.region                                                                               //
  });                                                                                                      //
});                                                                                                        // 16
                                                                                                           //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                         //
// packages/lepozepo_s3/server/sign_request.coffee.js                                                      //
//                                                                                                         //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                           //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var calculate_signature, crypto;                                                                           // 1
                                                                                                           //
Meteor.methods({                                                                                           // 1
  _s3_sign: function(ops) {                                                                                //
    var expiration, key, policy, post_url, signature;                                                      // 3
    if (ops == null) {                                                                                     //
      ops = {};                                                                                            //
    }                                                                                                      //
    this.unblock();                                                                                        //
    _.defaults(ops, {                                                                                      //
      expiration: 1800000,                                                                                 //
      path: "",                                                                                            //
      bucket: S3.config.bucket,                                                                            //
      acl: "public-read",                                                                                  //
      region: S3.config.region                                                                             //
    });                                                                                                    //
    check(ops, {                                                                                           //
      expiration: Number,                                                                                  //
      path: String,                                                                                        //
      bucket: String,                                                                                      //
      acl: String,                                                                                         //
      region: String,                                                                                      //
      file_type: String,                                                                                   //
      file_name: String,                                                                                   //
      file_size: Number                                                                                    //
    });                                                                                                    //
    expiration = new Date(Date.now() + ops.expiration);                                                    //
    expiration = expiration.toISOString();                                                                 //
    if (_.isEmpty(ops.path)) {                                                                             //
      key = "" + ops.file_name;                                                                            //
    } else {                                                                                               //
      key = ops.path + "/" + ops.file_name;                                                                //
    }                                                                                                      //
    policy = {                                                                                             //
      "expiration": expiration,                                                                            //
      "conditions": [                                                                                      //
        ["content-length-range", 0, ops.file_size], {                                                      //
          "key": key                                                                                       //
        }, {                                                                                               //
          "bucket": ops.bucket                                                                             //
        }, {                                                                                               //
          "Content-Type": ops.file_type                                                                    //
        }, {                                                                                               //
          "acl": ops.acl                                                                                   //
        }, {                                                                                               //
          "Content-Disposition": "inline; filename='" + ops.file_name + "'"                                //
        }                                                                                                  //
      ]                                                                                                    //
    };                                                                                                     //
    policy = Buffer(JSON.stringify(policy), "utf-8").toString("base64");                                   //
    signature = calculate_signature(policy);                                                               //
    if (ops.region === "us-east-1" || ops.region === "us-standard") {                                      //
      post_url = "https://s3.amazonaws.com/" + ops.bucket;                                                 //
    } else {                                                                                               //
      post_url = "https://s3-" + ops.region + ".amazonaws.com/" + ops.bucket;                              //
    }                                                                                                      //
    return {                                                                                               //
      policy: policy,                                                                                      //
      signature: signature,                                                                                //
      access_key: S3.config.key,                                                                           //
      post_url: post_url,                                                                                  //
      url: (post_url + "/" + key).replace("https://", "http://"),                                          //
      secure_url: post_url + "/" + key,                                                                    //
      relative_url: "/" + key,                                                                             //
      bucket: ops.bucket,                                                                                  //
      acl: ops.acl,                                                                                        //
      key: key,                                                                                            //
      file_type: ops.file_type,                                                                            //
      file_name: ops.file_name                                                                             //
    };                                                                                                     //
  }                                                                                                        //
});                                                                                                        //
                                                                                                           //
crypto = Npm.require("crypto");                                                                            // 75
                                                                                                           //
calculate_signature = function(policy) {                                                                   // 76
  return crypto.createHmac("sha1", S3.config.secret).update(new Buffer(policy, "utf-8")).digest("base64");
};                                                                                                         // 76
                                                                                                           //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                         //
// packages/lepozepo_s3/server/delete_object.coffee.js                                                     //
//                                                                                                         //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                           //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var Future;                                                                                                // 1
                                                                                                           //
Future = Npm.require('fibers/future');                                                                     // 1
                                                                                                           //
Meteor.methods({                                                                                           // 3
  _s3_delete: function(path) {                                                                             //
    var auth_function, delete_context, future, ref;                                                        // 5
    this.unblock();                                                                                        //
    check(path, String);                                                                                   //
    future = new Future();                                                                                 //
    if ((ref = S3.rules) != null ? ref["delete"] : void 0) {                                               //
      delete_context = _.extend(this, {                                                                    //
        s3_delete_path: path                                                                               //
      });                                                                                                  //
      auth_function = _.bind(S3.rules["delete"], delete_context);                                          //
      if (!auth_function()) {                                                                              //
        throw new Meteor.Error("Unauthorized", "Delete not allowed");                                      // 16
      }                                                                                                    //
    }                                                                                                      //
    S3.knox.deleteFile(path, function(e, r) {                                                              //
      if (e) {                                                                                             //
        return future["return"](e);                                                                        //
      } else {                                                                                             //
        return future["return"](true);                                                                     //
      }                                                                                                    //
    });                                                                                                    //
    return future.wait();                                                                                  //
  }                                                                                                        //
});                                                                                                        //
                                                                                                           //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
(function (pkg, symbols) {
  for (var s in symbols)
    (s in pkg) || (pkg[s] = symbols[s]);
})(Package['lepozepo:s3'] = {}, {
  Knox: Knox,
  AWS: AWS
});

})();

//# sourceMappingURL=lepozepo_s3.js.map
