(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var ECMAScript = Package.ecmascript.ECMAScript;
var orion = Package['orionjs:filesystem'].orion;
var Blaze = Package.ui.Blaze;
var UI = Package.ui.UI;
var Handlebars = Package.ui.Handlebars;
var Spacebars = Package.spacebars.Spacebars;
var meteorInstall = Package.modules.meteorInstall;
var Buffer = Package.modules.Buffer;
var process = Package.modules.process;
var Symbol = Package['ecmascript-runtime'].Symbol;
var Map = Package['ecmascript-runtime'].Map;
var Set = Package['ecmascript-runtime'].Set;
var meteorBabelHelpers = Package['babel-runtime'].meteorBabelHelpers;
var Promise = Package.promise.Promise;
var Tracker = Package.tracker.Tracker;
var Deps = Package.tracker.Deps;
var _ = Package.underscore._;
var check = Package.check.check;
var Match = Package.check.Match;
var RouterLayer = Package['nicolaslopezj:router-layer'].RouterLayer;
var Options = Package['nicolaslopezj:options'].Options;
var ReactiveTemplates = Package['nicolaslopezj:reactive-templates'].ReactiveTemplates;
var Roles = Package['nicolaslopezj:roles'].Roles;
var objectHasKey = Package['nicolaslopezj:roles'].objectHasKey;
var HTML = Package.htmljs.HTML;
var i18n = Package['anti:i18n'].i18n;
var T9n = Package['softwarerero:accounts-t9n'].T9n;
var SimpleSchema = Package['aldeed:simple-schema'].SimpleSchema;
var MongoObject = Package['aldeed:simple-schema'].MongoObject;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;

var require = meteorInstall({"node_modules":{"meteor":{"orionjs:file-attribute":{"attribute.js":function(){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/orionjs_file-attribute/attribute.js                      //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
orion.attributes.registerAttribute('file', {                         // 1
  template: 'orionAttributesFileUpload',                             // 2
  previewTemplate: 'orionAttributesFileUploadColumn',                // 3
  getSchema: function getSchema(options) {                           // 4
    var subSchema = new SimpleSchema({                               // 5
      url: {                                                         // 6
        type: String                                                 // 7
      },                                                             // 6
      fileId: {                                                      // 9
        type: String,                                                // 10
        optional: true                                               // 11
      },                                                             // 9
      meta: {                                                        // 13
        type: Object,                                                // 14
        blackbox: true,                                              // 15
        optional: true                                               // 16
      }                                                              // 13
    });                                                              // 5
    return {                                                         // 19
      type: subSchema                                                // 20
    };                                                               // 19
  },                                                                 // 22
  valueOut: function valueOut() {                                    // 23
    return Session.get('file' + this.attr('data-schema-key'));       // 24
  }                                                                  // 25
});                                                                  // 1
///////////////////////////////////////////////////////////////////////

}}}}},{"extensions":[".js",".json"]});
require("./node_modules/meteor/orionjs:file-attribute/attribute.js");

/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['orionjs:file-attribute'] = {};

})();

//# sourceMappingURL=orionjs_file-attribute.js.map
