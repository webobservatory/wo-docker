(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var _ = Package.underscore._;
var meteorInstall = Package['modules-runtime'].meteorInstall;

/* Package-scope variables */
var Buffer, process;

var require = meteorInstall({"node_modules":{"meteor":{"modules":{"server.js":["./install-packages.js","./buffer.js","./process.js",function(require){

////////////////////////////////////////////////////////////////////////////
//                                                                        //
// packages/modules/server.js                                             //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
                                                                          //
require("./install-packages.js");
require("./buffer.js");
require("./process.js");

////////////////////////////////////////////////////////////////////////////

}],"buffer.js":["buffer",function(require){

////////////////////////////////////////////////////////////////////////////
//                                                                        //
// packages/modules/buffer.js                                             //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
                                                                          //
try {
  Buffer = global.Buffer || require("buffer").Buffer;
} catch (noBuffer) {}

////////////////////////////////////////////////////////////////////////////

}],"install-packages.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////
//                                                                        //
// packages/modules/install-packages.js                                   //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
                                                                          //
function install(name) {
  var meteorDir = {};

  // Given a package name <name>, install a stub module in the
  // /node_modules/meteor directory called <name>.js, so that
  // require.resolve("meteor/<name>") will always return
  // /node_modules/meteor/<name>.js instead of something like
  // /node_modules/meteor/<name>/index.js, in the rare but possible event
  // that the package contains a file called index.js (#6590).
  meteorDir[name + ".js"] = function (r, e, module) {
    module.exports = Package[name];
  };

  meteorInstall({
    node_modules: {
      meteor: meteorDir
    }
  });
}

// This file will be modified during computeJsOutputFilesMap to include
// install(<name>) calls for every Meteor package.

install("underscore");
install("meteor");
install("standard-app-packages");
install("babel-compiler");
install("ecmascript");
install("base64");
install("ejson");
install("logging");
install("routepolicy");
install("tracker");
install("deps");
install("htmljs");
install("html-tools");
install("blaze-tools");
install("spacebars-compiler");
install("modules-runtime");
install("modules");
install("jquery");
install("check");
install("id-map");
install("promise");
install("ecmascript-runtime");
install("babel-runtime");
install("random");
install("mongo-id");
install("diff-sequence");
install("observe-sequence");
install("reactive-var");
install("blaze");
install("spacebars");
install("ui");
install("boilerplate-generator");
install("webapp-hashing");
install("webapp");
install("templating");
install("iron:core");
install("iron:dynamic-template");
install("iron:layout");
install("iron:url");
install("iron:middleware-stack");
install("iron:location");
install("npm-mongo");
install("ordered-dict");
install("geojson-utils");
install("minimongo");
install("retry");
install("ddp-common");
install("ddp-client");
install("rate-limit");
install("ddp-rate-limiter");
install("callback-hook");
install("ddp-server");
install("ddp");
install("allow-deny");
install("binary-heap");
install("mongo");
install("reactive-dict");
install("iron:controller");
install("iron:router");
install("sacha:spin");
install("blaze-html-templates");
install("meteor-base");
install("standard-minifiers");
install("reload");
install("autoupdate");
install("meteor-platform");
install("session");
install("livedata");
install("nicolaslopezj:options");
install("nicolaslopezj:reactive-templates");
install("accounts-base");
install("aldeed:simple-schema");
install("aldeed:collection2");
install("dburles:collection-helpers");
install("nicolaslopezj:roles");
install("nicolaslopezj:router-layer");
install("anti:i18n");
install("coffeescript");
install("softwarerero:accounts-t9n");
install("orionjs:lang-en");
install("hot-code-push");
install("standard-minifier-css");
install("standard-minifier-js");
install("orionjs:base");
install("aldeed:autoform");
install("momentjs:moment");
install("orionjs:attributes");
install("npm-bcrypt");
install("sha");
install("srp");
install("email");
install("accounts-password");
install("url");
install("http");
install("useraccounts:core");
install("matb33:collection-hooks");
install("meteorhacks:inject-initial");
install("aldeed:tabular");
install("orionjs:accounts");
install("orionjs:config");
install("orionjs:collections");
install("orionjs:dictionary");
install("orionjs:core");
install("orionjs:filesystem");
install("less");
install("summernote:standalone");
install("orionjs:summernote");
install("jeremy:selectize");
install("orionjs:relationships");
install("orionjs:image-attribute");
install("cfs:standard-packages");
install("cfs:base-package");
install("mongo-livedata");
install("raix:eventemitter");
install("cfs:storage-adapter");
install("cfs:gridfs");
install("cfs:data-man");
install("cfs:file");
install("cfs:tempstore");
install("cfs:http-methods");
install("cfs:http-publish");
install("cfs:access-point");
install("cfs:reactive-property");
install("cfs:reactive-list");
install("cfs:power-queue");
install("cfs:upload-http");
install("cfs:collection");
install("cfs:collection-filters");
install("cfs:worker");
install("cfs:autoform");
install("service-configuration");
install("lepozepo:s3");
install("orionjs:s3");
install("orionjs:file-attribute");
install("useraccounts:iron-routing");
install("localstorage");
install("oauth");
install("accounts-oauth");
install("oauth2");
install("google");
install("accounts-google");
install("accounts-ui");
install("github");
install("accounts-github");
install("vsivsi:file-collection");
install("vsivsi:orion-file-collection");
install("simple:reactive-method");
install("yuukan:streamy");
install("babrahams:accounts-ldap");
install("fortawesome:fontawesome");
install("useraccounts:bootstrap");
install("orionjs:bootstrap");
install("tmeasday:publish-counts");
install("meteorhacks:picker");
install("aldeed:autoform-bs-datepicker");
install("rajit:bootstrap3-datepicker");
install("twbs:bootstrap");
install("meteorhacks:search-source");
install("percolate:synced-cron");
install("meteorhacks:async");

////////////////////////////////////////////////////////////////////////////

},"process.js":["process",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////
//                                                                        //
// packages/modules/process.js                                            //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
                                                                          //
try {
  // The application can run `npm install process` to provide its own
  // process stub; otherwise this module will provide a partial stub.
  process = global.process || require("process");
} catch (noProcess) {
  process = {};
}

if (Meteor.isServer) {
  // Make require("process") work on the server in all versions of Node.
  meteorInstall({
    node_modules: {
      "process.js": function (r, e, module) {
        module.exports = process;
      }
    }
  });
} else {
  process.platform = "browser";
  process.nextTick = process.nextTick || Meteor._setImmediate;
}

if (typeof process.env !== "object") {
  process.env = {};
}

_.extend(process.env, meteorEnv);

////////////////////////////////////////////////////////////////////////////

}]}}}},{"extensions":[".js",".json"]});
var exports = require("./node_modules/meteor/modules/server.js");

/* Exports */
if (typeof Package === 'undefined') Package = {};
(function (pkg, symbols) {
  for (var s in symbols)
    (s in pkg) || (pkg[s] = symbols[s]);
})(Package.modules = exports, {
  meteorInstall: meteorInstall,
  Buffer: Buffer,
  process: process
});

})();

//# sourceMappingURL=modules.js.map
