(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var ECMAScript = Package.ecmascript.ECMAScript;
var orion = Package['orionjs:attributes'].orion;
var ReactiveVar = Package['reactive-var'].ReactiveVar;
var Blaze = Package.ui.Blaze;
var UI = Package.ui.UI;
var Handlebars = Package.ui.Handlebars;
var Spacebars = Package.spacebars.Spacebars;
var meteorInstall = Package.modules.meteorInstall;
var Buffer = Package.modules.Buffer;
var process = Package.modules.process;
var Symbol = Package['ecmascript-runtime'].Symbol;
var Map = Package['ecmascript-runtime'].Map;
var Set = Package['ecmascript-runtime'].Set;
var meteorBabelHelpers = Package['babel-runtime'].meteorBabelHelpers;
var Promise = Package.promise.Promise;
var Tracker = Package.tracker.Tracker;
var Deps = Package.tracker.Deps;
var _ = Package.underscore._;
var check = Package.check.check;
var Match = Package.check.Match;
var RouterLayer = Package['nicolaslopezj:router-layer'].RouterLayer;
var Options = Package['nicolaslopezj:options'].Options;
var ReactiveTemplates = Package['nicolaslopezj:reactive-templates'].ReactiveTemplates;
var Roles = Package['nicolaslopezj:roles'].Roles;
var objectHasKey = Package['nicolaslopezj:roles'].objectHasKey;
var HTML = Package.htmljs.HTML;
var i18n = Package['anti:i18n'].i18n;
var T9n = Package['softwarerero:accounts-t9n'].T9n;
var SimpleSchema = Package['aldeed:simple-schema'].SimpleSchema;
var MongoObject = Package['aldeed:simple-schema'].MongoObject;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;

var require = meteorInstall({"node_modules":{"meteor":{"orionjs:relationships":{"attribute.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/orionjs_relationships/attribute.js                                                                       //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
var _getSchema = function _getSchema(options, hasMany) {                                                             // 1
  check(options, Match.ObjectIncluding({                                                                             // 2
    titleField: Match.OneOf(String, Array),                                                                          // 3
    publicationName: String,                                                                                         // 4
    customPublication: Match.Optional(Boolean),                                                                      // 5
    pluralName: Match.Optional(Match.OneOf(String, Function)),                                                       // 6
    singularName: Match.Optional(Match.OneOf(String, Function)),                                                     // 7
    collection: Mongo.Collection,                                                                                    // 8
    filter: Match.Optional(Function),                                                                                // 9
    createFilter: Match.Optional(Function),                                                                          // 10
    create: Match.Optional(Function),                                                                                // 11
    additionalFields: Match.Optional(Array),                                                                         // 12
    sortFields: Match.Optional(Match.OneOf(Array, Object)),                                                          // 13
    validateOnClient: Match.Optional(Boolean),                                                                       // 14
    validateOnServer: Match.Optional(Boolean),                                                                       // 15
    dontValidate: Match.Optional(Boolean),                                                                           // 16
    render: Match.Optional({                                                                                         // 17
      item: Function,                                                                                                // 18
      option: Function                                                                                               // 19
    })                                                                                                               // 17
  }));                                                                                                               // 2
                                                                                                                     //
  if (!_.has(options, 'validateOnClient')) {                                                                         // 23
    options.validateOnClient = true;                                                                                 // 24
  }                                                                                                                  // 25
                                                                                                                     //
  if (!_.has(options, 'validateOnServer')) {                                                                         // 27
    options.validateOnServer = true;                                                                                 // 28
  }                                                                                                                  // 29
                                                                                                                     //
  if (!options.filter) {                                                                                             // 31
    options.filter = function (userId) {                                                                             // 32
      return {};                                                                                                     // 33
    };                                                                                                               // 34
  }                                                                                                                  // 35
                                                                                                                     //
  if (!options.create) {                                                                                             // 37
    options.create = false;                                                                                          // 38
  }                                                                                                                  // 39
                                                                                                                     //
  if (_.isArray(options.titleField) && options.titleField.length === 1) {                                            // 41
    options.titleField = options.titleField[0];                                                                      // 42
  }                                                                                                                  // 43
                                                                                                                     //
  function render_item_default(item, escape) {                                                                       // 45
    var fieldContent = '';                                                                                           // 46
    if (_.isArray(options.titleField)) {                                                                             // 47
      _.each(options.titleField, function (field, index) {                                                           // 48
        fieldContent += (index > 0 ? ' | ' : '') + escape(item[field]);                                              // 48
      });                                                                                                            // 48
    } else {                                                                                                         // 49
      fieldContent = escape(item[options.titleField]);                                                               // 50
    }                                                                                                                // 51
                                                                                                                     //
    return '<div>' + fieldContent + '</div>';                                                                        // 53
  }                                                                                                                  // 54
                                                                                                                     //
  if (!options.render) {                                                                                             // 56
    options.render = {                                                                                               // 57
      item: render_item_default,                                                                                     // 58
      option: render_item_default                                                                                    // 59
    };                                                                                                               // 57
  }                                                                                                                  // 61
                                                                                                                     //
  if (!options.additionalFields) {                                                                                   // 63
    options.additionalFields = [];                                                                                   // 64
  }                                                                                                                  // 65
                                                                                                                     //
  if (!options.pluralName) {                                                                                         // 67
    options.pluralName = i18n('collections.common.defaultPluralName');                                               // 68
  }                                                                                                                  // 69
                                                                                                                     //
  if (!options.singularName) {                                                                                       // 71
    options.singularName = i18n('collections.common.defaultSingularName');                                           // 72
  }                                                                                                                  // 73
                                                                                                                     //
  options.fields = _.union(options.additionalFields, options.titleField);                                            // 75
                                                                                                                     //
  if (Meteor.isServer) {                                                                                             // 77
    if (!options.customPublication) {                                                                                // 78
      Meteor.publish(options.publicationName, function () {                                                          // 79
        var pubFields = {};                                                                                          // 80
        for (var i = 0; i < options.fields.length; i++) {                                                            // 81
          pubFields[options.fields[i]] = 1;                                                                          // 82
        }                                                                                                            // 83
                                                                                                                     //
        return options.collection.find(options.filter(this.userId), { fields: pubFields });                          // 85
      });                                                                                                            // 86
    }                                                                                                                // 87
                                                                                                                     //
    if (!hasMany) {                                                                                                  // 89
      Meteor.publish(options.publicationName + '_row', function (id) {                                               // 90
        var pubFields = {};                                                                                          // 91
        for (var i = 0; i < options.fields.length; i++) {                                                            // 92
          pubFields[options.fields[i]] = 1;                                                                          // 93
        }                                                                                                            // 94
                                                                                                                     //
        var filter = options.filter(this.userId);                                                                    // 96
        filter._id = id;                                                                                             // 97
        return options.collection.find(filter, { fields: pubFields });                                               // 98
      });                                                                                                            // 99
    }                                                                                                                // 100
  }                                                                                                                  // 101
                                                                                                                     //
  if (options.dontValidate && hasMany) {                                                                             // 103
    return {                                                                                                         // 104
      type: [String],                                                                                                // 105
      orion: options                                                                                                 // 106
    };                                                                                                               // 104
  } else if (options.dontValidate && !hasMany) {                                                                     // 108
    return {                                                                                                         // 109
      type: String,                                                                                                  // 110
      orion: options                                                                                                 // 111
    };                                                                                                               // 109
  } else if (hasMany) {                                                                                              // 113
    return {                                                                                                         // 114
      type: [String],                                                                                                // 115
      orion: options,                                                                                                // 116
      custom: function custom() {                                                                                    // 117
        if (Meteor.isClient && !options.validateOnClient) {                                                          // 118
          return;                                                                                                    // 119
        }                                                                                                            // 120
                                                                                                                     //
        if (Meteor.isServer && !options.validateOnServer) {                                                          // 122
          return;                                                                                                    // 123
        }                                                                                                            // 124
                                                                                                                     //
        if (this.isSet && _.isArray(this.value) && this.value) {                                                     // 126
          var count = options.collection.find({ $and: [{ _id: { $in: this.value } }, options.filter(this.userId)] }).count();
          if (count != this.value.length) {                                                                          // 128
            return 'notAllowed';                                                                                     // 129
          }                                                                                                          // 130
        }                                                                                                            // 131
      }                                                                                                              // 132
    };                                                                                                               // 114
  } else {                                                                                                           // 134
    return {                                                                                                         // 135
      type: String,                                                                                                  // 136
      orion: options,                                                                                                // 137
      custom: function custom() {                                                                                    // 138
        if (Meteor.isClient && !options.validateOnClient) {                                                          // 139
          return;                                                                                                    // 140
        }                                                                                                            // 141
                                                                                                                     //
        if (Meteor.isServer && !options.validateOnServer) {                                                          // 143
          return;                                                                                                    // 144
        }                                                                                                            // 145
                                                                                                                     //
        if (this.isSet && _.isString(this.value) && this.value) {                                                    // 147
          var count = options.collection.find({ $and: [{ _id: this.value }, options.filter(this.userId)] }).count();
          if (count != 1) {                                                                                          // 149
            return 'notAllowed';                                                                                     // 150
          }                                                                                                          // 151
        }                                                                                                            // 152
      }                                                                                                              // 153
    };                                                                                                               // 135
  }                                                                                                                  // 155
};                                                                                                                   // 156
                                                                                                                     //
orion.attributes.registerAttribute('hasMany', {                                                                      // 158
  template: 'orionAttributesHasMany',                                                                                // 159
  previewTemplate: 'orionAttributesHasManyColumn',                                                                   // 160
  getSchema: function getSchema(options) {                                                                           // 161
    return _getSchema(options, true);                                                                                // 162
  },                                                                                                                 // 163
                                                                                                                     //
  valueOut: function valueOut() {                                                                                    // 165
    return this.val();                                                                                               // 166
  }                                                                                                                  // 167
});                                                                                                                  // 158
                                                                                                                     //
orion.attributes.registerAttribute('hasOne', {                                                                       // 170
  template: 'orionAttributesHasOne',                                                                                 // 171
  previewTemplate: 'orionAttributesHasOneColumn',                                                                    // 172
  getSchema: function getSchema(options) {                                                                           // 173
    return _getSchema(options, false);                                                                               // 174
  },                                                                                                                 // 175
                                                                                                                     //
  valueOut: function valueOut() {                                                                                    // 177
    return this.val();                                                                                               // 178
  }                                                                                                                  // 179
});                                                                                                                  // 170
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"users.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/orionjs_relationships/users.js                                                                           //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
orion.attributes.registerAttribute('users', {                                                                        // 1
  template: 'orionAttributesHasMany',                                                                                // 2
  previewTemplate: 'orionAttributesHasManyColumn',                                                                   // 3
  getSchema: function getSchema(options) {                                                                           // 4
    options = _.extend(options, {                                                                                    // 5
      titleField: 'profile.name',                                                                                    // 6
      pluralName: i18n('attributes.users.pluralName'),                                                               // 7
      singularName: i18n('attributes.users.singularName'),                                                           // 8
      collection: Meteor.users,                                                                                      // 9
      additionalFields: ['emails.address', 'roles'],                                                                 // 10
      render: {                                                                                                      // 11
        item: function item(_item, escape) {                                                                         // 12
          return '<div class="usersAttribute">' + (_item['profile.name'] ? '<span class="name">' + escape(_item['profile.name']) + '</span>' : '') + (_item['emails.address'] ? '<span class="email">' + escape(_item['emails.address']) + '</span>' : '') + '</div>';
        },                                                                                                           // 17
        option: function option(item, escape) {                                                                      // 18
          var label = item['profile.name'] || item['emails.address'];                                                // 19
          var caption = item['profile.name'] ? item['emails.address'] : null;                                        // 20
          return '<div class="usersAttribute">' + '<span class="name">' + escape(label) + '</span>' + (caption ? '<span class="email">' + escape(caption) + '</span>' : '') + '</div>';
        }                                                                                                            // 25
      }                                                                                                              // 11
    });                                                                                                              // 5
    return orion.attribute('hasMany', {}, options);                                                                  // 28
  },                                                                                                                 // 29
  valueOut: function valueOut() {                                                                                    // 30
    return this.val();                                                                                               // 31
  }                                                                                                                  // 32
});                                                                                                                  // 1
                                                                                                                     //
orion.attributes.registerAttribute('user', {                                                                         // 35
  template: 'orionAttributesHasOne',                                                                                 // 36
  previewTemplate: 'orionAttributesHasOneColumn',                                                                    // 37
  getSchema: function getSchema(options) {                                                                           // 38
    options = _.extend(options, {                                                                                    // 39
      titleField: 'profile.name',                                                                                    // 40
      collection: Meteor.users,                                                                                      // 41
      additionalFields: ['emails.address', 'roles'],                                                                 // 42
      render: {                                                                                                      // 43
        item: function item(_item2, escape) {                                                                        // 44
          return '<div class="usersAttribute">' + (_item2['profile.name'] ? '<span class="name">' + escape(_item2['profile.name']) + '</span>' : '') + (_item2['emails.address'] ? '<span class="email">' + escape(_item2['emails.address']) + '</span>' : '') + '</div>';
        },                                                                                                           // 49
        option: function option(item, escape) {                                                                      // 50
          var label = item['profile.name'] || item['emails.address'];                                                // 51
          var caption = item['profile.name'] ? item['emails.address'] : null;                                        // 52
          return '<div class="usersAttribute">' + '<span class="name">' + escape(label) + '</span>' + (caption ? '<span class="email">' + escape(caption) + '</span>' : '') + '</div>';
        }                                                                                                            // 57
      }                                                                                                              // 43
    });                                                                                                              // 39
    return orion.attribute('hasOne', {}, options);                                                                   // 60
  },                                                                                                                 // 61
  valueOut: function valueOut() {                                                                                    // 62
    return this.val();                                                                                               // 63
  }                                                                                                                  // 64
});                                                                                                                  // 35
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}}},{"extensions":[".js",".json"]});
require("./node_modules/meteor/orionjs:relationships/attribute.js");
require("./node_modules/meteor/orionjs:relationships/users.js");

/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['orionjs:relationships'] = {};

})();

//# sourceMappingURL=orionjs_relationships.js.map
