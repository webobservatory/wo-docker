(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var _ = Package.underscore._;
var WebApp = Package.webapp.WebApp;
var main = Package.webapp.main;
var WebAppInternals = Package.webapp.WebAppInternals;
var Log = Package.logging.Log;
var Tracker = Package.deps.Tracker;
var Deps = Package.deps.Deps;
var DDP = Package['ddp-client'].DDP;
var DDPServer = Package['ddp-server'].DDPServer;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;
var Blaze = Package.ui.Blaze;
var UI = Package.ui.UI;
var Handlebars = Package.ui.Handlebars;
var Spacebars = Package.spacebars.Spacebars;
var check = Package.check.check;
var Match = Package.check.Match;
var Random = Package.random.Random;
var EJSON = Package.ejson.EJSON;
var HTML = Package.htmljs.HTML;

/* Package-scope variables */
var RouterLayer;

(function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/nicolaslopezj_router-layer/packages/nicolaslopezj_router-layer.js                                        //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                            //
// packages/nicolaslopezj:router-layer/layer.js                                                               //
//                                                                                                            //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                              //
/**                                                                                                           // 1
 * Namespace for Router Layer                                                                                 // 2
 */                                                                                                           // 3
RouterLayer = {};                                                                                             // 4
                                                                                                              // 5
/**                                                                                                           // 6
 * The router package name                                                                                    // 7
 * @type {String}                                                                                             // 8
 */                                                                                                           // 9
RouterLayer.router = null;                                                                                    // 10
                                                                                                              // 11
/**                                                                                                           // 12
 * Check if uses iron router                                                                                  // 13
 */                                                                                                           // 14
if (_.has(Package, 'iron:router')) {                                                                          // 15
  RouterLayer.router = 'iron-router';                                                                         // 16
  RouterLayer.ironRouter = Package['iron:router'].Router;                                                     // 17
}                                                                                                             // 18
                                                                                                              // 19
/**                                                                                                           // 20
 * Check if uses flow router                                                                                  // 21
 */                                                                                                           // 22
if (_.has(Package, 'kadira:flow-router')) {                                                                   // 23
  RouterLayer.router = 'flow-router';                                                                         // 24
  if (!_.has(Package, 'kadira:blaze-layout')) {                                                               // 25
    throw new Meteor.Error('router-layer', 'If you use kadira:flow-router you must add kadira:blaze-layout'); // 26
  }                                                                                                           // 27
  RouterLayer.flowRouter = Package['kadira:flow-router'].FlowRouter;                                          // 28
  RouterLayer.blazeLayout = Package['kadira:blaze-layout'].BlazeLayout;                                       // 29
}                                                                                                             // 30
                                                                                                              // 31
/*                                                                                                            // 32
 * Throw a error if there is no route package                                                                 // 33
 */                                                                                                           // 34
if (!RouterLayer.router) {                                                                                    // 35
  throw new Meteor.Error('router-layer', 'You must add iron:router or kadira:flow-router');                   // 36
}                                                                                                             // 37
                                                                                                              // 38
/**                                                                                                           // 39
 * Creates a new route                                                                                        // 40
 * @param {String} url                        The path of the route                                           // 41
 * @param {Object} [options]                                                                                  // 42
 * @param {String} options.template           The template for this route                                     // 43
 * @param {String} options.name               The name of the route                                           // 44
 * @param {String} options.layout             Optional. The layout for this route                             // 45
 * @param {Boolean} options.reactiveTemplates Optional. Templates are reactive templates                      // 46
 */                                                                                                           // 47
RouterLayer.route = function(url, options) {                                                                  // 48
  check(url, String);                                                                                         // 49
  check(options, {                                                                                            // 50
    template: String,                                                                                         // 51
    name: Match.Optional(String),                                                                             // 52
    layout: Match.Optional(String),                                                                           // 53
    reactiveTemplates: Match.Optional(Boolean)                                                                // 54
  });                                                                                                         // 55
                                                                                                              // 56
  this._route(url, options);                                                                                  // 57
};                                                                                                            // 58
                                                                                                              // 59
/**                                                                                                           // 60
 * Returns the path for a route                                                                               // 61
 * @param  {String} routeName The name of the route                                                           // 62
 * @param  {Object} params    Parameters for the route                                                        // 63
 * @return {String}           The requested url                                                               // 64
 */                                                                                                           // 65
RouterLayer.pathFor = function(routeName, params) {                                                           // 66
  check(routeName, String);                                                                                   // 67
  // check(params, Match.Optional(Object)); Gives error when passing collection documents                     // 68
                                                                                                              // 69
  return this._pathFor(routeName, params);                                                                    // 70
}                                                                                                             // 71
                                                                                                              // 72
/**                                                                                                           // 73
 * Check if the current route has the specified name and params (if set)                                      // 74
 * @param  {String} routeName The name of the route                                                           // 75
 * @param  {Object} params    Optional. The parameters of the route                                           // 76
 * @return {Boolean}          True if the route is active                                                     // 77
 */                                                                                                           // 78
RouterLayer.isActiveRoute = function(routeName, params) {                                                     // 79
  check(routeName, String);                                                                                   // 80
  check(params, Match.Optional(Object));                                                                      // 81
                                                                                                              // 82
  return this._isActiveRoute(routeName, params);                                                              // 83
}                                                                                                             // 84
                                                                                                              // 85
/**                                                                                                           // 86
 * Check if the current route name, divided by dots, starts with the specified name                           // 87
 * @param  {String} routeName The name of the route                                                           // 88
 * @return {Boolean}          True if the route is active                                                     // 89
 */                                                                                                           // 90
RouterLayer.isActiveRoutePartial = function(routeName) {                                                      // 91
  check(routeName, String);                                                                                   // 92
                                                                                                              // 93
  return this._isActiveRoutePartial(routeName);                                                               // 94
}                                                                                                             // 95
                                                                                                              // 96
/**                                                                                                           // 97
 * Redirects the user to the specified route                                                                  // 98
 * @param  {String} routeName The name of the route                                                           // 99
 * @param  {Object} params    Optional. The parameters of the route                                           // 100
 */                                                                                                           // 101
RouterLayer.go = function(routeName, params) {                                                                // 102
  check(routeName, String);                                                                                   // 103
  // check(params, Match.Optional(Object)); Gives error when passing collection documents                     // 104
                                                                                                              // 105
  this._go(routeName, params);                                                                                // 106
}                                                                                                             // 107
                                                                                                              // 108
/**                                                                                                           // 109
 * Returns a parameter of the url                                                                             // 110
 * @param  {String} paramName The name of the parameter                                                       // 111
 */                                                                                                           // 112
RouterLayer.getParam = function(paramName) {                                                                  // 113
  check(paramName, String);                                                                                   // 114
                                                                                                              // 115
  return this._getParam(paramName);                                                                           // 116
}                                                                                                             // 117
                                                                                                              // 118
/**                                                                                                           // 119
 * Returns a parameter of the url query                                                                       // 120
 * @param  {String} queryStringKey The name of the parameter                                                  // 121
 */                                                                                                           // 122
RouterLayer.getQueryParam = function(queryStringKey) {                                                        // 123
  check(queryStringKey, String);                                                                              // 124
                                                                                                              // 125
  return this._getQueryParam(queryStringKey);                                                                 // 126
}                                                                                                             // 127
                                                                                                              // 128
/**                                                                                                           // 129
 * Returns the path of the current route                                                                      // 130
 * @return {String} The path of the current route                                                             // 131
 */                                                                                                           // 132
RouterLayer.getPath = function() {                                                                            // 133
  return this._getPath();                                                                                     // 134
}                                                                                                             // 135
                                                                                                              // 136
////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                            //
// packages/nicolaslopezj:router-layer/iron-router.js                                                         //
//                                                                                                            //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                              //
if (RouterLayer.router == 'iron-router') {                                                                    // 1
  RouterLayer._route = function(url, options) {                                                               // 2
    this.ironRouter.route(url, function() {                                                                   // 3
      if (options.reactiveTemplates) {                                                                        // 4
        options.layout && this.layout(ReactiveTemplates.get(options.layout));                                 // 5
        this.render(ReactiveTemplates.get(options.template));                                                 // 6
      } else {                                                                                                // 7
        options.layout && this.layout(options.layout);                                                        // 8
        this.render(options.template);                                                                        // 9
      }                                                                                                       // 10
    }, { name: options.name });                                                                               // 11
  };                                                                                                          // 12
                                                                                                              // 13
  RouterLayer._pathFor = function(routeName, params) {                                                        // 14
    return this.ironRouter.path(routeName, params);                                                           // 15
  }                                                                                                           // 16
                                                                                                              // 17
  RouterLayer._isActiveRoute = function(routeName, params) {                                                  // 18
    var currentRoute = this.ironRouter.current();                                                             // 19
    var isActive = true;                                                                                      // 20
                                                                                                              // 21
    if (currentRoute.route.getName() !== routeName) {                                                         // 22
      isActive = false;                                                                                       // 23
    }                                                                                                         // 24
                                                                                                              // 25
    if (!params) {                                                                                            // 26
      return isActive;                                                                                        // 27
    }                                                                                                         // 28
                                                                                                              // 29
    _.each(_.keys(params), function(key) {                                                                    // 30
      if (params[key] !== currentRoute.params[key]) {                                                         // 31
        isActive = false;                                                                                     // 32
      }                                                                                                       // 33
    });                                                                                                       // 34
                                                                                                              // 35
    return isActive;                                                                                          // 36
  }                                                                                                           // 37
                                                                                                              // 38
  RouterLayer._isActiveRoutePartial = function(routeName) {                                                   // 39
    var currentRouteName = this.ironRouter.current().route.getName().split('.');                              // 40
    var parts = routeName.split('.');                                                                         // 41
                                                                                                              // 42
    for(var i = 0; i < parts.length; i++) {                                                                   // 43
      if (currentRouteName[i] !== parts[i]) {                                                                 // 44
        return false;                                                                                         // 45
      }                                                                                                       // 46
    }                                                                                                         // 47
                                                                                                              // 48
    return true;                                                                                              // 49
  }                                                                                                           // 50
                                                                                                              // 51
  RouterLayer._go = function(routeName, params) {                                                             // 52
    this.ironRouter.go(routeName, params);                                                                    // 53
  }                                                                                                           // 54
                                                                                                              // 55
  RouterLayer._getParam = function(paramName) {                                                               // 56
    return this.ironRouter.current().params[paramName];                                                       // 57
  }                                                                                                           // 58
                                                                                                              // 59
  RouterLayer._getQueryParam = function(queryStringKey) {                                                     // 60
    return this.ironRouter.current().params.query[queryStringKey];                                            // 61
  }                                                                                                           // 62
                                                                                                              // 63
  RouterLayer._getPath = function() {                                                                         // 64
    return this.ironRouter.current().location.get().path                                                      // 65
  }                                                                                                           // 66
}                                                                                                             // 67
                                                                                                              // 68
////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                            //
// packages/nicolaslopezj:router-layer/flow-router.js                                                         //
//                                                                                                            //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                              //
if (RouterLayer.router == 'flow-router') {                                                                    // 1
  RouterLayer._route = function(url, options) {                                                               // 2
    var self = this;                                                                                          // 3
                                                                                                              // 4
    self.flowRouter.route(url, {                                                                              // 5
      name: options.name,                                                                                     // 6
      action: function(params) {                                                                              // 7
        if (options.reactiveTemplates) {                                                                      // 8
          Tracker.autorun(function() {                                                                        // 9
            if (options.layout) {                                                                             // 10
              self.blazeLayout.render(ReactiveTemplates.get(options.layout), { content: ReactiveTemplates.get(options.template) });
            } else {                                                                                          // 12
              self.blazeLayout.render(ReactiveTemplates.get(options.template));                               // 13
            }                                                                                                 // 14
          });                                                                                                 // 15
        } else {                                                                                              // 16
          if (options.layout) {                                                                               // 17
            self.blazeLayout.render(options.layout, { content: options.template });                           // 18
          } else {                                                                                            // 19
            self.blazeLayout.render(options.template);                                                        // 20
          }                                                                                                   // 21
        }                                                                                                     // 22
      }                                                                                                       // 23
    });                                                                                                       // 24
  };                                                                                                          // 25
                                                                                                              // 26
  RouterLayer._pathFor = function(routeName, params) {                                                        // 27
    return this.flowRouter.path(routeName, params);                                                           // 28
  }                                                                                                           // 29
                                                                                                              // 30
  RouterLayer._isActiveRoute = function(routeName, params) {                                                  // 31
    var isActive = true;                                                                                      // 32
                                                                                                              // 33
    if (this.flowRouter.getRouteName() !== routeName) {                                                       // 34
      isActive = false;                                                                                       // 35
    }                                                                                                         // 36
                                                                                                              // 37
    if (!params) {                                                                                            // 38
      return isActive;                                                                                        // 39
    }                                                                                                         // 40
                                                                                                              // 41
    var self = this;                                                                                          // 42
    _.each(_.keys(params), function(key) {                                                                    // 43
      if (params[key] !== self.flowRouter.getParam(key)) {                                                    // 44
        isActive = false;                                                                                     // 45
      }                                                                                                       // 46
    });                                                                                                       // 47
                                                                                                              // 48
    return isActive;                                                                                          // 49
  }                                                                                                           // 50
                                                                                                              // 51
  RouterLayer._isActiveRoutePartial = function(routeName) {                                                   // 52
    var currentRouteName = this.flowRouter.getRouteName().split('.');                                         // 53
    var parts = routeName.split('.');                                                                         // 54
                                                                                                              // 55
    for(var i = 0; i < parts.length; i++) {                                                                   // 56
      if (currentRouteName[i] !== parts[i]) {                                                                 // 57
        return false;                                                                                         // 58
      }                                                                                                       // 59
    }                                                                                                         // 60
                                                                                                              // 61
    return true;                                                                                              // 62
  }                                                                                                           // 63
                                                                                                              // 64
  RouterLayer._go = function(routeName, params) {                                                             // 65
    this.flowRouter.go(routeName, params);                                                                    // 66
  }                                                                                                           // 67
                                                                                                              // 68
  RouterLayer._getParam = function(paramName) {                                                               // 69
    return this.flowRouter.getParam(paramName);                                                               // 70
  }                                                                                                           // 71
                                                                                                              // 72
  RouterLayer._getQueryParam = function(queryStringKey) {                                                     // 73
    return this.flowRouter.getQueryParam(queryStringKey);                                                     // 74
  }                                                                                                           // 75
                                                                                                              // 76
  RouterLayer._getPath = function() {                                                                         // 77
    this.flowRouter.watchPathChange();                                                                        // 78
    return this.flowRouter.current().path;                                                                    // 79
  }                                                                                                           // 80
}                                                                                                             // 81
                                                                                                              // 82
////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
(function (pkg, symbols) {
  for (var s in symbols)
    (s in pkg) || (pkg[s] = symbols[s]);
})(Package['nicolaslopezj:router-layer'] = {}, {
  RouterLayer: RouterLayer
});

})();

//# sourceMappingURL=nicolaslopezj_router-layer.js.map
