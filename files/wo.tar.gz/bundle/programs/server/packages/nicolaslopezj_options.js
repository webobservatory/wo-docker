(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var WebApp = Package.webapp.WebApp;
var main = Package.webapp.main;
var WebAppInternals = Package.webapp.WebAppInternals;
var Log = Package.logging.Log;
var Tracker = Package.deps.Tracker;
var Deps = Package.deps.Deps;
var DDP = Package['ddp-client'].DDP;
var DDPServer = Package['ddp-server'].DDPServer;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;
var Blaze = Package.ui.Blaze;
var UI = Package.ui.UI;
var Handlebars = Package.ui.Handlebars;
var Spacebars = Package.spacebars.Spacebars;
var check = Package.check.check;
var Match = Package.check.Match;
var _ = Package.underscore._;
var Random = Package.random.Random;
var EJSON = Package.ejson.EJSON;
var HTML = Package.htmljs.HTML;

/* Package-scope variables */
var Options;

(function(){

///////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                           //
// packages/nicolaslopezj_options/packages/nicolaslopezj_options.js                          //
//                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////
                                                                                             //
(function () {

/////////////////////////////////////////////////////////////////////////////////////////
//                                                                                     //
// packages/nicolaslopezj:options/options.js                                           //
//                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////
                                                                                       //
/**                                                                                    // 1
 * Reactive options for orion                                                          // 2
 */                                                                                    // 3
Options = {                                                                            // 4
  _values: {},                                                                         // 5
  _deps: {},                                                                           // 6
  _listeners: {},                                                                      // 7
}                                                                                      // 8
                                                                                       // 9
/**                                                                                    // 10
 * Initialize a option variable.                                                       // 11
 * You can set a unique string o a array of string                                     // 12
 */                                                                                    // 13
Options.init = function(key, initialValue) {                                           // 14
  check(key, String);                                                                  // 15
  this._deps[key] = new Tracker.Dependency;                                            // 16
  this._values[key] = initialValue;                                                    // 17
  this._listeners[key] = [];                                                           // 18
}                                                                                      // 19
                                                                                       // 20
/**                                                                                    // 21
 * Method for setting options                                                          // 22
 */                                                                                    // 23
Options.set = function(key, value) {                                                   // 24
  if (!_.has(this._deps, key)) throw 'Option "' + key + '" is not initalized';         // 25
  this._values[key] = value;                                                           // 26
  this._deps[key].changed();                                                           // 27
  _.each(this._listeners[key], function(func){                                         // 28
    func(value)                                                                        // 29
  });                                                                                  // 30
}                                                                                      // 31
                                                                                       // 32
/**                                                                                    // 33
 * Push values to options                                                              // 34
 */                                                                                    // 35
Options.arrayPush = function(key, value) {                                             // 36
  if (!_.has(this._deps, key)) throw 'Option "' + key + '" is not initalized';         // 37
  if (!_.isArray(this._values[key])) throw 'Option "' + key + '" is not an array';     // 38
  this._values[key].push(value);                                                       // 39
  this._deps[key].changed();                                                           // 40
  _.each(this._listeners[key], function(func){                                         // 41
    func(value)                                                                        // 42
  });                                                                                  // 43
}                                                                                      // 44
                                                                                       // 45
/**                                                                                    // 46
 * Adds listeners to a option. The difference between this and tracker is that tracker // 47
 * waits till the app is idle to run the callback, this is instantly. I'm not saying   // 48
 * it's better, but sometimes tracker is not compatible.                               // 49
 */                                                                                    // 50
Options.listen = function(key, value) {                                                // 51
  check(key, String);                                                                  // 52
  check(value, Function);                                                              // 53
  if (!_.has(this._deps, key)) throw 'Option "' + key + '" is not initalized';         // 54
  this._listeners[key].push(value);                                                    // 55
}                                                                                      // 56
                                                                                       // 57
/**                                                                                    // 58
 * Returns the value of the definition.                                                // 59
 * If the definition doesn't exists it                                                 // 60
 * returns the defaultValue                                                            // 61
 */                                                                                    // 62
Options.get = function(key, defaultValue) {                                            // 63
  if (!_.has(this._deps, key)) throw 'Option "' + key + '" is not initalized';         // 64
  this._deps[key].depend();                                                            // 65
  return this._values[key] || defaultValue;                                            // 66
};                                                                                     // 67
/////////////////////////////////////////////////////////////////////////////////////////

}).call(this);

///////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
(function (pkg, symbols) {
  for (var s in symbols)
    (s in pkg) || (pkg[s] = symbols[s]);
})(Package['nicolaslopezj:options'] = {}, {
  Options: Options
});

})();

//# sourceMappingURL=nicolaslopezj_options.js.map
