(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var ECMAScript = Package.ecmascript.ECMAScript;
var i18n = Package['anti:i18n'].i18n;
var T9n = Package['softwarerero:accounts-t9n'].T9n;
var meteorInstall = Package.modules.meteorInstall;
var Buffer = Package.modules.Buffer;
var process = Package.modules.process;
var Symbol = Package['ecmascript-runtime'].Symbol;
var Map = Package['ecmascript-runtime'].Map;
var Set = Package['ecmascript-runtime'].Set;
var meteorBabelHelpers = Package['babel-runtime'].meteorBabelHelpers;
var Promise = Package.promise.Promise;

/* Package-scope variables */
var detectLanguage;

var require = meteorInstall({"node_modules":{"meteor":{"orionjs:lang-en":{"init.js":function(){

/////////////////////////////////////////////////////////////////////////////////
//                                                                             //
// packages/orionjs_lang-en/init.js                                            //
//                                                                             //
/////////////////////////////////////////////////////////////////////////////////
                                                                               //
i18n.setDefaultLanguage('en');                                                 // 1
i18n.showMissing('[no translation for "<%= label %>" in <%= language %>]');    // 2
                                                                               //
if (Meteor.isClient) {                                                         // 4
  /**                                                                          //
   * Detects and set the language                                              //
   */                                                                          //
  detectLanguage = function detectLanguage() {                                 // 8
    var language = window.navigator.userLanguage || window.navigator.language;
    language = language.split('-')[0];                                         // 10
    i18n.setLanguage(language);                                                // 11
    T9n.setLanguage(language);                                                 // 12
  };                                                                           // 13
                                                                               //
  /**                                                                          //
   * Detects and set the language on startup                                   //
   */                                                                          //
  Meteor.startup(function () {                                                 // 18
    detectLanguage();                                                          // 19
  });                                                                          // 20
}                                                                              // 21
/////////////////////////////////////////////////////////////////////////////////

},"en.js":function(){

/////////////////////////////////////////////////////////////////////////////////
//                                                                             //
// packages/orionjs_lang-en/en.js                                              //
//                                                                             //
/////////////////////////////////////////////////////////////////////////////////
                                                                               //
i18n.map('en', {                                                               // 1
  global: {                                                                    // 2
    save: 'Save',                                                              // 3
    create: 'Create',                                                          // 4
    logout: 'Logout',                                                          // 5
    back: 'Back',                                                              // 6
    cancel: 'Cancel',                                                          // 7
    'delete': 'Delete',                                                        // 8
    confirm: 'Confirm',                                                        // 9
    choose: 'Choose',                                                          // 10
    noPermission: 'You have no permissions',                                   // 11
    passwordNotMatch: 'Passwords doesn\'t match',                              // 12
    optional: 'Optional'                                                       // 13
  },                                                                           // 2
  accounts: {                                                                  // 15
    schema: {                                                                  // 16
      emails: {                                                                // 17
        title: 'Emails',                                                       // 18
        address: 'Address',                                                    // 19
        verified: 'Verified'                                                   // 20
      },                                                                       // 17
      password: {                                                              // 22
        title: 'Password',                                                     // 23
        'new': 'New Password',                                                 // 24
        confirm: 'Confirm Password'                                            // 25
      },                                                                       // 22
      profile: {                                                               // 27
        name: 'Name'                                                           // 28
      }                                                                        // 27
    },                                                                         // 16
    index: {                                                                   // 31
      title: 'Accounts',                                                       // 32
      noName: 'No Name',                                                       // 33
      actions: {                                                               // 34
        edit: 'Edit',                                                          // 35
        sendEnrollmentEmail: 'Send Enrollment Email'                           // 36
      },                                                                       // 34
      tableTitles: {                                                           // 38
        name: 'Name',                                                          // 39
        services: 'Login method',                                              // 40
        email: 'Email',                                                        // 41
        roles: 'Roles',                                                        // 42
        actions: 'Actions'                                                     // 43
      }                                                                        // 38
    },                                                                         // 31
    update: {                                                                  // 46
      title: 'Update Account',                                                 // 47
      messages: {                                                              // 48
        noPermissions: 'You have no permissions to edit this user'             // 49
      },                                                                       // 48
      sections: {                                                              // 51
        profile: {                                                             // 52
          title: 'Profile'                                                     // 53
        },                                                                     // 52
        roles: {                                                               // 55
          title: 'Roles',                                                      // 56
          selectRoles: 'Select user roles'                                     // 57
        },                                                                     // 55
        changePassword: {                                                      // 59
          title: 'Change Password'                                             // 60
        },                                                                     // 59
        deleteUser: {                                                          // 62
          title: 'Danger Ahead',                                               // 63
          advice: 'Deleting users can cause problems.',                        // 64
          button: 'Delete User'                                                // 65
        }                                                                      // 62
      }                                                                        // 51
    },                                                                         // 46
    myAccount: {                                                               // 69
      title: 'My Account'                                                      // 70
    },                                                                         // 69
    create: {                                                                  // 72
      title: 'Create a User',                                                  // 73
      createInvitation: 'Create invitation',                                   // 74
      createUserNow: 'Create user now',                                        // 75
      inviteOther: 'Invite Other',                                             // 76
      selectRoles: 'Select new user roles',                                    // 77
      email: 'Email',                                                          // 78
      messages: {                                                              // 79
        successfullyCreated: 'Invitation created successfully'                 // 80
      }                                                                        // 79
    },                                                                         // 72
    changePassword: {                                                          // 83
      title: 'Change Password'                                                 // 84
    },                                                                         // 83
    updateProfile: {                                                           // 86
      title: 'Update Profile'                                                  // 87
    },                                                                         // 86
    register: {                                                                // 89
      title: 'Register',                                                       // 90
      registerButton: 'Register',                                              // 91
      fields: {                                                                // 92
        email: 'Email',                                                        // 93
        name: 'Name',                                                          // 94
        password: 'Password',                                                  // 95
        confirmPassword: 'Password (again)'                                    // 96
      },                                                                       // 92
      messages: {                                                              // 98
        invalidEmail: 'Invalid Email',                                         // 99
        invalidInvitationCode: 'Invalid invitation code'                       // 100
      }                                                                        // 98
    }                                                                          // 89
  },                                                                           // 15
  collections: {                                                               // 104
    create: {                                                                  // 105
      title: 'Create a {$1}'                                                   // 106
    },                                                                         // 105
    update: {                                                                  // 108
      title: 'Update {$1}'                                                     // 109
    },                                                                         // 108
    'delete': {                                                                // 111
      title: 'Delete {$1}',                                                    // 112
      confirmQuestion: 'Are you sure you wan\'t to delete this {$1}?'          // 113
    },                                                                         // 111
    common: {                                                                  // 115
      defaultPluralName: 'items',                                              // 116
      defaultSingularName: 'item'                                              // 117
    }                                                                          // 115
  },                                                                           // 104
  config: {                                                                    // 120
    update: {                                                                  // 121
      title: 'Config'                                                          // 122
    }                                                                          // 121
  },                                                                           // 120
  dictionary: {                                                                // 125
    update: {                                                                  // 126
      title: 'Dictionary'                                                      // 127
    }                                                                          // 126
  },                                                                           // 125
  filesystem: {                                                                // 130
    messages: {                                                                // 131
      notFound_id: 'File not found [{$i}]',                                    // 132
      errorUploading: 'Error uploading file',                                  // 133
      errorRemoving: 'Error removing file'                                     // 134
    }                                                                          // 131
  },                                                                           // 130
  pages: {                                                                     // 137
    schema: {                                                                  // 138
      title: 'Title',                                                          // 139
      url: 'Url'                                                               // 140
    },                                                                         // 138
    index: {                                                                   // 142
      title: 'Pages'                                                           // 143
    },                                                                         // 142
    create: {                                                                  // 145
      title: 'Create page',                                                    // 146
      chooseTemplate: 'Choose Template'                                        // 147
    },                                                                         // 145
    update: {                                                                  // 149
      title: 'Update page'                                                     // 150
    },                                                                         // 149
    'delete': {                                                                // 152
      title: 'Delete page',                                                    // 153
      confirmQuestion: 'Are you sure you wan\'t to delete this page?'          // 154
    }                                                                          // 152
  },                                                                           // 137
  attributes: {                                                                // 157
    users: {                                                                   // 158
      pluralName: 'users',                                                     // 159
      singularName: 'user'                                                     // 160
    },                                                                         // 158
    file: {                                                                    // 162
      choose: 'Choose file',                                                   // 163
      noFile: 'No file'                                                        // 164
    },                                                                         // 162
    image: {                                                                   // 166
      choose: 'Choose image'                                                   // 167
    },                                                                         // 166
    images: {                                                                  // 169
      choose: 'Choose the images',                                             // 170
      clickToRemove: 'Click to remove'                                         // 171
    }                                                                          // 169
  },                                                                           // 157
  tabular: {                                                                   // 174
    search: 'Search:',                                                         // 175
    info: 'Showing _START_ to _END_ of _TOTAL_ entries',                       // 176
    infoEmpty: 'Showing 0 to 0 of 0 entries',                                  // 177
    lengthMenu: 'Show _MENU_ entries',                                         // 178
    emptyTable: 'No data available in table',                                  // 179
    paginate: {                                                                // 180
      first: 'First',                                                          // 181
      previous: 'Previous',                                                    // 182
      next: 'Next',                                                            // 183
      last: 'Last'                                                             // 184
    }                                                                          // 180
  }                                                                            // 174
});                                                                            // 1
/////////////////////////////////////////////////////////////////////////////////

}}}}},{"extensions":[".js",".json"]});
require("./node_modules/meteor/orionjs:lang-en/init.js");
require("./node_modules/meteor/orionjs:lang-en/en.js");

/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['orionjs:lang-en'] = {};

})();

//# sourceMappingURL=orionjs_lang-en.js.map
