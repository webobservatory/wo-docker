(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var WebApp = Package.webapp.WebApp;
var main = Package.webapp.main;
var WebAppInternals = Package.webapp.WebAppInternals;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;
var LocalCollection = Package.minimongo.LocalCollection;
var Minimongo = Package.minimongo.Minimongo;
var check = Package.check.check;
var Match = Package.check.Match;

/* Package-scope variables */
var __coffeescriptShare, FileCollection;

(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/vsivsi_file-collection/src/gridFS.coffee.js                                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
share.defaultChunkSize = 2 * 1024 * 1024 - 1024;                                                                       // 7
                                                                                                                       //
share.defaultRoot = 'fs';                                                                                              // 7
                                                                                                                       //
share.resumableBase = '/_resumable';                                                                                   // 7
                                                                                                                       //
share.insert_func = function(file, chunkSize) {                                                                        // 7
  var id, ref, ref1, ref2, ref3, subFile;                                                                              // 13
  if (file == null) {                                                                                                  //
    file = {};                                                                                                         //
  }                                                                                                                    //
  try {                                                                                                                // 13
    id = new Mongo.ObjectID("" + file._id);                                                                            // 14
  } catch (_error) {                                                                                                   //
    id = new Mongo.ObjectID();                                                                                         // 16
  }                                                                                                                    //
  subFile = {};                                                                                                        // 13
  subFile._id = id;                                                                                                    // 13
  subFile.length = 0;                                                                                                  // 13
  subFile.md5 = 'd41d8cd98f00b204e9800998ecf8427e';                                                                    // 13
  subFile.uploadDate = new Date();                                                                                     // 13
  subFile.chunkSize = chunkSize;                                                                                       // 13
  subFile.filename = (ref = file.filename) != null ? ref : '';                                                         // 13
  subFile.metadata = (ref1 = file.metadata) != null ? ref1 : {};                                                       // 13
  subFile.aliases = (ref2 = file.aliases) != null ? ref2 : [];                                                         // 13
  subFile.contentType = (ref3 = file.contentType) != null ? ref3 : 'application/octet-stream';                         // 13
  return subFile;                                                                                                      // 27
};                                                                                                                     // 12
                                                                                                                       //
share.reject_file_modifier = function(modifier) {                                                                      // 7
  var forbidden, required;                                                                                             // 31
  forbidden = Match.OneOf(Match.ObjectIncluding({                                                                      // 31
    _id: Match.Any                                                                                                     // 32
  }), Match.ObjectIncluding({                                                                                          //
    length: Match.Any                                                                                                  // 33
  }), Match.ObjectIncluding({                                                                                          //
    chunkSize: Match.Any                                                                                               // 34
  }), Match.ObjectIncluding({                                                                                          //
    md5: Match.Any                                                                                                     // 35
  }), Match.ObjectIncluding({                                                                                          //
    uploadDate: Match.Any                                                                                              // 36
  }));                                                                                                                 //
  required = Match.OneOf(Match.ObjectIncluding({                                                                       // 31
    _id: Match.Any                                                                                                     // 40
  }), Match.ObjectIncluding({                                                                                          //
    length: Match.Any                                                                                                  // 41
  }), Match.ObjectIncluding({                                                                                          //
    chunkSize: Match.Any                                                                                               // 42
  }), Match.ObjectIncluding({                                                                                          //
    md5: Match.Any                                                                                                     // 43
  }), Match.ObjectIncluding({                                                                                          //
    uploadDate: Match.Any                                                                                              // 44
  }), Match.ObjectIncluding({                                                                                          //
    metadata: Match.Any                                                                                                // 45
  }), Match.ObjectIncluding({                                                                                          //
    aliases: Match.Any                                                                                                 // 46
  }), Match.ObjectIncluding({                                                                                          //
    filename: Match.Any                                                                                                // 47
  }), Match.ObjectIncluding({                                                                                          //
    contentType: Match.Any                                                                                             // 48
  }));                                                                                                                 //
  return Match.test(modifier, Match.OneOf(Match.ObjectIncluding({                                                      // 51
    $set: forbidden                                                                                                    // 52
  }), Match.ObjectIncluding({                                                                                          //
    $unset: required                                                                                                   // 53
  }), Match.ObjectIncluding({                                                                                          //
    $inc: forbidden                                                                                                    // 54
  }), Match.ObjectIncluding({                                                                                          //
    $mul: forbidden                                                                                                    // 55
  }), Match.ObjectIncluding({                                                                                          //
    $bit: forbidden                                                                                                    // 56
  }), Match.ObjectIncluding({                                                                                          //
    $min: forbidden                                                                                                    // 57
  }), Match.ObjectIncluding({                                                                                          //
    $max: forbidden                                                                                                    // 58
  }), Match.ObjectIncluding({                                                                                          //
    $rename: required                                                                                                  // 59
  }), Match.ObjectIncluding({                                                                                          //
    $currentDate: forbidden                                                                                            // 60
  }), Match.Where(function(pat) {                                                                                      //
    return !Match.test(pat, Match.OneOf(Match.ObjectIncluding({                                                        // 62
      $inc: Match.Any                                                                                                  // 63
    }), Match.ObjectIncluding({                                                                                        //
      $set: Match.Any                                                                                                  // 64
    }), Match.ObjectIncluding({                                                                                        //
      $unset: Match.Any                                                                                                // 65
    }), Match.ObjectIncluding({                                                                                        //
      $addToSet: Match.Any                                                                                             // 66
    }), Match.ObjectIncluding({                                                                                        //
      $pop: Match.Any                                                                                                  // 67
    }), Match.ObjectIncluding({                                                                                        //
      $pullAll: Match.Any                                                                                              // 68
    }), Match.ObjectIncluding({                                                                                        //
      $pull: Match.Any                                                                                                 // 69
    }), Match.ObjectIncluding({                                                                                        //
      $pushAll: Match.Any                                                                                              // 70
    }), Match.ObjectIncluding({                                                                                        //
      $push: Match.Any                                                                                                 // 71
    }), Match.ObjectIncluding({                                                                                        //
      $bit: Match.Any                                                                                                  // 72
    })));                                                                                                              //
  })));                                                                                                                //
};                                                                                                                     // 29
                                                                                                                       //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/vsivsi_file-collection/src/server_shared.coffee.js                                                         //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var through2;                                                                                                          // 7
                                                                                                                       //
if (Meteor.isServer) {                                                                                                 // 7
  through2 = Npm.require('through2');                                                                                  // 9
  share.defaultResponseHeaders = {                                                                                     // 9
    'Content-Type': 'text/plain'                                                                                       // 12
  };                                                                                                                   //
  share.check_allow_deny = function(type, userId, file, fields) {                                                      // 9
    var checkRules, result;                                                                                            // 16
    checkRules = function(rules) {                                                                                     // 16
      var func, i, len, ref, res;                                                                                      // 17
      res = false;                                                                                                     // 17
      ref = rules[type];                                                                                               // 18
      for (i = 0, len = ref.length; i < len; i++) {                                                                    // 18
        func = ref[i];                                                                                                 //
        if (!res) {                                                                                                    //
          res = func(userId, file, fields);                                                                            // 19
        }                                                                                                              //
      }                                                                                                                // 18
      return res;                                                                                                      // 20
    };                                                                                                                 //
    result = !checkRules(this.denys) && checkRules(this.allows);                                                       // 16
    return result;                                                                                                     // 23
  };                                                                                                                   //
  share.bind_env = function(func) {                                                                                    // 9
    if (func != null) {                                                                                                // 26
      return Meteor.bindEnvironment(func, function(err) {                                                              // 27
        throw err;                                                                                                     // 27
      });                                                                                                              //
    } else {                                                                                                           //
      return func;                                                                                                     // 29
    }                                                                                                                  //
  };                                                                                                                   //
  share.safeObjectID = function(s) {                                                                                   // 9
    if (s != null ? s.match(/^[0-9a-f]{24}$/i) : void 0) {                                                             // 32
      return new Mongo.ObjectID(s);                                                                                    //
    } else {                                                                                                           //
      return null;                                                                                                     //
    }                                                                                                                  //
  };                                                                                                                   //
  share.streamChunker = function(size) {                                                                               // 9
    var makeFuncs;                                                                                                     // 38
    if (size == null) {                                                                                                //
      size = share.defaultChunkSize;                                                                                   //
    }                                                                                                                  //
    makeFuncs = function(size) {                                                                                       // 38
      var bufferList, flush, total, transform;                                                                         // 39
      bufferList = [new Buffer(0)];                                                                                    // 39
      total = 0;                                                                                                       // 39
      flush = function(cb) {                                                                                           // 39
        var lastBuffer, newBuffer, outSize, outputBuffer;                                                              // 42
        outSize = total > size ? size : total;                                                                         // 42
        if (outSize > 0) {                                                                                             // 43
          outputBuffer = Buffer.concat(bufferList, outSize);                                                           // 44
          this.push(outputBuffer);                                                                                     // 44
          total -= outSize;                                                                                            // 44
        }                                                                                                              //
        lastBuffer = bufferList.pop();                                                                                 // 42
        newBuffer = lastBuffer.slice(lastBuffer.length - total);                                                       // 42
        bufferList = [newBuffer];                                                                                      // 42
        if (total < size) {                                                                                            // 50
          return cb();                                                                                                 //
        } else {                                                                                                       //
          return flush.bind(this)(cb);                                                                                 //
        }                                                                                                              //
      };                                                                                                               //
      transform = function(chunk, enc, cb) {                                                                           // 39
        bufferList.push(chunk);                                                                                        // 55
        total += chunk.length;                                                                                         // 55
        if (total < size) {                                                                                            // 57
          return cb();                                                                                                 //
        } else {                                                                                                       //
          return flush.bind(this)(cb);                                                                                 //
        }                                                                                                              //
      };                                                                                                               //
      return [transform, flush];                                                                                       // 61
    };                                                                                                                 //
    return through2.apply(this, makeFuncs(size));                                                                      // 62
  };                                                                                                                   //
}                                                                                                                      //
                                                                                                                       //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/vsivsi_file-collection/src/gridFS_server.coffee.js                                                         //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var dicer, express, fs, grid, gridLocks, mongodb, path,                                                                // 7
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;                                                                                         //
                                                                                                                       //
if (Meteor.isServer) {                                                                                                 // 7
  mongodb = Npm.require('mongodb');                                                                                    // 9
  grid = Npm.require('gridfs-locking-stream');                                                                         // 9
  gridLocks = Npm.require('gridfs-locks');                                                                             // 9
  fs = Npm.require('fs');                                                                                              // 9
  path = Npm.require('path');                                                                                          // 9
  dicer = Npm.require('dicer');                                                                                        // 9
  express = Npm.require('express');                                                                                    // 9
  FileCollection = (function(superClass) {                                                                             // 9
    extend(FileCollection, superClass);                                                                                // 19
                                                                                                                       //
    function FileCollection(root, options) {                                                                           // 19
      var indexOptions, ref, ref1, ref2, ref3, ref4, ref5, ref6, ref7, ref8, self;                                     // 20
      this.root = root != null ? root : share.defaultRoot;                                                             // 20
      if (options == null) {                                                                                           //
        options = {};                                                                                                  //
      }                                                                                                                //
      if (!(this instanceof FileCollection)) {                                                                         // 20
        return new FileCollection(this.root, options);                                                                 // 21
      }                                                                                                                //
      if (!(this instanceof Mongo.Collection)) {                                                                       // 23
        throw new Meteor.Error('The global definition of Mongo.Collection has changed since the file-collection package was loaded. Please ensure that any packages that redefine Mongo.Collection are loaded before file-collection.');
      }                                                                                                                //
      if (Mongo.Collection !== Mongo.Collection.prototype.constructor) {                                               // 26
        throw new Meteor.Error('The global definition of Mongo.Collection has been patched by another package, and the prototype constructor has been left in an inconsistent state. Please see this link for a workaround: https://github.com/vsivsi/meteor-file-sample-app/issues/2#issuecomment-120780592');
      }                                                                                                                //
      if (typeof this.root === 'object') {                                                                             // 29
        options = this.root;                                                                                           // 30
        this.root = share.defaultRoot;                                                                                 // 30
      }                                                                                                                //
      this.chunkSize = (ref = options.chunkSize) != null ? ref : share.defaultChunkSize;                               // 20
      this.db = Meteor.wrapAsync(mongodb.MongoClient.connect)(process.env.MONGO_URL, {});                              // 20
      this.lockOptions = {                                                                                             // 20
        timeOut: (ref1 = (ref2 = options.locks) != null ? ref2.timeOut : void 0) != null ? ref1 : 360,                 // 38
        lockExpiration: (ref3 = (ref4 = options.locks) != null ? ref4.lockExpiration : void 0) != null ? ref3 : 90,    // 38
        pollingInterval: (ref5 = (ref6 = options.locks) != null ? ref6.pollingInterval : void 0) != null ? ref5 : 5    // 38
      };                                                                                                               //
      this.locks = gridLocks.LockCollection(this.db, {                                                                 // 20
        root: this.root,                                                                                               // 43
        timeOut: this.lockOptions.timeOut,                                                                             // 43
        lockExpiration: this.lockOptions.lockExpiration,                                                               // 43
        pollingInterval: this.lockOptions.pollingInterval                                                              // 43
      });                                                                                                              //
      this.gfs = new grid(this.db, mongodb, this.root);                                                                // 20
      this.baseURL = (ref7 = options.baseURL) != null ? ref7 : "/gridfs/" + this.root;                                 // 20
      if (options.resumable || options.http) {                                                                         // 53
        share.setupHttpAccess.bind(this)(options);                                                                     // 54
      }                                                                                                                //
      this.allows = {                                                                                                  // 20
        read: [],                                                                                                      // 57
        insert: [],                                                                                                    // 57
        write: [],                                                                                                     // 57
        remove: []                                                                                                     // 57
      };                                                                                                               //
      this.denys = {                                                                                                   // 20
        read: [],                                                                                                      // 58
        insert: [],                                                                                                    // 58
        write: [],                                                                                                     // 58
        remove: []                                                                                                     // 58
      };                                                                                                               //
      FileCollection.__super__.constructor.call(this, this.root + '.files', {                                          // 20
        idGeneration: 'MONGO'                                                                                          // 61
      });                                                                                                              //
      if (options.resumable) {                                                                                         // 64
        indexOptions = {};                                                                                             // 65
        if (typeof options.resumableIndexName === 'string') {                                                          // 66
          indexOptions.name = options.resumableIndexName;                                                              // 67
        }                                                                                                              //
        this.db.collection(this.root + ".files").ensureIndex({                                                         // 65
          'metadata._Resumable.resumableIdentifier': 1,                                                                // 69
          'metadata._Resumable.resumableChunkNumber': 1,                                                               // 69
          length: 1                                                                                                    // 69
        }, indexOptions);                                                                                              //
      }                                                                                                                //
      this.maxUploadSize = (ref8 = options.maxUploadSize) != null ? ref8 : -1;                                         // 20
      FileCollection.__super__.allow.bind(this)({                                                                      // 20
        insert: (function(_this) {                                                                                     // 90
          return function(userId, file) {                                                                              //
            return true;                                                                                               //
          };                                                                                                           //
        })(this),                                                                                                      //
        remove: (function(_this) {                                                                                     // 90
          return function(userId, file) {                                                                              //
            return true;                                                                                               //
          };                                                                                                           //
        })(this)                                                                                                       //
      });                                                                                                              //
      FileCollection.__super__.deny.bind(this)({                                                                       // 20
        insert: (function(_this) {                                                                                     // 95
          return function(userId, file) {                                                                              //
            check(file, {                                                                                              // 98
              _id: Mongo.ObjectID,                                                                                     // 99
              length: Match.Where(function(x) {                                                                        // 99
                check(x, Match.Integer);                                                                               // 101
                return x === 0;                                                                                        //
              }),                                                                                                      //
              md5: Match.Where(function(x) {                                                                           // 99
                check(x, String);                                                                                      // 104
                return x === 'd41d8cd98f00b204e9800998ecf8427e';                                                       //
              }),                                                                                                      //
              uploadDate: Date,                                                                                        // 99
              chunkSize: Match.Where(function(x) {                                                                     // 99
                check(x, Match.Integer);                                                                               // 108
                return x === _this.chunkSize;                                                                          //
              }),                                                                                                      //
              filename: String,                                                                                        // 99
              contentType: String,                                                                                     // 99
              aliases: [String],                                                                                       // 99
              metadata: Object                                                                                         // 99
            });                                                                                                        //
            if (file.chunkSize !== _this.chunkSize) {                                                                  // 116
              console.warn("Invalid chunksize");                                                                       // 117
              return true;                                                                                             // 118
            }                                                                                                          //
            if (share.check_allow_deny.bind(_this)('insert', userId, file)) {                                          // 121
              return false;                                                                                            // 122
            }                                                                                                          //
            return true;                                                                                               // 124
          };                                                                                                           //
        })(this),                                                                                                      //
        update: (function(_this) {                                                                                     // 95
          return function(userId, file, fields) {                                                                      //
            return true;                                                                                               // 132
          };                                                                                                           //
        })(this),                                                                                                      //
        remove: (function(_this) {                                                                                     // 95
          return function(userId, file) {                                                                              //
            return true;                                                                                               // 137
          };                                                                                                           //
        })(this)                                                                                                       //
      });                                                                                                              //
      self = this;                                                                                                     // 20
      Meteor.server.method_handlers[this._prefix + "remove"] = function(selector) {                                    // 20
        var file;                                                                                                      // 142
        if (!LocalCollection._selectorIsIdPerhapsAsObject(selector)) {                                                 // 142
          throw new Meteor.Error(403, "Not permitted. Untrusted code may only remove documents by ID.");               // 143
        }                                                                                                              //
        file = self.findOne(selector);                                                                                 // 142
        if (file) {                                                                                                    // 146
          if (share.check_allow_deny.bind(self)('remove', this.userId, file)) {                                        // 147
            return self.remove(file);                                                                                  // 148
          } else {                                                                                                     //
            throw new Meteor.Error(403, "Access denied");                                                              // 150
          }                                                                                                            //
        } else {                                                                                                       //
          return 0;                                                                                                    // 152
        }                                                                                                              //
      };                                                                                                               //
    }                                                                                                                  //
                                                                                                                       //
    FileCollection.prototype.allow = function(allowOptions) {                                                          // 19
      var func, results, type;                                                                                         // 156
      results = [];                                                                                                    // 156
      for (type in allowOptions) {                                                                                     //
        func = allowOptions[type];                                                                                     //
        if (!(type in this.allows)) {                                                                                  // 157
          throw new Meteor.Error("Unrecognized allow rule type '" + type + "'.");                                      // 158
        }                                                                                                              //
        if (typeof func !== 'function') {                                                                              // 159
          throw new Meteor.Error("Allow rule " + type + " must be a valid function.");                                 // 160
        }                                                                                                              //
        results.push(this.allows[type].push(func));                                                                    // 157
      }                                                                                                                // 156
      return results;                                                                                                  //
    };                                                                                                                 //
                                                                                                                       //
    FileCollection.prototype.deny = function(denyOptions) {                                                            // 19
      var func, results, type;                                                                                         // 165
      results = [];                                                                                                    // 165
      for (type in denyOptions) {                                                                                      //
        func = denyOptions[type];                                                                                      //
        if (!(type in this.denys)) {                                                                                   // 166
          throw new Meteor.Error("Unrecognized deny rule type '" + type + "'.");                                       // 167
        }                                                                                                              //
        if (typeof func !== 'function') {                                                                              // 168
          throw new Meteor.Error("Deny rule " + type + " must be a valid function.");                                  // 169
        }                                                                                                              //
        results.push(this.denys[type].push(func));                                                                     // 166
      }                                                                                                                // 165
      return results;                                                                                                  //
    };                                                                                                                 //
                                                                                                                       //
    FileCollection.prototype.insert = function(file, callback) {                                                       // 19
      if (file == null) {                                                                                              //
        file = {};                                                                                                     //
      }                                                                                                                //
      if (callback == null) {                                                                                          //
        callback = void 0;                                                                                             //
      }                                                                                                                //
      file = share.insert_func(file, this.chunkSize);                                                                  // 173
      return FileCollection.__super__.insert.call(this, file, callback);                                               //
    };                                                                                                                 //
                                                                                                                       //
    FileCollection.prototype.update = function(selector, modifier, options, callback) {                                // 19
      var err;                                                                                                         // 182
      if (options == null) {                                                                                           //
        options = {};                                                                                                  //
      }                                                                                                                //
      if (callback == null) {                                                                                          //
        callback = void 0;                                                                                             //
      }                                                                                                                //
      if ((callback == null) && typeof options === 'function') {                                                       // 182
        callback = options;                                                                                            // 183
        options = {};                                                                                                  // 183
      }                                                                                                                //
      if (options.upsert != null) {                                                                                    // 186
        err = new Meteor.Error("Update does not support the upsert option");                                           // 187
        if (callback != null) {                                                                                        // 188
          return callback(err);                                                                                        // 189
        } else {                                                                                                       //
          throw err;                                                                                                   // 191
        }                                                                                                              //
      }                                                                                                                //
      if (share.reject_file_modifier(modifier) && !options.force) {                                                    // 193
        err = new Meteor.Error("Modifying gridFS read-only document elements is a very bad idea!");                    // 194
        if (callback != null) {                                                                                        // 195
          return callback(err);                                                                                        // 196
        } else {                                                                                                       //
          throw err;                                                                                                   // 198
        }                                                                                                              //
      } else {                                                                                                         //
        return FileCollection.__super__.update.call(this, selector, modifier, options, callback);                      //
      }                                                                                                                //
    };                                                                                                                 //
                                                                                                                       //
    FileCollection.prototype.upsert = function(selector, modifier, options, callback) {                                // 19
      var err;                                                                                                         // 203
      if (options == null) {                                                                                           //
        options = {};                                                                                                  //
      }                                                                                                                //
      if (callback == null) {                                                                                          //
        callback = void 0;                                                                                             //
      }                                                                                                                //
      if ((callback == null) && typeof options === 'function') {                                                       // 203
        callback = options;                                                                                            // 204
      }                                                                                                                //
      err = new Meteor.Error("File Collections do not support 'upsert'");                                              // 203
      if (callback != null) {                                                                                          // 206
        return callback(err);                                                                                          //
      } else {                                                                                                         //
        throw err;                                                                                                     // 209
      }                                                                                                                //
    };                                                                                                                 //
                                                                                                                       //
    FileCollection.prototype.upsertStream = function(file, options, callback) {                                        // 19
      var cbCalled, found, mods, writeStream;                                                                          // 212
      if (options == null) {                                                                                           //
        options = {};                                                                                                  //
      }                                                                                                                //
      if (callback == null) {                                                                                          //
        callback = void 0;                                                                                             //
      }                                                                                                                //
      if ((callback == null) && typeof options === 'function') {                                                       // 212
        callback = options;                                                                                            // 213
        options = {};                                                                                                  // 213
      }                                                                                                                //
      callback = share.bind_env(callback);                                                                             // 212
      cbCalled = false;                                                                                                // 212
      mods = {};                                                                                                       // 212
      if (file.filename != null) {                                                                                     // 218
        mods.filename = file.filename;                                                                                 // 218
      }                                                                                                                //
      if (file.aliases != null) {                                                                                      // 219
        mods.aliases = file.aliases;                                                                                   // 219
      }                                                                                                                //
      if (file.contentType != null) {                                                                                  // 220
        mods.contentType = file.contentType;                                                                           // 220
      }                                                                                                                //
      if (file.metadata != null) {                                                                                     // 221
        mods.metadata = file.metadata;                                                                                 // 221
      }                                                                                                                //
      if (options.autoRenewLock == null) {                                                                             //
        options.autoRenewLock = true;                                                                                  //
      }                                                                                                                //
      if (options.mode === 'w+') {                                                                                     // 225
        throw new Meteor.Error("The ability to append file data in upsertStream() was removed in version 1.0.0");      // 226
      }                                                                                                                //
      if (file._id) {                                                                                                  // 229
        found = this.findOne({                                                                                         // 230
          _id: file._id                                                                                                // 230
        });                                                                                                            //
      }                                                                                                                //
      if (!(file._id && found)) {                                                                                      // 232
        file._id = this.insert(mods);                                                                                  // 233
      } else if (Object.keys(mods).length > 0) {                                                                       //
        this.update({                                                                                                  // 235
          _id: file._id                                                                                                // 235
        }, {                                                                                                           //
          $set: mods                                                                                                   // 235
        });                                                                                                            //
      }                                                                                                                //
      writeStream = Meteor.wrapAsync(this.gfs.createWriteStream.bind(this.gfs))({                                      // 212
        root: this.root,                                                                                               // 238
        _id: mongodb.ObjectID("" + file._id),                                                                          // 238
        mode: 'w',                                                                                                     // 238
        timeOut: this.lockOptions.timeOut,                                                                             // 238
        lockExpiration: this.lockOptions.lockExpiration,                                                               // 238
        pollingInterval: this.lockOptions.pollingInterval                                                              // 238
      });                                                                                                              //
      if (writeStream) {                                                                                               // 245
        if (options.autoRenewLock) {                                                                                   // 247
          writeStream.on('expires-soon', (function(_this) {                                                            // 248
            return function() {                                                                                        //
              return writeStream.renewLock(function(e, d) {                                                            //
                if (e || !d) {                                                                                         // 250
                  return console.warn("Automatic Write Lock Renewal Failed: " + file._id, e);                          //
                }                                                                                                      //
              });                                                                                                      //
            };                                                                                                         //
          })(this));                                                                                                   //
        }                                                                                                              //
        if (callback != null) {                                                                                        // 253
          writeStream.on('close', function(retFile) {                                                                  // 254
            if (retFile) {                                                                                             // 255
              retFile._id = new Mongo.ObjectID(retFile._id.toHexString());                                             // 256
              return callback(null, retFile);                                                                          //
            }                                                                                                          //
          });                                                                                                          //
          writeStream.on('error', function(err) {                                                                      // 254
            return callback(err);                                                                                      //
          });                                                                                                          //
        }                                                                                                              //
        return writeStream;                                                                                            // 261
      }                                                                                                                //
      return null;                                                                                                     // 263
    };                                                                                                                 //
                                                                                                                       //
    FileCollection.prototype.findOneStream = function(selector, options, callback) {                                   // 19
      var file, opts, range, readStream, ref, ref1, ref2, ref3;                                                        // 266
      if (options == null) {                                                                                           //
        options = {};                                                                                                  //
      }                                                                                                                //
      if (callback == null) {                                                                                          //
        callback = void 0;                                                                                             //
      }                                                                                                                //
      if ((callback == null) && typeof options === 'function') {                                                       // 266
        callback = options;                                                                                            // 267
        options = {};                                                                                                  // 267
      }                                                                                                                //
      callback = share.bind_env(callback);                                                                             // 266
      opts = {};                                                                                                       // 266
      if (options.sort != null) {                                                                                      // 272
        opts.sort = options.sort;                                                                                      // 272
      }                                                                                                                //
      if (options.skip != null) {                                                                                      // 273
        opts.skip = options.skip;                                                                                      // 273
      }                                                                                                                //
      file = this.findOne(selector, opts);                                                                             // 266
      if (file) {                                                                                                      // 276
        if (options.autoRenewLock == null) {                                                                           //
          options.autoRenewLock = true;                                                                                //
        }                                                                                                              //
        range = {                                                                                                      // 277
          start: (ref = (ref1 = options.range) != null ? ref1.start : void 0) != null ? ref : 0,                       // 281
          end: (ref2 = (ref3 = options.range) != null ? ref3.end : void 0) != null ? ref2 : file.length - 1            // 281
        };                                                                                                             //
        readStream = Meteor.wrapAsync(this.gfs.createReadStream.bind(this.gfs))({                                      // 277
          root: this.root,                                                                                             // 285
          _id: mongodb.ObjectID("" + file._id),                                                                        // 285
          timeOut: this.lockOptions.timeOut,                                                                           // 285
          lockExpiration: this.lockOptions.lockExpiration,                                                             // 285
          pollingInterval: this.lockOptions.pollingInterval,                                                           // 285
          range: {                                                                                                     // 285
            startPos: range.start,                                                                                     // 291
            endPos: range.end                                                                                          // 291
          }                                                                                                            //
        });                                                                                                            //
        if (readStream) {                                                                                              // 294
          if (options.autoRenewLock) {                                                                                 // 295
            readStream.on('expires-soon', (function(_this) {                                                           // 296
              return function() {                                                                                      //
                return readStream.renewLock(function(e, d) {                                                           //
                  if (e || !d) {                                                                                       // 298
                    return console.warn("Automatic Read Lock Renewal Failed: " + file._id, e);                         //
                  }                                                                                                    //
                });                                                                                                    //
              };                                                                                                       //
            })(this));                                                                                                 //
          }                                                                                                            //
          if (callback != null) {                                                                                      // 301
            readStream.on('close', function() {                                                                        // 302
              return callback(null, file);                                                                             //
            });                                                                                                        //
            readStream.on('error', function(err) {                                                                     // 302
              return callback(err);                                                                                    //
            });                                                                                                        //
          }                                                                                                            //
          return readStream;                                                                                           // 306
        }                                                                                                              //
      }                                                                                                                //
      return null;                                                                                                     // 308
    };                                                                                                                 //
                                                                                                                       //
    FileCollection.prototype.remove = function(selector, callback) {                                                   // 19
      var err, ret;                                                                                                    // 311
      if (callback == null) {                                                                                          //
        callback = void 0;                                                                                             //
      }                                                                                                                //
      callback = share.bind_env(callback);                                                                             // 311
      if (selector != null) {                                                                                          // 312
        ret = 0;                                                                                                       // 313
        this.find(selector).forEach((function(_this) {                                                                 // 313
          return function(file) {                                                                                      //
            var res;                                                                                                   // 315
            res = Meteor.wrapAsync(_this.gfs.remove.bind(_this.gfs))({                                                 // 315
              _id: mongodb.ObjectID("" + file._id),                                                                    // 316
              root: _this.root,                                                                                        // 316
              timeOut: _this.lockOptions.timeOut,                                                                      // 316
              lockExpiration: _this.lockOptions.lockExpiration,                                                        // 316
              pollingInterval: _this.lockOptions.pollingInterval                                                       // 316
            });                                                                                                        //
            return ret += res ? 1 : 0;                                                                                 //
          };                                                                                                           //
        })(this));                                                                                                     //
        (callback != null) && callback(null, ret);                                                                     // 313
        return ret;                                                                                                    // 323
      } else {                                                                                                         //
        err = new Meteor.Error("Remove with an empty selector is not supported");                                      // 325
        if (callback != null) {                                                                                        // 326
          callback(err);                                                                                               //
        } else {                                                                                                       //
          throw err;                                                                                                   // 330
        }                                                                                                              //
      }                                                                                                                //
    };                                                                                                                 //
                                                                                                                       //
    FileCollection.prototype.importFile = function(filePath, file, callback) {                                         // 19
      var readStream, writeStream;                                                                                     // 333
      callback = share.bind_env(callback);                                                                             // 333
      filePath = path.normalize(filePath);                                                                             // 333
      if (file == null) {                                                                                              //
        file = {};                                                                                                     //
      }                                                                                                                //
      if (file.filename == null) {                                                                                     //
        file.filename = path.basename(filePath);                                                                       //
      }                                                                                                                //
      readStream = fs.createReadStream(filePath);                                                                      // 333
      readStream.on('error', share.bind_env(callback));                                                                // 333
      writeStream = this.upsertStream(file);                                                                           // 333
      return readStream.pipe(share.streamChunker(this.chunkSize)).pipe(writeStream).on('close', share.bind_env(function(d) {
        return callback(null, d);                                                                                      //
      })).on('error', share.bind_env(callback));                                                                       //
    };                                                                                                                 //
                                                                                                                       //
    FileCollection.prototype.exportFile = function(selector, filePath, callback) {                                     // 19
      var readStream, writeStream;                                                                                     // 345
      callback = share.bind_env(callback);                                                                             // 345
      filePath = path.normalize(filePath);                                                                             // 345
      readStream = this.findOneStream(selector);                                                                       // 345
      writeStream = fs.createWriteStream(filePath);                                                                    // 345
      return readStream.pipe(writeStream).on('finish', share.bind_env(callback)).on('error', share.bind_env(callback));
    };                                                                                                                 //
                                                                                                                       //
    return FileCollection;                                                                                             //
                                                                                                                       //
  })(Mongo.Collection);                                                                                                //
}                                                                                                                      //
                                                                                                                       //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/vsivsi_file-collection/src/resumable_server.coffee.js                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var async, check_order, dicer, express, grid, gridLocks, mongodb, resumable_get_handler, resumable_get_lookup, resumable_post_handler, resumable_post_lookup;
                                                                                                                       //
if (Meteor.isServer) {                                                                                                 // 7
  express = Npm.require('express');                                                                                    // 9
  mongodb = Npm.require('mongodb');                                                                                    // 9
  grid = Npm.require('gridfs-locking-stream');                                                                         // 9
  gridLocks = Npm.require('gridfs-locks');                                                                             // 9
  dicer = Npm.require('dicer');                                                                                        // 9
  async = Npm.require('async');                                                                                        // 9
  check_order = function(file, callback) {                                                                             // 9
    var fileId, lock;                                                                                                  // 20
    fileId = mongodb.ObjectID("" + file.metadata._Resumable.resumableIdentifier);                                      // 20
    lock = gridLocks.Lock(fileId, this.locks, {}).obtainWriteLock();                                                   // 20
    lock.on('locked', (function(_this) {                                                                               // 20
      return function() {                                                                                              //
        var cursor, files;                                                                                             // 24
        files = _this.db.collection(_this.root + ".files");                                                            // 24
        cursor = files.find({                                                                                          // 24
          'metadata._Resumable.resumableIdentifier': file.metadata._Resumable.resumableIdentifier,                     // 27
          length: {                                                                                                    // 27
            $ne: 0                                                                                                     // 30
          }                                                                                                            //
        }, {                                                                                                           //
          fields: {                                                                                                    // 32
            length: 1,                                                                                                 // 34
            metadata: 1                                                                                                // 34
          },                                                                                                           //
          sort: {                                                                                                      // 32
            'metadata._Resumable.resumableChunkNumber': 1                                                              // 37
          }                                                                                                            //
        });                                                                                                            //
        return cursor.count(function(err, count) {                                                                     //
          var chunks;                                                                                                  // 42
          if (err) {                                                                                                   // 42
            lock.releaseLock();                                                                                        // 43
            return callback(err);                                                                                      // 44
          }                                                                                                            //
          if (!(count >= 1)) {                                                                                         // 46
            cursor.close();                                                                                            // 47
            lock.releaseLock();                                                                                        // 47
            return callback();                                                                                         // 49
          }                                                                                                            //
          if (count !== file.metadata._Resumable.resumableTotalChunks) {                                               // 51
            cursor.close();                                                                                            // 52
            lock.releaseLock();                                                                                        // 52
            return callback();                                                                                         // 54
          }                                                                                                            //
          chunks = _this.db.collection(_this.root + ".chunks");                                                        // 42
          cursor.batchSize(file.metadata._Resumable.resumableTotalChunks + 1);                                         // 42
          return cursor.toArray(function(err, parts) {                                                                 //
            if (err) {                                                                                                 // 63
              lock.releaseLock();                                                                                      // 64
              return callback(err);                                                                                    // 65
            }                                                                                                          //
            return async.eachLimit(parts, 5, function(part, cb) {                                                      //
              var partId, partlock;                                                                                    // 69
              if (err) {                                                                                               // 69
                console.error("Error from cursor.next()", err);                                                        // 70
                cb(err);                                                                                               // 70
              }                                                                                                        //
              if (!part) {                                                                                             // 72
                return cb(new Meteor.Error("Received null part"));                                                     // 72
              }                                                                                                        //
              partId = mongodb.ObjectID("" + part._id);                                                                // 69
              partlock = gridLocks.Lock(partId, _this.locks, {}).obtainWriteLock();                                    // 69
              partlock.on('locked', function() {                                                                       // 69
                return async.series([                                                                                  //
                  function(cb) {                                                                                       //
                    return chunks.update({                                                                             //
                      files_id: partId,                                                                                // 78
                      n: 0                                                                                             // 78
                    }, {                                                                                               //
                      $set: {                                                                                          // 79
                        files_id: fileId,                                                                              // 79
                        n: part.metadata._Resumable.resumableChunkNumber - 1                                           // 79
                      }                                                                                                //
                    }, cb);                                                                                            //
                  }, function(cb) {                                                                                    //
                    return files.remove({                                                                              //
                      _id: partId                                                                                      // 82
                    }, cb);                                                                                            //
                  }                                                                                                    //
                ], function(err, res) {                                                                                //
                  if (err) {                                                                                           // 85
                    return cb(err);                                                                                    // 85
                  }                                                                                                    //
                  if (part.metadata._Resumable.resumableChunkNumber !== part.metadata._Resumable.resumableTotalChunks) {
                    partlock.removeLock();                                                                             // 87
                    return cb();                                                                                       //
                  } else {                                                                                             //
                    return chunks.update({                                                                             //
                      files_id: partId,                                                                                // 91
                      n: 1                                                                                             // 91
                    }, {                                                                                               //
                      $set: {                                                                                          // 92
                        files_id: fileId,                                                                              // 92
                        n: part.metadata._Resumable.resumableChunkNumber                                               // 92
                      }                                                                                                //
                    }, function(err, res) {                                                                            //
                      partlock.removeLock();                                                                           // 94
                      if (err) {                                                                                       // 95
                        return cb(err);                                                                                // 95
                      }                                                                                                //
                      return cb();                                                                                     //
                    });                                                                                                //
                  }                                                                                                    //
                });                                                                                                    //
              });                                                                                                      //
              partlock.on('timed-out', function() {                                                                    // 69
                return cb(new Meteor.Error('Partlock timed out!'));                                                    //
              });                                                                                                      //
              partlock.on('expired', function() {                                                                      // 69
                return cb(new Meteor.Error('Partlock expired!'));                                                      //
              });                                                                                                      //
              return partlock.on('error', function(err) {                                                              //
                console.error("Error obtaining partlock " + part._id, err);                                            // 100
                return cb(err);                                                                                        //
              });                                                                                                      //
            }, function(err) {                                                                                         //
              var md5Command;                                                                                          // 103
              if (err) {                                                                                               // 103
                lock.releaseLock();                                                                                    // 104
                return callback(err);                                                                                  // 105
              }                                                                                                        //
              md5Command = {                                                                                           // 103
                filemd5: fileId,                                                                                       // 108
                root: "" + _this.root                                                                                  // 108
              };                                                                                                       //
              return _this.db.command(md5Command, function(err, results) {                                             //
                if (err) {                                                                                             // 112
                  lock.releaseLock();                                                                                  // 113
                  return callback(err);                                                                                // 114
                }                                                                                                      //
                return files.update({                                                                                  //
                  _id: fileId                                                                                          // 116
                }, {                                                                                                   //
                  $set: {                                                                                              // 116
                    length: file.metadata._Resumable.resumableTotalSize,                                               // 116
                    md5: results.md5                                                                                   // 116
                  }                                                                                                    //
                }, (function(_this) {                                                                                  //
                  return function(err, res) {                                                                          //
                    lock.releaseLock();                                                                                // 118
                    return callback(err);                                                                              //
                  };                                                                                                   //
                })(this));                                                                                             //
              });                                                                                                      //
            });                                                                                                        //
          });                                                                                                          //
        });                                                                                                            //
      };                                                                                                               //
    })(this));                                                                                                         //
    lock.on('expires-soon', function() {                                                                               // 20
      return lock.renewLock().once('renewed', function(ld) {                                                           //
        if (!ld) {                                                                                                     // 123
          return console.warn("Resumable upload lock renewal failed!");                                                //
        }                                                                                                              //
      });                                                                                                              //
    });                                                                                                                //
    lock.on('expired', function() {                                                                                    // 20
      return callback(new Meteor.Error("File Lock expired"));                                                          //
    });                                                                                                                //
    lock.on('timed-out', function() {                                                                                  // 20
      return callback(new Meteor.Error("File Lock timed out"));                                                        //
    });                                                                                                                //
    return lock.on('error', function(err) {                                                                            //
      return callback(err);                                                                                            //
    });                                                                                                                //
  };                                                                                                                   //
  resumable_post_lookup = function(params, query, multipart) {                                                         // 9
    var ref;                                                                                                           // 132
    return {                                                                                                           // 132
      _id: share.safeObjectID(multipart != null ? (ref = multipart.params) != null ? ref.resumableIdentifier : void 0 : void 0)
    };                                                                                                                 //
  };                                                                                                                   //
  resumable_post_handler = function(req, res, next) {                                                                  // 9
    var chunkQuery, findResult, ref, ref1, resumable, writeStream;                                                     // 137
    if (!((ref = req.multipart) != null ? (ref1 = ref.params) != null ? ref1.resumableIdentifier : void 0 : void 0)) {
      console.error("Missing resumable.js multipart information");                                                     // 138
      res.writeHead(501, share.defaultResponseHeaders);                                                                // 138
      res.end();                                                                                                       // 138
      return;                                                                                                          // 141
    }                                                                                                                  //
    resumable = req.multipart.params;                                                                                  // 137
    resumable.resumableTotalSize = parseInt(resumable.resumableTotalSize);                                             // 137
    resumable.resumableTotalChunks = parseInt(resumable.resumableTotalChunks);                                         // 137
    resumable.resumableChunkNumber = parseInt(resumable.resumableChunkNumber);                                         // 137
    resumable.resumableChunkSize = parseInt(resumable.resumableChunkSize);                                             // 137
    resumable.resumableCurrentChunkSize = parseInt(resumable.resumableCurrentChunkSize);                               // 137
    if (req.maxUploadSize > 0) {                                                                                       // 150
      if (!(resumable.resumableTotalSize <= req.maxUploadSize)) {                                                      // 151
        res.writeHead(413, share.defaultResponseHeaders);                                                              // 152
        res.end();                                                                                                     // 152
        return;                                                                                                        // 154
      }                                                                                                                //
    }                                                                                                                  //
    if (!((req.gridFS.chunkSize === resumable.resumableChunkSize) && (resumable.resumableChunkNumber <= resumable.resumableTotalChunks) && (resumable.resumableTotalSize / resumable.resumableChunkSize <= resumable.resumableTotalChunks + 1) && (resumable.resumableCurrentChunkSize === resumable.resumableChunkSize) || ((resumable.resumableChunkNumber === resumable.resumableTotalChunks) && (resumable.resumableCurrentChunkSize < 2 * resumable.resumableChunkSize)))) {
      res.writeHead(501, share.defaultResponseHeaders);                                                                // 164
      res.end();                                                                                                       // 164
      return;                                                                                                          // 166
    }                                                                                                                  //
    chunkQuery = {                                                                                                     // 137
      length: resumable.resumableCurrentChunkSize,                                                                     // 169
      'metadata._Resumable.resumableIdentifier': resumable.resumableIdentifier,                                        // 169
      'metadata._Resumable.resumableChunkNumber': resumable.resumableChunkNumber                                       // 169
    };                                                                                                                 //
    findResult = this.findOne(chunkQuery, {                                                                            // 137
      fields: {                                                                                                        // 174
        _id: 1                                                                                                         // 174
      }                                                                                                                //
    });                                                                                                                //
    if (findResult) {                                                                                                  // 176
      res.writeHead(200, share.defaultResponseHeaders);                                                                // 179
      return res.end();                                                                                                //
    } else {                                                                                                           //
      req.gridFS.metadata._Resumable = resumable;                                                                      // 183
      writeStream = this.upsertStream({                                                                                // 183
        filename: "_Resumable_" + resumable.resumableIdentifier + "_" + resumable.resumableChunkNumber + "_" + resumable.resumableTotalChunks,
        metadata: req.gridFS.metadata                                                                                  // 185
      });                                                                                                              //
      if (!writeStream) {                                                                                              // 188
        res.writeHead(404, share.defaultResponseHeaders);                                                              // 189
        res.end();                                                                                                     // 189
        return;                                                                                                        // 191
      }                                                                                                                //
      return req.multipart.fileStream.pipe(share.streamChunker(this.chunkSize)).pipe(writeStream).on('close', share.bind_env((function(_this) {
        return function(retFile) {                                                                                     //
          if (retFile) {                                                                                               // 195
            return check_order.bind(_this)(req.gridFS, function(err) {                                                 //
              if (err) {                                                                                               // 198
                console.error("Error reassembling chunks of resumable.js upload", err);                                // 199
                res.writeHead(500, share.defaultResponseHeaders);                                                      // 199
              } else {                                                                                                 //
                res.writeHead(200, share.defaultResponseHeaders);                                                      // 202
              }                                                                                                        //
              return res.end();                                                                                        //
            });                                                                                                        //
          } else {                                                                                                     //
            console.error("Missing retFile on pipe close");                                                            // 206
            res.writeHead(500, share.defaultResponseHeaders);                                                          // 206
            return res.end();                                                                                          //
          }                                                                                                            //
        };                                                                                                             //
      })(this))).on('error', share.bind_env((function(_this) {                                                         //
        return function(err) {                                                                                         //
          console.error("Piping Error!", err);                                                                         // 212
          res.writeHead(500, share.defaultResponseHeaders);                                                            // 212
          return res.end();                                                                                            //
        };                                                                                                             //
      })(this)));                                                                                                      //
    }                                                                                                                  //
  };                                                                                                                   //
  resumable_get_lookup = function(params, query) {                                                                     // 9
    var q;                                                                                                             // 217
    q = {                                                                                                              // 217
      _id: share.safeObjectID(query.resumableIdentifier)                                                               // 217
    };                                                                                                                 //
    return q;                                                                                                          // 218
  };                                                                                                                   //
  resumable_get_handler = function(req, res, next) {                                                                   // 9
    var chunkQuery, query, result;                                                                                     // 224
    query = req.query;                                                                                                 // 224
    chunkQuery = {                                                                                                     // 224
      $or: [                                                                                                           // 226
        {                                                                                                              //
          _id: share.safeObjectID(query.resumableIdentifier),                                                          // 227
          length: parseInt(query.resumableTotalSize)                                                                   // 227
        }, {                                                                                                           //
          length: parseInt(query.resumableCurrentChunkSize),                                                           // 231
          'metadata._Resumable.resumableIdentifier': query.resumableIdentifier,                                        // 231
          'metadata._Resumable.resumableChunkNumber': parseInt(query.resumableChunkNumber)                             // 231
        }                                                                                                              //
      ]                                                                                                                //
    };                                                                                                                 //
    result = this.findOne(chunkQuery, {                                                                                // 224
      fields: {                                                                                                        // 238
        _id: 1                                                                                                         // 238
      }                                                                                                                //
    });                                                                                                                //
    if (result) {                                                                                                      // 239
      res.writeHead(200, share.defaultResponseHeaders);                                                                // 241
    } else {                                                                                                           //
      res.writeHead(204, share.defaultResponseHeaders);                                                                // 244
    }                                                                                                                  //
    return res.end();                                                                                                  //
  };                                                                                                                   //
  share.resumablePaths = [                                                                                             // 9
    {                                                                                                                  //
      method: 'head',                                                                                                  // 250
      path: share.resumableBase,                                                                                       // 250
      lookup: resumable_get_lookup,                                                                                    // 250
      handler: resumable_get_handler                                                                                   // 250
    }, {                                                                                                               //
      method: 'post',                                                                                                  // 256
      path: share.resumableBase,                                                                                       // 256
      lookup: resumable_post_lookup,                                                                                   // 256
      handler: resumable_post_handler                                                                                  // 256
    }, {                                                                                                               //
      method: 'get',                                                                                                   // 262
      path: share.resumableBase,                                                                                       // 262
      lookup: resumable_get_lookup,                                                                                    // 262
      handler: resumable_get_handler                                                                                   // 262
    }                                                                                                                  //
  ];                                                                                                                   //
}                                                                                                                      //
                                                                                                                       //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/vsivsi_file-collection/src/http_access_server.coffee.js                                                    //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var build_access_point, cookieParser, del, dice_multipart, dicer, express, find_mime_boundary, get, grid, gridLocks, handle_auth, lookup_userId_by_token, mongodb, post, put;
                                                                                                                       //
if (Meteor.isServer) {                                                                                                 // 7
  express = Npm.require('express');                                                                                    // 9
  cookieParser = Npm.require('cookie-parser');                                                                         // 9
  mongodb = Npm.require('mongodb');                                                                                    // 9
  grid = Npm.require('gridfs-locking-stream');                                                                         // 9
  gridLocks = Npm.require('gridfs-locks');                                                                             // 9
  dicer = Npm.require('dicer');                                                                                        // 9
  find_mime_boundary = function(req) {                                                                                 // 9
    var RE_BOUNDARY, result;                                                                                           // 17
    RE_BOUNDARY = /^multipart\/.+?(?:; boundary=(?:(?:"(.+)")|(?:([^\s]+))))$/i;                                       // 17
    result = RE_BOUNDARY.exec(req.headers['content-type']);                                                            // 17
    return (result != null ? result[1] : void 0) || (result != null ? result[2] : void 0);                             //
  };                                                                                                                   //
  dice_multipart = function(req, res, next) {                                                                          // 9
    var boundary, count, d, fileName, fileStream, fileType, handleFailure, params, responseSent;                       // 24
    next = share.bind_env(next);                                                                                       // 24
    if (!(req.method === 'POST' && !req.diced)) {                                                                      // 26
      next();                                                                                                          // 27
      return;                                                                                                          // 28
    }                                                                                                                  //
    req.diced = true;                                                                                                  // 24
    responseSent = false;                                                                                              // 24
    handleFailure = function(msg, err, retCode) {                                                                      // 24
      if (err == null) {                                                                                               //
        err = "";                                                                                                      //
      }                                                                                                                //
      if (retCode == null) {                                                                                           //
        retCode = 500;                                                                                                 //
      }                                                                                                                //
      console.error(msg + " \n", err);                                                                                 // 34
      if (!responseSent) {                                                                                             // 35
        responseSent = true;                                                                                           // 36
        res.writeHead(retCode, share.defaultResponseHeaders);                                                          // 36
        return res.end();                                                                                              //
      }                                                                                                                //
    };                                                                                                                 //
    boundary = find_mime_boundary(req);                                                                                // 24
    if (!boundary) {                                                                                                   // 42
      handleFailure("No MIME multipart boundary found for dicer");                                                     // 43
      return;                                                                                                          // 44
    }                                                                                                                  //
    params = {};                                                                                                       // 24
    count = 0;                                                                                                         // 24
    fileStream = null;                                                                                                 // 24
    fileType = 'text/plain';                                                                                           // 24
    fileName = 'blob';                                                                                                 // 24
    d = new dicer({                                                                                                    // 24
      boundary: boundary                                                                                               // 52
    });                                                                                                                //
    d.on('part', function(p) {                                                                                         // 24
      p.on('header', function(header) {                                                                                // 55
        var RE_FILE, RE_PARAM, data, k, param, re, ref, v;                                                             // 56
        RE_FILE = /^form-data; name="file"; filename="([^"]+)"/;                                                       // 56
        RE_PARAM = /^form-data; name="([^"]+)"/;                                                                       // 56
        for (k in header) {                                                                                            // 58
          v = header[k];                                                                                               //
          if (k === 'content-type') {                                                                                  // 59
            fileType = v;                                                                                              // 60
          }                                                                                                            //
          if (k === 'content-disposition') {                                                                           // 61
            if (re = RE_FILE.exec(v)) {                                                                                // 62
              fileStream = p;                                                                                          // 63
              fileName = re[1];                                                                                        // 63
            } else if (param = (ref = RE_PARAM.exec(v)) != null ? ref[1] : void 0) {                                   //
              data = '';                                                                                               // 66
              count++;                                                                                                 // 66
              p.on('data', function(d) {                                                                               // 66
                return data += d.toString();                                                                           //
              });                                                                                                      //
              p.on('end', function() {                                                                                 // 66
                count--;                                                                                               // 71
                params[param] = data;                                                                                  // 71
                if (count === 0 && fileStream) {                                                                       // 73
                  req.multipart = {                                                                                    // 74
                    fileStream: fileStream,                                                                            // 75
                    fileName: fileName,                                                                                // 75
                    fileType: fileType,                                                                                // 75
                    params: params                                                                                     // 75
                  };                                                                                                   //
                  responseSent = true;                                                                                 // 74
                  return next();                                                                                       //
                }                                                                                                      //
              });                                                                                                      //
            } else {                                                                                                   //
              console.warn("Dicer part", v);                                                                           // 82
            }                                                                                                          //
          }                                                                                                            //
        }                                                                                                              // 58
        if (count === 0 && fileStream) {                                                                               // 84
          req.multipart = {                                                                                            // 85
            fileStream: fileStream,                                                                                    // 86
            fileName: fileName,                                                                                        // 86
            fileType: fileType,                                                                                        // 86
            params: params                                                                                             // 86
          };                                                                                                           //
          responseSent = true;                                                                                         // 85
          return next();                                                                                               //
        }                                                                                                              //
      });                                                                                                              //
      return p.on('error', function(err) {                                                                             //
        return handleFailure('Error in Dicer while parsing multipart:', err);                                          //
      });                                                                                                              //
    });                                                                                                                //
    d.on('error', function(err) {                                                                                      // 24
      return handleFailure('Error in Dicer while parsing parts:', err);                                                //
    });                                                                                                                //
    d.on('finish', function() {                                                                                        // 24
      if (!fileStream) {                                                                                               // 100
        return handleFailure("Error in Dicer, no file found in POST");                                                 //
      }                                                                                                                //
    });                                                                                                                //
    return req.pipe(d);                                                                                                //
  };                                                                                                                   //
  post = function(req, res, next) {                                                                                    // 9
    var stream;                                                                                                        // 113
    if (req.multipart.fileType) {                                                                                      // 113
      req.gridFS.contentType = req.multipart.fileType;                                                                 // 113
    }                                                                                                                  //
    if (req.multipart.fileName) {                                                                                      // 114
      req.gridFS.filename = req.multipart.fileName;                                                                    // 114
    }                                                                                                                  //
    stream = this.upsertStream(req.gridFS);                                                                            // 113
    if (stream) {                                                                                                      // 118
      return req.multipart.fileStream.pipe(share.streamChunker(this.chunkSize)).pipe(stream).on('close', function(retFile) {
        if (retFile) {                                                                                                 // 121
          res.writeHead(200, share.defaultResponseHeaders);                                                            // 122
          return res.end();                                                                                            //
        }                                                                                                              //
      }).on('error', function(err) {                                                                                   //
        res.writeHead(500, share.defaultResponseHeaders);                                                              // 125
        return res.end();                                                                                              //
      });                                                                                                              //
    } else {                                                                                                           //
      res.writeHead(410, share.defaultResponseHeaders);                                                                // 128
      return res.end();                                                                                                //
    }                                                                                                                  //
  };                                                                                                                   //
  get = function(req, res, next) {                                                                                     // 9
    var chunksize, end, filename, h, headers, parts, ref, ref1, start, statusCode, stream, v;                          // 137
    headers = {};                                                                                                      // 137
    ref = share.defaultResponseHeaders;                                                                                // 138
    for (h in ref) {                                                                                                   // 138
      v = ref[h];                                                                                                      //
      headers[h] = v;                                                                                                  // 139
    }                                                                                                                  // 138
    if (req.headers['range']) {                                                                                        // 142
      statusCode = 206;                                                                                                // 144
      parts = req.headers["range"].replace(/bytes=/, "").split("-");                                                   // 144
      start = parseInt(parts[0], 10);                                                                                  // 144
      end = (parts[1] ? parseInt(parts[1], 10) : req.gridFS.length - 1);                                               // 144
      if ((start < 0) || (end >= req.gridFS.length) || (start > end) || isNaN(start) || isNaN(end)) {                  // 152
        headers['Content-Range'] = 'bytes ' + '*/' + req.gridFS.length;                                                // 153
        res.writeHead(416, headers);                                                                                   // 153
        res.end();                                                                                                     // 153
        return;                                                                                                        // 156
      }                                                                                                                //
      chunksize = (end - start) + 1;                                                                                   // 144
      headers['Content-Range'] = 'bytes ' + start + '-' + end + '/' + req.gridFS.length;                               // 144
      headers['Accept-Ranges'] = 'bytes';                                                                              // 144
      headers['Content-Type'] = req.gridFS.contentType;                                                                // 144
      headers['Content-Length'] = chunksize;                                                                           // 144
      headers['Last-Modified'] = req.gridFS.uploadDate.toUTCString();                                                  // 144
      if (req.method !== 'HEAD') {                                                                                     // 169
        stream = this.findOneStream({                                                                                  // 170
          _id: req.gridFS._id                                                                                          // 171
        }, {                                                                                                           //
          range: {                                                                                                     // 173
            start: start,                                                                                              // 174
            end: end                                                                                                   // 174
          }                                                                                                            //
        });                                                                                                            //
      }                                                                                                                //
    } else {                                                                                                           //
      statusCode = 200;                                                                                                // 181
      headers['Content-Type'] = req.gridFS.contentType;                                                                // 181
      headers['Content-MD5'] = req.gridFS.md5;                                                                         // 181
      headers['Content-Length'] = req.gridFS.length;                                                                   // 181
      headers['Last-Modified'] = req.gridFS.uploadDate.toUTCString();                                                  // 181
      if (req.method !== 'HEAD') {                                                                                     // 190
        stream = this.findOneStream({                                                                                  // 191
          _id: req.gridFS._id                                                                                          // 191
        });                                                                                                            //
      }                                                                                                                //
    }                                                                                                                  //
    if ((req.query.download && req.query.download.toLowerCase() === 'true') || req.query.filename) {                   // 194
      filename = encodeURIComponent((ref1 = req.query.filename) != null ? ref1 : req.gridFS.filename);                 // 195
      headers['Content-Disposition'] = "attachment; filename=\"" + filename + "\"; filename*=UTF-8''" + filename;      // 195
    }                                                                                                                  //
    if (req.query.cache && !isNaN(parseInt(req.query.cache))) {                                                        // 199
      headers['Cache-Control'] = "max-age=" + parseInt(req.query.cache) + ", private";                                 // 200
    }                                                                                                                  //
    if (req.method === 'HEAD') {                                                                                       // 203
      res.writeHead(204, headers);                                                                                     // 204
      res.end();                                                                                                       // 204
      return;                                                                                                          // 206
    }                                                                                                                  //
    if (stream) {                                                                                                      // 209
      res.writeHead(statusCode, headers);                                                                              // 210
      return stream.pipe(res).on('close', function() {                                                                 //
        return res.end();                                                                                              //
      }).on('error', function(err) {                                                                                   //
        res.writeHead(500, share.defaultResponseHeaders);                                                              // 215
        return res.end(err);                                                                                           //
      });                                                                                                              //
    } else {                                                                                                           //
      res.writeHead(410, share.defaultResponseHeaders);                                                                // 218
      return res.end();                                                                                                //
    }                                                                                                                  //
  };                                                                                                                   //
  put = function(req, res, next) {                                                                                     // 9
    var stream;                                                                                                        // 230
    if (req.headers['content-type']) {                                                                                 // 230
      req.gridFS.contentType = req.headers['content-type'];                                                            // 231
    }                                                                                                                  //
    stream = this.upsertStream(req.gridFS);                                                                            // 230
    if (stream) {                                                                                                      // 235
      return req.pipe(share.streamChunker(this.chunkSize)).pipe(stream).on('close', function(retFile) {                //
        if (retFile) {                                                                                                 // 238
          res.writeHead(200, share.defaultResponseHeaders);                                                            // 239
          return res.end();                                                                                            //
        } else {                                                                                                       //
                                                                                                                       // 238
        }                                                                                                              //
      }).on('error', function(err) {                                                                                   //
        res.writeHead(500, share.defaultResponseHeaders);                                                              // 243
        return res.end(err);                                                                                           //
      });                                                                                                              //
    } else {                                                                                                           //
      res.writeHead(404, share.defaultResponseHeaders);                                                                // 246
      return res.end(req.url + " Not found!");                                                                         //
    }                                                                                                                  //
  };                                                                                                                   //
  del = function(req, res, next) {                                                                                     // 9
    this.remove(req.gridFS);                                                                                           // 257
    res.writeHead(204, share.defaultResponseHeaders);                                                                  // 257
    return res.end();                                                                                                  //
  };                                                                                                                   //
  build_access_point = function(http) {                                                                                // 9
    var i, len, r;                                                                                                     // 267
    for (i = 0, len = http.length; i < len; i++) {                                                                     // 267
      r = http[i];                                                                                                     //
      if (r.method.toUpperCase() === 'POST') {                                                                         // 269
        this.router.post(r.path, dice_multipart);                                                                      // 270
      }                                                                                                                //
      this.router[r.method](r.path, (function(_this) {                                                                 // 269
        return function(r) {                                                                                           //
          return function(req, res, next) {                                                                            //
            var lookup, opts, ref, ref1, ref2;                                                                         // 278
            if (((ref = req.params) != null ? ref._id : void 0) != null) {                                             // 278
              req.params._id = share.safeObjectID(req.params._id);                                                     // 278
            }                                                                                                          //
            if (((ref1 = req.query) != null ? ref1._id : void 0) != null) {                                            // 279
              req.query._id = share.safeObjectID(req.query._id);                                                       // 279
            }                                                                                                          //
            lookup = (ref2 = r.lookup) != null ? ref2.bind(_this)(req.params || {}, req.query || {}, req.multipart) : void 0;
            if (lookup == null) {                                                                                      // 283
              res.writeHead(500, share.defaultResponseHeaders);                                                        // 285
              res.end();                                                                                               // 285
            } else {                                                                                                   //
              req.gridFS = _this.findOne(lookup);                                                                      // 290
              if (!req.gridFS) {                                                                                       // 291
                res.writeHead(404, share.defaultResponseHeaders);                                                      // 292
                res.end();                                                                                             // 292
                return;                                                                                                // 294
              }                                                                                                        //
              switch (req.method) {                                                                                    // 297
                case 'HEAD':                                                                                           // 297
                case 'GET':                                                                                            // 297
                  if (!share.check_allow_deny.bind(_this)('read', req.meteorUserId, req.gridFS)) {                     // 299
                    res.writeHead(403, share.defaultResponseHeaders);                                                  // 300
                    res.end();                                                                                         // 300
                    return;                                                                                            // 302
                  }                                                                                                    //
                  break;                                                                                               // 298
                case 'POST':                                                                                           // 297
                case 'PUT':                                                                                            // 297
                  req.maxUploadSize = _this.maxUploadSize;                                                             // 304
                  if (!(opts = share.check_allow_deny.bind(_this)('write', req.meteorUserId, req.gridFS))) {           // 305
                    res.writeHead(403, share.defaultResponseHeaders);                                                  // 306
                    res.end();                                                                                         // 306
                    return;                                                                                            // 308
                  }                                                                                                    //
                  if ((opts.maxUploadSize != null) && typeof opts.maxUploadSize === 'number') {                        // 309
                    req.maxUploadSize = opts.maxUploadSize;                                                            // 310
                  }                                                                                                    //
                  if (req.maxUploadSize > 0) {                                                                         // 311
                    if (req.headers['content-length'] == null) {                                                       // 312
                      res.writeHead(411, share.defaultResponseHeaders);                                                // 313
                      res.end();                                                                                       // 313
                      return;                                                                                          // 315
                    }                                                                                                  //
                    if (!(parseInt(req.headers['content-length']) <= req.maxUploadSize)) {                             // 316
                      res.writeHead(413, share.defaultResponseHeaders);                                                // 317
                      res.end();                                                                                       // 317
                      return;                                                                                          // 319
                    }                                                                                                  //
                  }                                                                                                    //
                  break;                                                                                               // 303
                case 'DELETE':                                                                                         // 297
                  if (!share.check_allow_deny.bind(_this)('remove', req.meteorUserId, req.gridFS)) {                   // 321
                    res.writeHead(403, share.defaultResponseHeaders);                                                  // 322
                    res.end();                                                                                         // 322
                    return;                                                                                            // 324
                  }                                                                                                    //
                  break;                                                                                               // 320
                case 'OPTIONS':                                                                                        // 297
                  if (!(share.check_allow_deny.bind(_this)('read', req.meteorUserId, req.gridFS) || share.check_allow_deny.bind(_this)('write', req.meteorUserId, req.gridFS) || share.check_allow_deny.bind(_this)('remove', req.meteorUserId, req.gridFS))) {
                    res.writeHead(403, share.defaultResponseHeaders);                                                  // 329
                    res.end();                                                                                         // 329
                    return;                                                                                            // 331
                  }                                                                                                    //
                  break;                                                                                               // 325
                default:                                                                                               // 297
                  res.writeHead(500, share.defaultResponseHeaders);                                                    // 333
                  res.end();                                                                                           // 333
                  return;                                                                                              // 335
              }                                                                                                        // 297
              return next();                                                                                           //
            }                                                                                                          //
          };                                                                                                           //
        };                                                                                                             //
      })(this)(r));                                                                                                    //
      if (typeof r.handler === 'function') {                                                                           // 340
        this.router[r.method](r.path, r.handler.bind(this));                                                           // 341
      }                                                                                                                //
    }                                                                                                                  // 267
    return this.router.route('/*').head(get.bind(this)).get(get.bind(this)).put(put.bind(this)).post(post.bind(this))["delete"](del.bind(this)).all(function(req, res, next) {
      res.writeHead(500, share.defaultResponseHeaders);                                                                // 351
      return res.end();                                                                                                //
    });                                                                                                                //
  };                                                                                                                   //
  lookup_userId_by_token = function(authToken) {                                                                       // 9
    var ref, userDoc;                                                                                                  // 357
    userDoc = (ref = Meteor.users) != null ? ref.findOne({                                                             // 357
      'services.resume.loginTokens': {                                                                                 // 358
        $elemMatch: {                                                                                                  // 359
          hashedToken: typeof Accounts !== "undefined" && Accounts !== null ? Accounts._hashLoginToken(authToken) : void 0
        }                                                                                                              //
      }                                                                                                                //
    }) : void 0;                                                                                                       //
    return (userDoc != null ? userDoc._id : void 0) || null;                                                           // 361
  };                                                                                                                   //
  handle_auth = function(req, res, next) {                                                                             // 9
    var ref, ref1;                                                                                                     // 367
    if (req.meteorUserId == null) {                                                                                    // 367
      if (((ref = req.headers) != null ? ref['x-auth-token'] : void 0) != null) {                                      // 369
        req.meteorUserId = lookup_userId_by_token(req.headers['x-auth-token']);                                        // 370
      } else if (((ref1 = req.cookies) != null ? ref1['X-Auth-Token'] : void 0) != null) {                             //
        req.meteorUserId = lookup_userId_by_token(req.cookies['X-Auth-Token']);                                        // 373
      } else {                                                                                                         //
        req.meteorUserId = null;                                                                                       // 375
      }                                                                                                                //
    }                                                                                                                  //
    return next();                                                                                                     //
  };                                                                                                                   //
  share.setupHttpAccess = function(options) {                                                                          // 9
    var h, i, len, otherHandlers, r, ref, ref1, resumableHandlers;                                                     // 382
    if (options.resumable) {                                                                                           // 382
      if (options.http == null) {                                                                                      // 383
        options.http = [];                                                                                             // 383
      }                                                                                                                //
      resumableHandlers = [];                                                                                          // 383
      otherHandlers = [];                                                                                              // 383
      ref = options.http;                                                                                              // 386
      for (i = 0, len = ref.length; i < len; i++) {                                                                    // 386
        h = ref[i];                                                                                                    //
        if (h.path === share.resumableBase) {                                                                          // 387
          resumableHandlers.push(h);                                                                                   // 388
        } else {                                                                                                       //
          otherHandlers.push(h);                                                                                       // 390
        }                                                                                                              //
      }                                                                                                                // 386
      resumableHandlers = resumableHandlers.concat(share.resumablePaths);                                              // 383
      options.http = resumableHandlers.concat(otherHandlers);                                                          // 383
    }                                                                                                                  //
    if (((ref1 = options.http) != null ? ref1.length : void 0) > 0) {                                                  // 395
      r = express.Router();                                                                                            // 396
      r.use(express.query());                                                                                          // 396
      r.use(cookieParser());                                                                                           // 396
      r.use(handle_auth);                                                                                              // 396
      WebApp.rawConnectHandlers.use(this.baseURL, share.bind_env(r));                                                  // 396
      this.router = express.Router();                                                                                  // 396
      build_access_point.bind(this)(options.http, this.router);                                                        // 396
      return WebApp.rawConnectHandlers.use(this.baseURL, share.bind_env(this.router));                                 //
    }                                                                                                                  //
  };                                                                                                                   //
}                                                                                                                      //
                                                                                                                       //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
(function (pkg, symbols) {
  for (var s in symbols)
    (s in pkg) || (pkg[s] = symbols[s]);
})(Package['vsivsi:file-collection'] = {}, {
  FileCollection: FileCollection
});

})();

//# sourceMappingURL=vsivsi_file-collection.js.map
