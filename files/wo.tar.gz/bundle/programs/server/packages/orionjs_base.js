(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var ECMAScript = Package.ecmascript.ECMAScript;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;
var _ = Package.underscore._;
var Spacebars = Package.spacebars.Spacebars;
var check = Package.check.check;
var Match = Package.check.Match;
var Tracker = Package.tracker.Tracker;
var Deps = Package.tracker.Deps;
var Options = Package['nicolaslopezj:options'].Options;
var ReactiveTemplates = Package['nicolaslopezj:reactive-templates'].ReactiveTemplates;
var Roles = Package['nicolaslopezj:roles'].Roles;
var objectHasKey = Package['nicolaslopezj:roles'].objectHasKey;
var RouterLayer = Package['nicolaslopezj:router-layer'].RouterLayer;
var SimpleSchema = Package['aldeed:simple-schema'].SimpleSchema;
var MongoObject = Package['aldeed:simple-schema'].MongoObject;
var meteorInstall = Package.modules.meteorInstall;
var Buffer = Package.modules.Buffer;
var process = Package.modules.process;
var Symbol = Package['ecmascript-runtime'].Symbol;
var Map = Package['ecmascript-runtime'].Map;
var Set = Package['ecmascript-runtime'].Set;
var meteorBabelHelpers = Package['babel-runtime'].meteorBabelHelpers;
var Promise = Package.promise.Promise;
var WebApp = Package.webapp.WebApp;
var main = Package.webapp.main;
var WebAppInternals = Package.webapp.WebAppInternals;
var DDP = Package['ddp-client'].DDP;
var DDPServer = Package['ddp-server'].DDPServer;
var Blaze = Package.ui.Blaze;
var UI = Package.ui.UI;
var Handlebars = Package.ui.Handlebars;
var i18n = Package['anti:i18n'].i18n;
var T9n = Package['softwarerero:accounts-t9n'].T9n;
var Autoupdate = Package.autoupdate.Autoupdate;
var HTML = Package.htmljs.HTML;

/* Package-scope variables */
var orion;

var require = meteorInstall({"node_modules":{"meteor":{"orionjs:base":{"init.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                //
// packages/orionjs_base/init.js                                                                  //
//                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                  //
orion = {};                                                                                       // 1
////////////////////////////////////////////////////////////////////////////////////////////////////

},"helpers.js":["babel-runtime/helpers/typeof",function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                //
// packages/orionjs_base/helpers.js                                                               //
//                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                  //
var _typeof2 = require('babel-runtime/helpers/typeof');                                           //
                                                                                                  //
var _typeof3 = _interopRequireDefault(_typeof2);                                                  //
                                                                                                  //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
                                                                                                  //
/**                                                                                               //
 * Orion Helpers                                                                                  //
 */                                                                                               //
orion.helpers = {};                                                                               // 4
                                                                                                  //
/**                                                                                               //
 * Searchs a object with a givin string                                                           //
 * you can specify if you want the searcher to                                                    //
 * take the first values of array if they are                                                     //
 */                                                                                               //
orion.helpers.searchObjectWithDots = function (object, key, selectFirstIfIsArray) {               // 11
  key = key.split('.');                                                                           // 12
                                                                                                  //
  try {                                                                                           // 14
    for (var i = 0; i < key.length; i++) {                                                        // 15
      if (selectFirstIfIsArray && object.length && object.length > 0) {                           // 16
        object = object[0];                                                                       // 17
      }                                                                                           //
      if (key[i] in object) {                                                                     // 19
        object = object[key[i]];                                                                  // 20
      } else {                                                                                    //
        return undefined;                                                                         // 22
      }                                                                                           //
    }                                                                                             //
  } catch (error) {                                                                               //
    return undefined;                                                                             // 26
  }                                                                                               //
                                                                                                  //
  return object;                                                                                  // 29
};                                                                                                //
                                                                                                  //
/**                                                                                               //
 * Deep extend                                                                                    //
 */                                                                                               //
orion.helpers.deepExtend = function (target, source) {                                            // 35
  for (var prop in meteorBabelHelpers.sanitizeForInObject(source)) {                              // 36
    if (prop in target && (0, _typeof3['default'])(target[prop]) == 'object' && (0, _typeof3['default'])(source[prop]) == 'object') orion.helpers.deepExtend(target[prop], source[prop]);else target[prop] = source[prop];
  }return target;                                                                                 //
};                                                                                                //
                                                                                                  //
/**                                                                                               //
 * Returns a function that returns the translation                                                //
 * Useful for autoform                                                                            //
 */                                                                                               //
orion.helpers.getTranslation = function (key) {                                                   // 48
  return function () {                                                                            // 49
    return i18n(key);                                                                             // 50
  };                                                                                              //
};                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////

}],"home-route.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                //
// packages/orionjs_base/home-route.js                                                            //
//                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                  //
/**                                                                                               //
 * Set the admin home route                                                                       //
 */                                                                                               //
Options.init('adminHomeRoute', 'myAccount.index');                                                // 4
                                                                                                  //
if (RouterLayer.router == 'iron-router') {                                                        // 6
  RouterLayer.ironRouter.route('/admin', function () {                                            // 7
    this.router.go(Options.get('adminHomeRoute'), {}, { replaceState: true });                    // 8
  }, { name: 'admin' });                                                                          //
} else {                                                                                          //
  RouterLayer.flowRouter.route('/admin', {                                                        // 11
    name: 'admin',                                                                                // 12
    action: function () {                                                                         // 13
      function action() {                                                                         // 13
        RouterLayer.go(Options.get('adminHomeRoute'));                                            // 14
      }                                                                                           //
                                                                                                  //
      return action;                                                                              //
    }()                                                                                           //
  });                                                                                             //
}                                                                                                 //
////////////////////////////////////////////////////////////////////////////////////////////////////

},"layouts.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                //
// packages/orionjs_base/layouts.js                                                               //
//                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                  //
/**                                                                                               //
 * Requests a layout template                                                                     //
 */                                                                                               //
ReactiveTemplates.request('layout');                                                              // 4
                                                                                                  //
/**                                                                                               //
 * Requests a layout for auth                                                                     //
 */                                                                                               //
ReactiveTemplates.request('outAdminLayout');                                                      // 9
////////////////////////////////////////////////////////////////////////////////////////////////////

}}}}},{"extensions":[".js",".json"]});
require("./node_modules/meteor/orionjs:base/init.js");
require("./node_modules/meteor/orionjs:base/helpers.js");
require("./node_modules/meteor/orionjs:base/home-route.js");
require("./node_modules/meteor/orionjs:base/layouts.js");

/* Exports */
if (typeof Package === 'undefined') Package = {};
(function (pkg, symbols) {
  for (var s in symbols)
    (s in pkg) || (pkg[s] = symbols[s]);
})(Package['orionjs:base'] = {}, {
  orion: orion
});

})();

//# sourceMappingURL=orionjs_base.js.map
